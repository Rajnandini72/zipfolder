Document #: COM-4111 REV-1.0
################################################################################
#                                                                              #
# Copyright (C) IBM Corporation 2016, 2020.                                    #
# Copyright (C) Merge Healthcare 2005, 2016.                                   #
#                                                                              #
# All rights reserved.                                                         #
#                                                                              #
# This software is furnished under license and may be used and copied only in  #
# accordance with the terms of such license and with the inclusion of the      #
# above copyright notice.                                                      #
#                                                                              #
# This software or any other copies thereof may not be provided or otherwise   #
# made available to any other person. No title to and ownership of the         #
# software is hereby transferred.                                              #
#                                                                              #
################################################################################
#                                                                              #
#                             RELEASE NOTES for                                #
#                 Merge DICOM C/C++ Toolkit Release 5.11.0                     #
#                                                                              #
#                 https://www.ibm.com/marketplace/merge-dicom-toolkit          #
#                                                                              #
# Please read the platform notes included for your platform first. They        #
# describesthe system configuration on which this toolkit will run. Verify     #
# that your systemconfiguration is appropriate. It also contains a road map to #
# the rest of the Merge DICOM Toolkit documentation.                           #
#                                                                              #
################################################################################

PLEASE NOTE:
============

If you cannot find the answer to your questions in any of the documentation,
contact IBM Watson Health via e-mail or phone (e-mail preferred) at:

            MC3Support@ca.ibm.com

            � In North America: call toll-free 1-877-741-5369
            � International: +31.40.299.0773

Please include any relevant logs, API usage descriptions, or other data that may
be helpful in diagnosing the problem in your e-mail.

WINDOWS PLATFORM NOTE:
======================

On Windows platforms, the toolkit is now built with Microsoft Visual Studio 
2005 SP1. As a consequence applications using the static version of the toolkit 
have to be linked with the C runtime library included in Microsoft Visual 
Studio 2005 SP1 or later.  Applications using the dynamic library 
version of the toolkit can be linked with older versions of the C runtime.

ICU4C Unicode conversion library
================================

All platforms, with the exception of Linux on ARM, support Unicode conversion
using the ICU4C library.
  ICU License - ICU 1.8.1 and later
  COPYRIGHT AND PERMISSION NOTICE
  Copyright (c) 1995-2014 International Business Machines Corporation and others
  All rights reserved. 
Refer to User's Manual for details of copyright, permission and disclaimer
notice.


Enhancements in Version 5.11.0
==============================

Added support to the data dictionary and software for the following DICOM
Supplements:
 176    Second Generation Radiotherapy - New RT Radiations
 208    DICOM Encapsulation of OBJ Models for 3D Manufacturing and Virtual
        Reality

Updated the data dictionary and software to address the following change
proposals:
 1479, 1721, 1726, 1733, 1777, 1852, 1861, 1862, 1882, 1867, 1886, 1888,
 1890, 1891, 1892, 1893, 1894, 1895, 1899, 1900, 1901, 1902, 1903, 1904,
 1905, 1906, 1907, 1909, 1910, 1911, 1912, 1913, 1919, 1920, 1922, 1924,
 1925, 1928, 1929, 1930, 1931, 1932, 1933, 1935, 1936, 1937, 1938, 1939,
 1940, 1941, 1942, 1943, 1945, 1946, 1947, 1948, 1949, 1952, 1953, 1954,
 1955, 1956, 1957, 1958, 1959, 1960, 1961, 1963, 1965, 1973, 1979, 1980

Added support for multithreaded operation of Pegasus compression/decompression
library. The PEGASUS_NUMBER_OF_THREADS configuration setting has been added to
the [MESSAGE_PARMS] section of the system profile.

Upgraded libxml2 to the latest version (2.9.10).


Updates in Version 5.11.0
=========================

Fixed issue where the DICOM character string decoder defaulted on the wrong
character set (ISO_IR 100) instead of the default repertoire.

Fixed issue where the DICOM to JSON and DICOM to XML Native conversions would
fail if the Specific Character Set (0008,0005) attribute is missing or empty.

Fixed issue where the PEGASUS_OPCODE_PATH configuration setting could not be set
using environment variables, including the pseudo-variable MC3INIDIR (Windows
platforms only).
Recently the Merge DICOM Toolkit implemented support for Unicode paths for the
configuration files and in general for all the files that the toolkit uses:
temporary files, log file, etc. The Pegasus library, however, only supports
ASCII paths for the opcodes. So PEGASUS_OPCODE_PATH was exempted from the new
scheme, with the result that it could not be set using environment variables.
The fix was to add PEGASUS_OPCODE_PATH to the Unicode path scheme and then just
let the client application deal with the obligation to supply a non-Unicode
(ASCII) path (either directly or indirectly through environment variables) so as
to meet this Pegasus limitation.

Fixed issue where for JPEG 2000, RGB, non-interleaved (color-by-plane)
compressed data the Pegasus library would return incomplete decompressed data.
The main fix was in the Pegasus decompression library (issue logged as case
IN-139520 by Accusoft).

Fixed crash in the mc3dcomb database utility when attempting to combine data
dictionary with modifier file.

Fixed a failure to read multiple values of attribute with value representation
DS when the maximum data value length of 16 was exceeded. Instead of just
issuing a warning, the toolkit would quit parsing the subsequent values, which
would be lost.

Fixed the MC_Get_MergeCOM_Service_From_UID API that did not work for user
defined services.

Fixed toolkit crash when opening a file with a duplicated private tag when the
two instances of the tag have different value representations, in particular:
non-SQ for the first instance and SQ for the second instance.

Fixed the failure to decompress JPEG lossless, RGB, non-interleaved
(color-by-plane) pixel data.


Enhancements in Version 5.10.0
==============================

Added support to the data dictionary and software for the following DICOM
Supplements:
 175    Second Generation Radiotherapy - C-Arm Radiations
 202    Real-Time Video

Updated the data dictionary and software to address the following change
proposals:
 1551, 1552, 1766, 1770, 1808, 1835, 1839, 1841, 1842, 1843, 1844, 1845,
 1846, 1847, 1848, 1849, 1850, 1851, 1853, 1854, 1855, 1856, 1857, 1858,
 1859, 1860, 1864, 1865, 1874, 1875, 1876, 1877, 1878, 1879, 1880, 1883,
 1884

Added support for Unicode paths through environment variables for the toolkit
configuration files.
This means that for all the files used by the toolkit (configuration, log file,
temporary files, etc.), Unicode paths can now be specified through environment
variables. This also includes the pseudo-environment variable MC3INIDIR, which
doesn't have to be set as it's resolved internally by the toolkit to the
directory where the merge.ini file resides.
There are two methods for specifying a Unicode path for the merge.ini
initialization file itself: the existing MERGE_INI environment variable and the
newly added function MC_Set_MergeINI_Unicode().

Added support for compression/decompression of images with photometric
interpretations of YBR_FULL and PALETTE COLOR.


Updates in Version 5.10.0
=========================

Fixed issue where the range of the ISO 2022 IR 87 encoder/decoder was missing
the last 6 characters in the JIS X 0208 to Unicode mapping (0x7421 to 0x7426).

Fixed issue where the validation functions (MC_Validate_Attribute,
MC_Validate_Message, MC_Validate_File) would incorrectly return
MC_INVALID_VALUE_FOR_VR when MC_INVALID_LENGTH_FOR_VR would have been
appropriate.

Fixed similar issue where set value functions, upon performing value validation,
would incorrectly return MC_INVALID_VALUE_FOR_VR when MC_INVALID_LENGTH_FOR_VR
would have been appropriate.

Fixed issue where consecutive messages were sent to the same destination AE with
the same message ID in multi-threading operation.

Fixed issue where the toolkit would crash on malformed P-DATA-TF PDU, e.g. a PDU
where the PDV item length is set to a very large value such as 4294967289
(0xfffffff9).


Enhancements in Version 5.9.0
=============================

Added support to the data dictionary and software for the following DICOM
Supplements:
 147    Second Generation Radiotherapy - Prescription and Segment Annotation
 164    Contrast Agent Administration Reporting
 183    PS3.18 Web Services Re-Documentation
 188    Multi-Energy CT Images
 203    Thumbnail Resources for DICOMweb
 206    Extended BCP195 TLS Profile

Updated the data dictionary and software to address the following change
proposals:
  991, 1626, 1663, 1674, 1714, 1736, 1746, 1747, 1764, 1779, 1787, 1788,
 1789, 1790, 1791, 1792, 1793, 1794, 1795, 1796, 1797, 1798, 1799, 1801,
 1802, 1803, 1804, 1807, 1809, 1810, 1811, 1812, 1813, 1814, 1815, 1816,
 1817, 1820, 1821, 1822, 1823, 1824, 1825, 1826, 1827, 1828, 1829, 1830,
 1833, 1834, 1836, 1837, 1838, 1840

The toolkit library leverages Zlib inflate/deflate functionality by embedding
some of the Zlib source code. One problem that may arise is that applications
wanting to link with an external instance of the library risk facing potential
name clashes that can cause the link to fail. The solution recommended by Zlib
is to use the Z_PREFIX compile option, which shifts the names of all the
functions in the library (by prepending 'z_'), thus avoiding the name clashes
when linking with a second instance of the library. Unless that second instance
itself uses the Z_PREFIX, in which case the name clashes are brought back. In
the case of the toolkit, the issue was solved by introducing our own unique
custom prefix, therefore reducing the chance of name clashes to extremely
improbable.

A number of well-known vulnerabilities registered against Zlib (CVE-2016-9840,
CVE-2016-9841, CVE-2016-9842, CVE-2016-9843) for version 1.2.8 and earlier were
resolved by upgrading the Zlib library embedded source code to version 1.2.11.


Updates in Version 5.9.0
========================

According to the DICOM standard, string type attribute values of VR (value
representation) UR and UT can be very large, up to 2^32 - 2, but the VM (value
multiplicity) is always 1. Accordingly, the toolkit allows such values to be
stored and retrieved using MC_Set_Value_From_Function() and
MC_Get_Value_To_Function(), respectively, for standard attributes and
MC_Set_Value_From_Function() and MC_Get_Value_To_Function() for private
attributes. In such usage, the large values may be stored internally in multiple
chunks of size determined by the size of the buffers defined in the user
function. This was causing problems with the way some internal and public
functions were handling these values. The following issues were fixed:
    - Issue where the MC_Get_Value_Count() and MC_Get_pValue_Count() functions
    would return the number of internal values (chunks) in which the UR or UT
    value was stored instead of value 1 expected in accordance with the VM
    mandated by DICOM.
    - Issue where the MC_Get_Value_Length() and MC_Get_pValue_Length() functions
    would erroneously account for separator characters ('\') between the
    internal values (chunks) in which the UR or UT value was stored.
    - Issue where the MC_Get_Stream_Length() function would erroneously
    account for separator characters ('\') between the internal values (chunks)
    in which the UR or UT value was stored.
    - Issue where media functions such as MC_Write_File() and
    MC_Write_File_By_Callback() would incorrectly insert value separators ('\')
    between the internal values (chunks) in which the UR or UT value was stored,
    when writing the Part 10 file to the media.
    - Issue where message sending and receiving functions such as
    MC_Send_Request(), MC_Send_Request_For_Service(), MC_Send_Request_Message(),
    MC_Send_Request_Message_For_Service(), MC_Send_Response(),
    MC_Send_Response_Message() would incorrectly insert value separators ('\')
    between the internal values (chunks) in which the UR or UT value was stored,
    when sending the request or response message over the association.
    - Issue where the MC_Set_Next_Value_From_String() and
    MC_Set_Next_pValue_From_String() functions would succeed for attributes with
    a VR of UR or UT despite the DICOM standard stating that these VRs have a VM
    of 1.
    - Issue where the MC_Get_Next_Value_To_String() and
    MC_Get_Next_pValue_To_String() functions would succeed for attributes with a
    VR of UR or UT although the DICOM standard states that these VRs have a VM
    of 1.

Updated a number of directory record definitions in the message information
database that were outdated.

Fixed regression where the toolkit would discard an otherwise valid (accepted)
association if the A-ASSOCIATE-AC PDU contained a Presentation Context Item
corresponding to a presentation context that was rejected and this Presentation
Context Item did not contain a Transfer Syntax sub-item, even an empty one. The
issue, now fixed, was that the toolkit would insist that the Transfer Syntax
sub-item be present, a condition that is not mandated by the DICOM standard,
which just states that the Transfer Syntax sub-item for a rejected presentation
context should simply be ignored.

Fixed issue where calling MC_Write_File() or MC_Write_File_By_Callback() would
result in a crash if the Part 10 file to be written out contained DICOM
directory structuring elements, i.e. elements from group (0004).

Fixed issue affecting 32- and 64-bit Windows platforms, where several relatively
rarely used user functions (MC_Get_MergeCOM_Service_From_UID(),
MC_Release_Library_Exception_Handler(), MC_Send_Response(),
MC_Unicode_Get_Substitution_Characters(), while documented in the Reference
Manual, were not actually being exported to the toolkit dynamic library. 


Enhancements in Version 5.8.0
=============================

Added support to the data dictionary and software for the following DICOM
Supplement:
 205    Encapsulation of STL Models for 3D Manufacturing

Updated the data dictionary and software to address the following change
proposals:
 1670, 1671, 1700, 1719, 1720, 1738, 1748, 1750, 1751, 1752, 1753, 1757,
 1758, 1759, 1760, 1761, 1762, 1763, 1765, 1767, 1768, 1769, 1771, 1772,
 1773, 1774, 1775, 1778, 1780, 1781, 1782, 1783, 1784

Added support for extended character set encoding/decoding using the ICU4C
Unicode conversion library to the iOS platform.

Added support for DICOM Native XML conversion API to the Android on ARMv7/ARMv8
platforms. The DICOM Native XML conversion is now supported on all platforms,
with the exception of Linux on ARMv8.

Enhanced run-time error logging to provide more information for improved
on-the-fly and off-line debugging.

Implemented support for obtaining the reason why an association request was
rejected. The new APIs introduced - MC_Open_Association_With_Reject_Info(),
MC_Open_Association_With_Identity_With_Reject_Info(),
MC_Open_Secure_Association_With_Reject_Info() - now return the
result/source/reason parameters for the rejection.
Another API - MC_Reject_Association_With_Reason_Codes() - was added to
allow passing the individual result/source/reason parameters for the
A-ASSOCIATE-RJ PDU.

Improved the validation functions (MC_Validate_File(), MC_Validate_Message(),
MC_Validate_Attribute()) and the mc3valid utility to make it easier to figure
out where in the data set hierarchy the validation errors originate.

Added several integrity checks for the association negotiation PDUs:
- Presentation Context Items in A-ASSOCIATE-RQ and A-ASSOCIATE-AC
- SOP Class Common Extended Negotiation Sub-Items in A-ASSOCIATE-AC (not
  allowed)

Improved usability of the mc3valid utility by:
- removing some redundant command line options
- eliminating some unexpected behaviour, such as validation yielding different
  results when the service/command parameters are entered on the command line
  or when they are selected from a list

Improved message validation functionality to respond to "May be present
otherwise" conditional clauses - Part 2.

Improved message and attribute validation by introducing support for conditions
on attributes not present in the current data set, but in an enclosing data set
- Part 2. The added support is still work-in-progress, with only a subset of
the applicable conditions from the DICOM standard having been handled.

Added support for DICOM to JSON and JSON to DICOM conversion for Android
platforms.

Added support for specific character sets to the high level structured report
API (the MC_SRH_... functions). Previously the API could only be used if the
string parameters to the functions consisted only of ASCII characters.

Improved MC_Set_Value_From_Function() and MC_Set_pValue_From_Function() by
adding support for numeric value representations (SS, US, AT, SL, UL, FL, FD)
to match the range of VRs accepted by MC_Get_Value_To_Function() and
MC_Get_pValue_To_Function().

Updates in Version 5.8.0
========================

Fixed dynamic link build failure for sample applications in the Borland
distribution.

Fixed issue where a warning returned by an ICU4C internal call, which normally
does not indicate a failure, would instead cause the MC_Byte_To_Unicode() API
to return an error and fail.

The MC_Byte_To_Unicode() API was behaving incorrectly in multi-threaded use due
to a race condition in the ICU4C library. Fixed by synchronizing the ICU4C calls
in toolkit code.

Fixed issue where the toolkit could not receive sequence attribute over the
network if the tag and value length of the attribute were in one PDU and the
item tag and sequence item in the next PDU.

Fixed issue where not detailed enough  encoding ranges for the ISO 2022 IR 87
and ISO 2022 IR 159 specific character sets could result in incorrect encoding
of Japanese characters.

Fixed issue where reading icon image sequence pixel data with missing delimiter
would cause a crash.


Enhancements in Version 5.7.0
=============================

Added support to the data dictionary and software for the following DICOM
Supplements:
 200    Transformation of NCI Annotation and Image Markup (AIM) and DICOM SR
        Measurement Templates
 204    TLS Security Profiles
 
Updated the data dictionary and software to address the following change
proposals:
 1180, 1189, 1224, 1403, 1617, 1632, 1650, 1668, 1683, 1698, 1699, 1701,
 1702, 1703, 1704, 1705, 1709, 1710, 1711, 1713, 1716, 1722, 1725, 1727,
 1729, 1730, 1731, 1734, 1737, 1739, 1740, 1741, 1742, 1743, 1744

Added support for extended character set encoding/decoding using the ICU4C
Unicode conversion library to the Android platform.

Improved message validation functionality to respond to "May be present
otherwise" conditional clauses - Part 1. The added support is still
work-in-progress, with only a subset of the applicable conditions from the DICOM
standard having been handled.

Improved message and attribute validation by introducing support for conditions
on attributes not present in the current data set, but in an enclosing data set
- Part 1. The added support is still work-in-progress, with only a subset of the
applicable conditions from the DICOM standard having been handled.

Retro-fitted the toolkit for compatibility with the trial retired UPS SOP
Classes. The toolkit is now able to handle both the 'trial retired' and the
officially supported UPS SOP classes.

Improvement in the message database definitions to resolve the functional group
macros for each individual IOD type to a uniquely, clearly defined sequence
item for to the respective IOD, rather than the non-specific union of all
existing functional group macro sequence items.


Updates in Version 5.7.0
========================

Fixed issue where the RLE compressor would crash if pixel data is 1 pixel. In
fact requesting RLE compression does not add any value for very small data sizes
as the compressed data tend to be even larger than the uncompressed data.
Therefore the minimum pixel data size that is now accepted for RLE compression
is 8 rows by 8 columns.

Fixed issue where MC_Get_Encapsulated_Value_To_Function() would return the
entire pixel data rather than the first frame or fragment and would not leave
anything for subsequent calls to MC_Get_Next_Encapsulated_Value_To_Function()
which would return "No more values". This issue would manifest itself only under
these particular conditions:
- no decompression callback was registered for the pixel data
- the pixel data did not have an offset table.

Fixed issue where an empty value 3 in the Image Type (0008,0008) attribute,
which is acceptable by the DICOM Standard in a Digital X-Ray image, was being
reported as a validation error.

Fixed issue where if the user read callback used a very small working buffer
(less than 8 bytes) then the offset table from encapsulated pixel data was not
being read correctly.

Fixed issue where the message database was failing to enact the recursive nature
of the Content Sequence (0040,A730) attribute in the SR Document Content Module.

Fixed issue where the Structured Report (API MC_SRH_Create_NUM_Node()) was
inadvertently attempting to create non-existent MEASURING_UNITS sequence item
and the call would result in a failure.

Fixed issue where in A-ASSOCIATE-RQ the User Information Item length field
having a value greater than the maximum length requested would cause buffer
overflow and result in a crash.

Fixed issue where icon image sequence pixel data was being truncated on write
back if all the following conditions were met:
- call to MC_Open_File_Upto_Tag_Bypass_Value() to read the file up to the (main
  data set) pixel data
- callback function registered for pixel data but the icon image sequence pixel
  data not handled by the registered callback function (size less than
  CALLBACK_MIN_DATA_SIZE)
- the icon image sequence pixel data read in in more than one chunk (depending
  on the size chosen for the buffer used by the user read callback

Fixed issue where the top level data set transfer syntax would fail to propagate
to the icon image sequence causing MC_Get_Encapsulated_Value_To_Function() to
fail when called for compressed icon image sequence pixel data.

Fixed issue where the compression/decompression callbacks would fail to
propagate to the icon image sequence causing MC_Duplicate_Message() to fail to
decompress icon image sequence pixel data.

Fixed issue where MC_Duplicate_Message would fail for (non-DICOM Standard
compliant) pixel data that is NULL (empty).

Fixed issue where the sequence attribute validation failure would issue
misleading warning "Value not one of defined terms" instead of the appropriate
"Sequence item not one of permitted types".

Fixed issue where a received PDV with length less than 2 bytes would cause a
buffer overflow and ultimately result in a crash.

Fixed issue where leading spaces in an attribute value with value representation
PN would cause a validation error. The DICOM standard originally specified that
PN values may be padded with trailing spaces. The 2008 edition of the standard
changes that (in a not totally unambiguous way) by stating that both leading and
trailing spaces are allowed and considered insignificant. The fix aligns the
toolkit with the present standard specification.

Fixed issue where the MC_Get_Tag_Keyword() function would alter the keywords for
retired attributes by appending "RETIRED", effectively making them different
from the DICOM standard.

Fixed issue where a call to the MC_Open_File_Bypass_OBOW() function would crash
the toolkit if it encounters a private attribute with a value representation of
OB/OW that does not have a private creator code.


Enhancements in Version 5.6.0
=============================

Added support to the data dictionary and software for the following DICOM
Supplements:
 189    Advanced Blending Presentation State Storage
 190    Volume Rendering Volumetric Presentation States
 191    Patient Radiation Dose Structured Report (P-RDSR)
 192    Instance Approval Storage SOP Class
 197    Ophthalmic Tomography Angiographic (OCT-A) Image Storage SOP Classes
 198    Retirement of WADO-WS
 201    Retirement of Radiation Dose Module from Modality Performed Procedure
        Step

Made changes to the data dictionary and software to address the following
correction proposals:
 1323, 1513, 1581, 1583, 1590, 1603, 1604, 1615, 1616, 1625, 1627, 1628,
 1629, 1630, 1631, 1633, 1635, 1638, 1642, 1643, 1644, 1645, 1646, 1647,
 1648, 1649, 1651, 1652, 1653, 1654, 1656, 1657, 1658, 1659, 1660, 1661,
 1662, 1664, 1665, 1666, 1672, 1673, 1675, 1676, 1677, 1678, 1679, 1680,
 1681, 1682, 1685, 1686, 1687, 1688, 1689, 1690, 1691, 1692, 1693, 1694,
 1695, 1696, 1697

Added Structured Report sample.


Updates in Version 5.6.0
========================

Fixed return values for MC_Get(_Next)_Value_To_UnicodeString() to be consistent
with MC_Get(_Next)_Value_To_String: MC_EMPTY_VALUE for empty value,
MC_NULL_VALUE for null value.

Fixed mc3dcomb tool to be more robust in the face of slight variations in input
file format, e.g. an empty line or a comment line should not result in a crash
or a hang.

Fixed issue where the called application title was not matched properly and was
incorrectly accepted based on incomplete (truncated) string comparison.

Fixed issue where the Q/R SCU sample would forget the service name between
(C-STORE) request and response, which would result in a warning.

Fixed issue where replacing a data set's compressed pixel data with uncompressed
would result in a crash.

Fixed issue where one replacement character would be returned in the encoded
string for each byte of an out-of-range character in the input string, instead
of one replacement character for each out-of-range character in the input
string.

Fixed issue where attempting to call MC_Get_Value_To_UnicodeString() for an
empty value would result in a crash.

Fixed issue where the toolkit would do exact AE Title match, including in the
comparison leading and trailing white space that is supposed to be
insignificant.

Fixed issue where in A-ASSOCIATE-RQ, the PDU maximum length field with length
shorter than the minimum length would cause buffer-overflow and result in a
crash.

Fixed issue where P-DATA-TF PDU of length shorter than the minimum length would
cause buffer-overflow and result in a crash. 

Fixed issue where value limit checks for long configuration parameters of type
'long integer' were missed when loading the configuration.

Fixed issue where the log file being not accessible for writing would prevent
callbacks to the registered log handling functions to be invoked.

Fixed issue where the toolkit would inadvertently encapsulate the pixel data
upon conversion to Deflated Explicit VR Little Endian transfer syntax.


Enhancements in Version 5.5.0
=============================

Added support to the data dictionary and software for the following DICOM
Supplements:
 169    Simplified Adult Echocardiographic Report
 194    RESTful Services for Non-Patient Instances
 195    HEVC/H.265 Transfer Syntax

Made changes to the data dictionary and software to address the following
correction proposals:
 1455, 1527, 1578, 1579, 1584, 1587, 1588, 1591, 1592, 1593, 1594, 1595,
 1597, 1598, 1599, 1600, 1601, 1602, 1608, 1609, 1611, 1612, 1619, 1620,
 1621, 1622, 1624, 1641


Updates in Version 5.5.0
========================

Fixed issue where MC_Get_Frame_To_Function() would not retrieve fragments of
data beyond the number of frames in the image. When pixel data are encapsulated
as fragments rather than whole frames, it means that the data contain more
fragments than there are frames. When there is no offset table and no
decompression is used, MC_Get_Frame_To_Function() will return a fragment and
must be able to retrieve any fragment in the data.

Fixed issue where MC_Get_Frame_To_Function() failed for multi-frame image with
bits allocated 1.

Fixed issue where MC_Open_File_Upto_Tag_Bypass_Value would stop on pixel data in
icon image sequence rather than the pixel data in the main data set.

Fixed issue where each time the offset table would be recalculated as a result
of a new encapsulated frame being added to the attribute, the changing size of
the offset table was added fully and not incrementally to the data length given
to the registered callback function, resulting in an incorrect total value
length for the attribute.

Imported ICU4C encoders may have encoding capabilities that extend beyond the
range of the character set for which they are used in the toolkit, so they may
be able to encode some Unicode characters that don't have a counterpart in the
character set, which would result in an invalid encoding. This issue has been
fixed by introducing range check on the characters returned by the encoder.

Fixed issue where MC_Get_Stream_Length() fails to calculate the correct stream
length if a callback function is registered for the pixel data AND the pixel
data has undefined length AND the undefined length (0xffffffff or -1) is passed
to the callback function AND then returned by the callback to the toolkit when
requested.

Fixed issue where, due to the relation between the PDV length and the length of
the internal toolkit buffers, the last PDV to be sent might have been of zero
length, which contravenes the DICOM Standard.

Fixed issue where the encapsulated icon image sequence pixel data was written
back with defined length, which contravenes the DICOM Standard in that it may
prevent further users to discern if the pixel data is encapsulated or native.

Fixed issue where the query to the JPEG header for image parameters (rows,
columns, etc.) fails if pixel data has multiple fragments per frame and the
entire JPEG header is not returned in the first fragment.

Fixed issue where MC_Open_File_Upto_Tag_Bypass_Value() returned
MC_OUT_OF_ORDER_TAG when reading file with icon image sequence

Fixed issue where internal toolkit macro was treating groups 0001, 0003, 0005
and 0007 as non-private and returning MC_INVALID_GROUP. Although these groups
are illegal as private groups in terms of the DICOM Standard, they are now
tolerated so that the element values are retrievable from legacy data (with a
warning being logged).

Fixed issue where a presentation context with a supported abstract syntax but
unsupported transfer syntax was rejected with the wrong reason
'3 - abstract-syntax-not-supported (provider rejection)' instead of the correct
one '4 - transfer-syntaxes-not-supported (provider rejection)'.


Enhancements in Version 5.4.0
=============================

Added support to the data dictionary and software for the following DICOM
Supplements:
 121    CT Protocol Storage

Made changes to the data dictionary and software to address the following
correction items:
 1013, 1361, 1362, 1418, 1433, 1503, 1509, 1539, 1541, 1542, 1543, 1544,
 1545, 1546, 1547, 1548, 1549, 1550, 1553, 1556, 1557, 1560, 1561, 1562,
 1563, 1564, 1565, 1566, 1567, 1568, 1569, 1573, 1574, 1575, 1582, 1586,
 1618


Updates in Version 5.4.0
========================

Relaxed condition for escape sequence between specific character sets
to allow escaping back not only to the G0, but also to the G1 code element of
value 1 of the Specific Character Set (0008,0005) attribute.

Fixed issue where the toolkit corrupts encapsulated DICOM file on storage if
pixel data is of odd length.

Fixed issue where mc3valid utility would issue warnings about duplicated DICOM
Directory Structuring Elements (group 0004 tags) in DICOMDIR file.

Fixed issue where the toolkit would issue a 'Missing Delimiter' error when
retrieving frames from DICOM file if the frame end and the internal buffer
boundary coincide.

Fixed issue where a null 'Filename' parameter to any of the MC_Send_Request,
MC_Send_Request_For_Service or MC_Send_Response functions would result in an
MC_NULL_POINTER_PARM error despite the documentation claiming that a null
value is allowed.

Fixed a number of usability issues in the compression sample (comp.c):
    - specifying a default input file is ineffective
    - inaccurate/incomplete error messages.
    - input file location restricted to the current directory
    - status codes returned by some functions are not checked consistently

Fixed issue where the UserInfo argument to
MC_Get_(Next_)Encapsulated_Value_To_Function was being misused in certain
use cases.

Fixed issue in attribute value validation where one of the character range
segments for the GB18030 character set was incorrect.

Fixed issue where invalid printf-like format in logging operation would cause
MC_Open_Association to crash (on timeout) if the remote node is not available.

Fixed issue where the last byte of a frame of odd length was being dropped when
retrieving the decompressed frame.


Enhancements in Version 5.3.0
=============================

Added support for the following DICOM Supplements to the data dictionary and
software:
 174	RESTful Rendering
 184	Brachy Delivery Instruction
 185	Content Assessment Results IOD
 187	Preclinical Small Animal Imaging Acquisition Context

Made changes to the data dictionary and software to address the following
correction items:
 1364, 1415, 1431, 1432, 1450, 1451, 1452, 1457, 1460, 1462, 1463, 1464,
 1465, 1466, 1467, 1468, 1469, 1470, 1471, 1472, 1473, 1475, 1476, 1477,
 1478, 1480, 1482, 1483, 1485, 1486, 1487, 1488, 1489, 1490, 1491, 1492,
 1493, 1494, 1495, 1496, 1497, 1498, 1499, 1501, 1502, 1504, 1506, 1507,
 1510, 1512, 1514, 1515, 1516, 1520, 1521, 1522, 1523, 1524, 1525, 1526,
 1528, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1537, 1538

Added support for simplified Chinese character sets (GBK, GB2312).

Added compression/decompression support (Pegasus) to the Solaris 10 on 32-bit
Intel platforms

Introduced automatically generated header files to pre-define the names of the
supported sequence items (mc3items.h) and supported services (mc3services.h).
Before, the names were hard-coded at least once in a program. This need has now
been removed, enabling compile-time name checking.

Updated the storage samples and SSL storage samples to handle the new meta file
information attributes introduced in CP 1297 (Sending Application Entity Title
and Receiving Application Entity Title).

Added DICOM Native XML conversion API. The DICOM Native XML conversion is now
supported on all platforms, with the exception of Android on ARMv7/ARMv8 and
Linux on ARMv7/ARMv8.

Added DICOM to JSON and JSON to DICOM conversion API. The JSON conversion is
now supported on all platforms, with the exception of Android on ARMv7/ARMv8
and Linux on ARMv7/ARMv8.

Improved tag formatting for display purposes to be in line with the standard
way users want it, as in this example: "(0010,0020) Patient ID".

Improved performance for the MC_Send_Request, MC_Send_Request_For_Service and
MC_Send_Response APIs to open the file only up to the last attribute that is
relevant (in this case SopInstanceUid (0008,0018) rather than the entire (0008)
group, as was previously done.

Developed simple Swift sample application to illustrate the basic guidelines of
integrating the Merge DICOM Toolkit into Xcode project for iOS.


Updates in Version 5.3.0
========================

Fixed a crash in MC_Read_Message() which would occur if the application AE
title is changed (application released, then re-registered) while the transfer
is on-going.

Fixed synchronization issue in configuration where setting a string-type
configuration item multiple times might trigger a race condition which may
result in incorrect (out-of-date or released) values being retrieved.

Fixed issue where it was not possible to create private block if the private
code contained invalid characters (even if the configuration setting
ALLOW_INVALID_PRIVATE_CREATOR_CODES was on).

Fixed issue where the mc3valid validation tool hangs if it is presented with a
data set containing a VOI LUT table where the (0028,3006) LUT Data attribute
has the maximum permitted number of values (65536) and a VR of US (as implied
by the toolkit).

Fixed the mc3valid validation utility to load the list of services from
configuration at run-time so as to be up-to-date with the DICOM standard in a
maintenance free way. The utility used to have the supported service/command
pairs hard-coded. Over the years, as the DICOM standard evolved, many new
services have been introduced, with no corresponding updates to mc3valid. 

Introduced mechanism to handle system errors/exceptions in toolkit operations
and provide some orderly shutdown action (logging, clean-up, etc.)

Fixed off-by-one error in the mc3dict tool where, upon generating the
MC_Dictionary_Values() function, the last entry in the data dictionary was left
out.

Fixed rare crash in native toolkit occurring when the finalizer for MCdataSet
was being invoked by the garbage collector.

Fixed issue where the storage SCP and the SSL storage SCP samples forgot the
service name between request and response, which resulted in a warning.

Fixed several buffer-overflow-type crashes caused by fields with invalid length
in A-ASSOCIATE_RQ PDU.



Enhancements in Version 5.2.0
=============================

Added support for the following DICOM Supplements to the data dictionary:
 156    Planar MPR Volumetric Presentation State
 180    MPEG-4 AVC/H.264 Transfer Syntax
 181    Tractography Results Storage SOP Class
 186    Extensible SR Storage SOP Class

Made changes to the data dictionary and software to address the following
correction items:
  812,  934, 1066, 1302, 1321, 1322, 1357, 1402, 1411, 1413, 1416, 1436,
 1437, 1438, 1439, 1440, 1441, 1442, 1443, 1444, 1445, 1446, 1447, 1448,
 1449, 1454, 1456, 1458, 1459, 1461

Added dynamic shared object to the distribution for Linux for ARMv7-A platform.
Previously only the static library was offered.

Added support for 64-bit Linux on ARMv8-A platforms.

Introduced new configuration setting (EXPLICIT_VR_TO_UN_FOR_LENGTH_GT_64K) to
support encoding data elements in Explicit VR whose value representation is none
of OB, OW, OD, OF, SQ or UT with value length exceeding 65534 bytes (CP-1066).

Added support for 64-bit iOS on ARMv8-A platforms. Previously supported 32-bit
iOS on ARMv7-A is no longer supported.

Added support for 32- and 64-bit Windows 10 platforms.

Added support for 64-bit Android on ARMv8-A platforms. Previously supported
32-bit Android on ARMv7-A is still supported.

Relaxed the validation for the encoding of data elements with value
representation UI to allow for multiple '.' characters in succession, which is
in violation of the DICOM standard, but apparently not uncommon in field
clinical data.



Updates in Version 5.2.0
========================

Fixed issue where corrupted RLE data would cause buffer overflow which may
result in crash.

Fixed memory leak in hash list of message objects which were not released
correctly.

Fixed issue where the storage SCU sample would send compressed images as
Explicit Little Endian. When creating the request message, setting the transfer
syntax was forgotten and the default ELE was being used.



Enhancements in Version 5.1.0
=============================

Added support for the following DICOM Supplements to the data dictionary:
 155    Imaging Reports using HL7 Clinical Document Architecture
 167    X-Ray 3D IOD Informative Annex
 171    Unified Procedure Step by Representational State Transfer (REST) Services
 172    Parametric Map Storage
 173    Wide Field Ophthalmic Photography Image Storage SOP Classes

Made changes to the data dictionary and software to address the following
correction items:
  375, 1031, 1350, 1366, 1367, 1368, 1369, 1370, 1371, 1372, 1373, 1374,
 1375, 1376, 1377, 1378, 1379, 1380, 1381, 1383, 1384, 1385, 1386, 1387,
 1388, 1389, 1390, 1391, 1392, 1393, 1394, 1395, 1396, 1397, 1398, 1399,
 1400, 1401, 1404, 1405, 1406, 1407, 1408, 1409, 1410, 1412, 1417, 1419,
 1420, 1421, 1422, 1424, 1425, 1426, 1427, 1428, 1429, 1430, 1434, 1435

Added support for Linux on ARMv7 platforms.

Introduced REJECT_INVALID_VR configuration setting to avoid some crashes due to
faulty data. If set to true it will cause the parsing will be aborted and the
data rejected.

Greatly improved the performance of traversing messages with very large numbers of
sequence items.



Updates in Version 5.1.0
========================

Fixed issue where the SCP crashes if the SCU is terminated during the send of a
large message.

Fixed issue where MC_Open_File_Upto_Tag_Bypass_Value did not behave as intended:
the function would not store the bulk (pixel) data (for which it relies on the
user callback to be invoked later on as needed), but it would still read the
data to the end, which defeats the purpose.

Fixed issue where planar configuration of JPEG/MPEG files was not set to 0 by
the MC_Duplicate_Message function and mc3conv tool.

Fixed issue where the license key was not working on the iOS platform.

Fixed errors in the Merge proprietary XML to/from DICOM conversion



Enhancements in Version 5.0.0
=============================

Added support for the following DICOM Supplements to the data dictionary:
 124    Communication of Display Parameters
 159    Radiopharmaceutical Radiation Dose Reporting
 170    Server Options RESTful Services

Made changes to the data dictionary to address the following correction items:

 1032, 1203, 1278, 1282, 1285, 1290, 1292, 1314, 1316, 1317, 1318, 1324,
 1325, 1326, 1327, 1328, 1329, 1330, 1331, 1332, 1334, 1335, 1336, 1337,
 1338, 1339, 1340, 1341, 1342, 1343, 1344, 1346, 1347, 1351, 1354, 1355,
 1356, 1359, 1360, 1365

Introduced prefixed symbols for the built-in zlib functions to prevent name clashes with external zlib in user applications.
 
Added support for new URI VR type (CP 1324).



Updates in Version 5.0.0
========================

Fixed issue where MC_XML_To_Message() fails to convert nested sequence attributes.

Fixed issue where XML to DICOM conversion handles character set incorrectly.

Fixed security vulnerability (CVE-2013-6825 - root privilege escalation) in print sample.

Fixed issue where length of string values encoded in ISO 2022 IR 149 (Korean) character set is calculated incorrectly.

Fixed issue where multi-valued Korean (ISO 2022 IR 149) is treated as single value.

Fixed crash in the mc3comp utility when comparing sequence items.



Enhancements in Version 4.10.0
==============================

Added support for the following DICOM Supplements to the data dictionary:

 165    Breast Projection X-Ray Image Storage SOP Class
 166    Query based on ID for DICOM Objects by RESTful Services (QIDO-RS)
 168    Corneal Topography Map Storage SOP Class

Made changes to the data dictionary to address the following change proposals:

 1223, 1268, 1274, 1287, 1291, 1294, 1295, 1296, 1297, 1298, 1299, 1300, 
 1301, 1303, 1304, 1305, 1306, 1307, 1308, 1309, 1310, 1311, 1312, 1313, 
 1315

Added functions MC_Send_Request(), MC_Send_Response() and MC_Read_To_Stream
added to allow using the callback mechanism for message exchange. Especially
useful for large data transfers, as the data are not loaded into application
memory.

Handle possible inconsistencies between compressed data (JPEG) header and
DICOM header in the favour of the JPEG header as required by DICOM (see
COMPRESSION_USE_HEADER_QUERY configuration setting in the documentation).



Updates in Version 4.10.0
=========================

Fixed the toolkit database implementation of MODALITY_WORKLIST_FIND which has
the wrong attribute types.

Fixed issue with MC_Set_Value_From_Int() called a second time for SQ attribute
results in memory leak as the previous value (sequence item) was not freed.

Fixed MC_Set_Encapsulated_Value_From_Function() which, for messages with
MPEG2/MPEG-4 transfer syntaxes, fails to store the entire pixel data bit stream
in a single fragment as required by the DICOM Standard.

Fixed defect where the toolkit in raw store mode saves received image in
Explicit Little Endian no matter regardless of the original transfer syntax.

Fixed issue where the UPS Pull SOP C-FIND response message has the wrong
Affected SOP Class UID.

Fixed issue where network capture initialization callback re-uses invalidated
semaphore after MC_Library_Release() has been called.



Enhancements in Version 4.9.0
=============================

Added support for the following DICOM Supplements to the data dictionary:

 157    Multi-Frame Converted Legacy Images
 163    Store Over the Web by RESTful Services (STOW-RS)

Made changes to the data dictionary to address the following change proposals:

 1164, 1173, 1218, 1219, 1220, 1244, 1245, 1246, 1247, 1248, 1249, 1250,
 1251, 1252, 1253, 1254, 1255, 1256, 1257, 1258, 1259, 1260, 1261, 1262,
 1263, 1264, 1265, 1266, 1267, 1269, 1270, 1271, 1272, 1273, 1275, 1276,
 1277, 1279, 1280, 1281, 1283, 1284, 1286, 1289, 1293

Allow the acceptable called AE title to be configured from predefined list
(previously either one defined AE title or any called AE tile was accepted)

Add sample case for the retrieval of the offset table in compression sample.

Configure pixel data buffer size so that data larger than 13MB no longer require
copying.

Exclude private creator code from output message if its private block contains
no attributes (when message template is used that includes private tags).

Allow users to relax DICOM validation when reading a file/stream
(ALLOW_INVALID_LENGTH_FOR_VR configuration setting, default NO).

Support pass-through mode (raw stream saving, no DICOM validation) in
Storage SCP sample.

Allow the option to not renumber private tags into contiguous sub-groups
(as DICOM suggests) when writing out a dataset



Updates in Version 4.9.0
========================

Fixed issue where private attributes with VR of AT cannot be set.

Fixed issue where validation did not handle the free-mingling ISO-IR 6 (ASCII)
and ISO-IR 149 (Korean) character sets.

Fixed issue with incomplete support for character set encoding in nested data
items (did not observe the specific character set attribute of the enclosing
data set).

Fixed issue with log file which did not wrap around correctly when full
(it was being reset instead).

Fixed issue where Unicode SetValue/GetValue functions would fail if attribute
(0008,0005) Specific Character Set is missing from the data set.

Fixed issue where MC_Duplicate_Message() fails if input file has attributes
beyond pixel data.

Fixed issue where MC_Read_Message_To_Tag/MC_Continue_Read_Message() would fail
if the stop tag encoding (group, element, VR, length) straddles two PDU buffers.

Fixed issue where isLast flag was not being set at the end of pixel data in
callback function when retrieving encapsulated data without offset table.



Enhancements in Version 4.8.0
=============================

Added support for the following DICOM Supplements to the data dictionary:

 154	Optical Surface Scanner Storage SOP Class
 158	Retirement of General Purpose Worklist and Procedure Step
 161	WADO by means of RESTful Services
 162	Comprehensive 3D SR Storage SOP Class

Made changes to the data dictionary to address the following change proposals:

 1112, 1152, 1174, 1200, 1201, 1209, 1210, 1211, 1213, 1214, 1215, 1216, 1221,
 1222, 1229, 1230, 1231, 1232, 1233, 1234, 1235, 1236, 1237, 1239, 1240, 1242,
 1243

Added support for iOS platform.

Added support for iOS compression/decompression with evaluation copy
(limited performance) of Accusoft's AIMTools� toolkit version 2.00.024.

Added support for callback 'C' and temp file 'F' storage model in message-to-XML
conversion.

Changed temporary file access to be open and closed only once instead of
for each write operation for improved performance.



Updates in Version 4.8.0
========================

Fixed issue where for compressed multiframe images the offset table is created
only after reading at least one frame.

Fixed issue where for compressed multiframe images "NO MORE VALUES" error
is returned when frames are read out of sequence.

Fixed issue where for compressed multiframe images with only one frame
"NO MORE VALUES" error is returned.

Fixed issue where for compressed multiframe images the wrong frame length
is returned.

Added missing error codes for storage commitment.

Fixed issue where padding due to odd length is not stripped from private attributes.

Fixed issue where for attributes larger than 2GB the toolkit fails to switch
to the second temporary file.

Fixed value multiplicity of (1-n) parsing error in mc3dict tool

Fixed issue where "Unexpected end of stream data" error is issued for an attribute that:
    has a VR of UN in the message/file 
    has a VR that is not UN in the dictionary 
    is the last in the message/file 
    has a length of zero

Fixed failure to pad odd size pixel data.



Enhancements in Version 4.7.0
=============================

Made changes to the data dictionary to address the following change proposals:

  739, 1077, 1105, 1123, 1137, 1138, 1148, 1171, 1175, 1176, 1177, 1178, 1179,
 1181, 1182, 1183, 1184, 1185, 1186, 1187, 1188, 1190, 1191, 1192, 1193, 1194,
 1195, 1197, 1198, 1199, 1202, 1204, 1205, 1206

Note:
 No new DICOM supplements were approved since version 4.6.0.

Added support for Android platform.

Added support for Android compression/decompression with evaluation copy 
(limited performance) of Accusoft's AIMTools� toolkit version 2.00.021.

Added extended character set encoding/decoding functionality with an optional
ICU4C Unicode conversion library.

Added support of extended character sets while converting DICOM to/from XML.

Added support of extended character sets during validation of attribute length.

Added new API to return offset table of multi-frame image.

Added new API to return a requested frame of multi-frame image.

Added support for lazy image pixel data reading and frame by frame decoding
(i.e. read frame on demand)

Added samples to show usage of getting a frame from multi-frame image.

Added support for frame level retrieval for COMPOSITE_INSTANCE_ROOT_RET_MOVE and
COMPOSITE_INSTANCE_ROOT_RET_GET service classes in sample programs.

Integrate Pegasus library version 2.00.636 into toolkit.

Added allowance of MONOCHROME J2K decompression to ignore signed pixel representation.

Added support for Windows 8 and Windows Server 2012.
 

 
Updates in Version 4.7.0
========================

Fixed internal reallocation of a 40 byte block to a 64 block that causes memory corruption
when triggered by MC_Reset_Filename.

Fixed implementation of Supplement 74 and 96.

Fixed validation code that fails to catch ISO-IR 6 character out of range issue.

Fixed validation code error in some cases that are conditional on other attribute's value.

Fixed mc3icomb that fails to merge new attributes into an existing item.

Fixed MC_Free_File/MC_Free_Message to report error when a SR object is passed in.

Fixed PN value representation length validation to respect multiple component groups.

Fixed memory leak when LARGE_DATA_STORE is set to FILE and data set is big endian.



Enhancements in Version 4.6.0
=============================

Made changes to the data dictionary to address the following change proposals:

 1095, 1128, 1131, 1132, 1133, 1134, 1135, 1136, 1139, 1140, 1141, 1142, 1143, 
 1144, 1145, 1146, 1147, 1149, 1150, 1151, 1154, 1156, 1157, 1158, 1159, 1160, 
 1161, 1162, 1165, 1166, 1167, 1168, 1169, 1170, 1172

Note:
 No new DICOM supplements were approved since version 4.5.0.

Added default value setting for the meta info (group 0002 elements) prior to 
writing to Part 10 file.

Extended validation code to catch invalid (extended) characters used instead of 
the expected default repertoire and issue warning.

Added SR high level API to handle SCOORD3D content item.

Created VS solution and individual project files for the samples in the 
distribution.



Updates in Version 4.6.0
========================

Fixed issue where the RLE decompressor attempts to decode invalid padding bytes 
at the end of the segment.

Added missing attributes to the Patient Demographic Module:
 (0010,1010) Patient's Age 
 (0010,2180) Occupation 
 (0040,3001) Confidentiality Constraint on Patient Data Description 



Enhancements in Version 4.5.0
=============================

Added support for the following DICOM Supplements to the data dictionary:

 139 Enhanced XA/XRF IOD Informative Annex
 148 WADO via Web Services
 150 Radiation Dose Summary Information in Radiology Reports
 151 Intravascular OCT Image Storage SOP Class 
 152 Ophthalmic Thickness Map Storage SOP Class 
 153 Blu-ray Disc Media Application Profiles


Made changes to the data dictionary to address the following change proposals:

 993, 994, 1038, 1039, 1041, 1042, 1047, 1062, 1064, 1079, 1085, 1089, 1090,
 1091, 1092, 1093, 1094, 1096, 1097, 1098, 1099, 1100, 1101, 1102, 1103, 1104, 
 1107, 1109, 1110, 1111, 1113, 1114, 1116, 1117, 1118, 1119, 1120, 1121, 1122, 
 1124, 1125, 1129, 1130 
 
Added support for dual stack mode IPV6 listener. IP_TYPE sets to IPV6 will only
allow IPV6 connections. IP_TYPE sets to AVAILABLE in SCP will allow dual mode
(IPV4 and IPV6 connections) if platform supports it. IP_TYPE sets to AVAILABLE in
SCU will use IPV4 or IPV6 if it is enabled in platform.
(Note: For Windows platform, only Vista or higher supports IPV6 dual stack.
Solaris 8 is always in dual stack mode when IPV6 is set for listener)
 
 
Updates in Version 4.5.0
========================

Fixed image corruption when MC_Duplicate_Message is JPEG-compressing a 
RGB multiframe image with UPDATE_GROUP_0028_ON_DUPLICATE turned on.

Fixed missing definitions for JPIP transfer syntax.



Enhancements in Version 4.4.0
==================================

Added support for the following DICOM Supplements to the data dictionary:

 131 Bone Mounted Implant Description Storage SOP Class
 134 Implantation Plan SR Document Storage SOP Class
 142 Clinical Trial De-identification Profiles
 145 Whole Slide Imaging in Pathology
 149 MPEG-4 AVC/H.264 Transfer Syntax

Made changes to the data dictionary to address the following change proposals:

 768, 797, 952, 970, 979, 1036, 1037, 1040, 1043, 1044, 1048, 1049, 1050,
 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1063,
 1065, 1067, 1069, 1070, 1072, 1073, 1074, 1076, 1078, 1080, 1081, 1082,
 1084, 1087
 

 
Updates in Version 4.4.0
==================================

Fixed issue where OBOW_BUFFER_SIZE set too low can limit size of pixel data
supported.

Fixed issue where private attributes are templated/validated incorrectly.

Fixed DICOM validation errors.

Removed in-place byte swapping when LARGE_DATA_STORE = FILE which makes the
application supplied buffer non-reusable.

Fixed mpeg2dicom sample compiler errors.

Implemented support for compression of images with color-by-plane planar
configuration.

Removed dependencies of compiled configuration on files that are not
part of the distribution.

Fixed wrong attribute type in the database for Segmentation Fractional Type
(0062,0010) (1 instead of 1C).

Fixed crash when application is disposed while association request is pending.



Enhancements in Version 4.3.0
==================================

Added support for the following DICOM Supplements to the data dictionary:

 95  Audit Trail Messages
 118 Application Hosting
 120 Extended Presentation States
 135 SR Diagnostic Imaging Report Transformation Guide
 144 Ophthalmic Axial Measurements Storage SOP Class
 146 Ophthalmic Visual Field (OPV) - Static Perimetry Measurements Storage SOP Class

Made changes to the data dictionary to address the following change proposals:

 463, 709, 729, 890, 997, 1001, 1004, 1007, 1008, 1009, 1010, 1011, 1012, 
 1014, 1015, 1016, 1017, 1018, 1020, 1021, 1023, 1024, 1025, 1026, 1027, 
 1028, 1029, 1033, 1034, 1035, 1045

Updated Pegasus libraries to version 2.595.

Added support for JPEG-LS compression.

Corrected the definition of the BREAST_TOMO_IMAGE_STORAGE C_STORE_RSP message.

Updated configuration file to use undefined length as default sequence encoding.

Improved Specific Character Set (0008,0005) attribute handling and validation of 
the encoded strings.

Changed MC_Get_Value_To_Buffer to work for pixel data tags.

Removed unused Items from the database and replaced ICON_IMAGE with the 
IMAGE_PIXEL_MACRO item.



Updates in Version 4.3.0
==================================

Fixed DICOM to XML conversion of the empty attributes.

Fixed exception caused by the Encapsulated icon pixel data.

Added a sample code for the MPEG-2 compression/decompression.

Fixed crash in MCI_StreamToMessage with private creator string longer than 200 bytes.
 
Fixed problem with adding many items to the DICOMDIR record will overrun the stream 
buffer.

Updated DICOM validation condition that checks for the Patient Orientation Code 
Sequence (0054,0410) presence. 

Fixed stack overrun in MCI_SetAttribute() on 64bit platforms.

Fixed potential problems with reuse of Entity IDs and Application IDs if the number 
will roll over the maximum.

Fixed problems with YBR_FULL_422 compression handled incorrectly during conversion.

Fixed race condition problem with MC_OpenAssociation.



Enhancements in Version 4.2.0
=============================

Added support for the following DICOM Supplements to the data dictionary:
 
    140, XA/XRF Grayscale Softcopy Presentation State Storage SOP Class
    143, SR Template for Reporting of Macular Grid Thickness and Volume
    78,  Pediatric, Fetal and Congenital Cardiac Ultrasound Reports
 
Made changes to the data dictionary to address the following change proposals:
    238, 650, 835, 850, 904, 905, 909, 913, 930, 931, 942, 947, 951, 953, 954, 955, 
    956, 957, 958, 959, 960, 963, 964, 965, 966, 967, 968, 969, 971, 972, 973, 974, 
    975, 976, 978, 980, 981, 982, 983, 984, 985, 986, 988, 989, 990, 995, 996, 998, 
    999, 1000, 1002, 1003
 
Updated the data dictionary to address various changes in the DICOM standard,
as follows:
  - Renamed element (0020,930F) from 'Plane Orientation (Volume) Sequence'
    to 'Plane Orientation (Volume) Sequence'
  - Changed the tag numbers that were revised in Supp 117 after it had been
    integrated into the toolkit (version 3.9). The following tags were 
    changed from group 28 to group 18: (0018,9758), (0018,9759), (0018,9760),
    (0018,9761), (0018,9762), (0018,9763), (0018,9764), (0018,9765), (0018,9766),
    (0018,9767).
  - Deleted element (0018,9757) which was defined in the first version of Supp 117,
    but was removed in version 2.
  - Renamed (0062,0002) from 'Segmentation Sequence' to 'Segment Sequence'. The 
    change is done based on Supp 111 and the fact that in the Supp 147 (currently 
    in 'Work' status) the name 'Segmentation Sequence' will be used for another 
    attribute (30xx,082A).
  - Renamed (0066,0015) from 'Number of Points' to 'Number of Surface Points'
    (CP 959)
  - Renamed (0018,0029) from 'Intervention Drug Sequence' to 'Intervention Drug 
    Code Sequence'
  - Renamed (0100,0420) from 'SOP Authorization Date and Time' to 'SOP 
    Authorization DateTime'
  - Renamed (0018,9360) from 'CT Multiple X-Ray Source Sequence' to 'CT 
    Additional X-Ray Source Sequence' (CP 765, version 3) 
  - Renamed (0040,4040) from 'Retain Raw Data' to 'Raw Data Handling' (CP 943, 
    the CP was revised and the name was changed)
  - Renamed (0040,4005) from 'Scheduled Procedure Step Start Date and Time' to 
    'Scheduled Procedure Step Start DateTime'
  - Renamed (0040,4011) from 'Expected Completion Date and Time' to 'Expected 
    Completion Date Time'
  - Renamed (0018,1019) from 'Secondary Capture Device Software Version(s)' to 
    'Secondary Capture Device Software Versions'
  - Renamed (0018,9195) from 'Chemical Shifts Minimum Integration Limit in Hz' 
    to 'Chemical Shift Minimum Integration Limit in Hz'
  - Renamed (0018,9196) from 'Chemical Shifts Maximum Integration Limit in Hz' 
    to 'Chemical Shift Maximum Integration Limit in Hz'
  - Renamed (0018,9295) from 'Chemical Shifts Minimum Integration Limit in ppm' 
    to 'Chemical Shift Minimum Integration Limit in ppm'
  - Renamed (0018,9296) from 'Chemical Shifts Maximum Integration Limit in ppm' 
    to 'Chemical Shift Maximum Integration Limit in ppm'
  - Renamed (0020,0026) from 'Lookup Table Number' to 'LUT Number'
  - Renamed (0028,6022) from 'Frame(s) of Interest Description' to 'Frame of 
    Interest Description'
  - Renamed (0040,B020) from 'Annotation Sequence' to 'Waveform Annotation 
    Sequence'
  - Renamed (0074,1002) from 'UPS Progress Information Sequence' to 'Unified 
    Procedure Step Progress Information Sequence'
  - Renamed (0074,1216) from 'UPS Performed Procedure Sequence' to 'Unified 
    Procedure Step Performed Procedure Sequence'
  - Renamed (0074,1246) from 'UPS List Status' to 'Unified Procedure Step List
    Status'
  - Changes to SOP Class UID's related to corrections in Supp 133 that were done 
    after it was released and integrated into the toolkit version 4.0. New SOP 
    instances were added in Supp 133 (version 1) with wrong UID's 
    (e.g. 1.2.840.10008.39.1 instead of 1.2.840.10008.5.1.4.39.1). The list of 
    corrected UID's as per Supp 133 version 2 is:
        �1.2.840.10008.39.1� to �1.2.840.10008.5.1.4.39.1�
        �1.2.840.10008.39.2� to �1.2.840.10008.5.1.4.39.2
        �1.2.840.10008.39.3� to �1.2.840.10008.5.1.4.39.3� 
        �1.2.840.10008.39.4� to �1.2.840.10008.5.1.4.39.4
 
 
 
Added MC_SRH_... functions for easy manipulation of Structured Reports.
 
Added enhanced DICODMIR management functions (MC_DDH_..) supporting "on-demand"
reading of directory records and incremental modifications to the record 
hierarchy.
 
Added functions that allow the application to specify the name or IP address 
of the network interface to listen on, so association can be accepted only on
specific network interfaces instead of any available interface.
 
Enhanced MC_Write_File... functions to automatically set the File Meta 
Information Version (0002,0001) attribute if not set by the application.
 
Added two new functions, MC_Message_To_XML and MC_XML_To_Message, that allow
streaming DICOM data to/from XML.
 
Added support for skipping a specified set of elements when decoding DICOM data.
The DECODER_TAG_FILTER configuration item can be used to specify a decoding 
attribute filter.
 
Added support for DICOM element keywords as defined in CP 850. The 
MC_Get_Tag_Keyword function can be used to obtain the keyword for a standard data 
element defined in the toolkit's DICOM dictionary.
 
Added support for setting default role selection to MC_NewService... functions
(i.e. association requester is SCU and association acceptor is SCP).
 
Changed MC_Get_Version_String function to return the toolkit's version even 
when the toolkit is not initialized.
 
Removed bufferoverflowU.lib linker dependency from the 64-bit Windows sample 
application makefile.

Updated MC_Get_Value_To_String to increase the precision of the value returned
for attributes with FL value representation.


Updates in Version 4.2.0
========================

Fixed a problem on Windows platforms that caused the toolkit to incorrectly 
resolve the location of the configuration files specified in merge.ini when the
path was relative to the initialization file and it contained "./".
 
Fixed the compression library's hardcoded location in the mc3conv utility on
Unix platforms. 
 
Fixed a problem that caused a crash when receiving certain malformed PDU data.
 
Fixed the decoder to properly decode unknown sequences encoded with implicit
VR inside data encoded with explicit VR.
 
Fix for Solaris platforms to properly report the remote host name for received
associations when the connection is made on IPV6.
 
Fixed a problem that could cause duplicate association identifiers being 
returned by the toolkit after processing more than 21000 associations while
the first association was still active. 
 
Fixed a crash in MC_Open_Association when the remote port number argument was 
greater than 9,999,999.
 
Fixed a small memory leak associated with extended negotiation information in
dynamically created service lists.
 
Changed the validation of the value's length when setting attribute values with 
LO, LT, PN, SH and ST value representation, to take into account character sets 
with multiple bytes per characters and escape sequences.
 
Fixed a problem that caused the wrong error status when decoding datasets with
an incorrect length of a fixed length attribute. Now the toolkit returns 
MC_INVALID_LENGTH_FOR_VR.
 
Fixed the list of Defined Terms for the Specific Character Set Attribute 
(0008,0005) in all modules to have the full list of the specific character sets
that are currently defined by DICOM.
 
Fixed some build warnings in the sample applications.
 
Fixed Media FSU sample application to use the transfer syntax of the received
instance when saving the instance to file.
 
Fixed Q/R SCP sample application to respond with the correct reject reason when
the called Application Entity Title is incorrect.

Fixed incorrect element names in the toolkit's DICOM database. See the list of
data dictionary updates below for more information on these changes.

Fixed a definition of the list of attributes for the REQUEST_ATTRIBUTES item 
in the message.txt file.



Updates in Version 4.1.0
==================================

Fixed a crash in MC_Get_Next_Encapsulated_Value_To_Function() call when
no MC_Get_Encapsulated_Value_To_Function() was called first.

Fixed the incorrect printing of extended negotiation information in T3 log
messages.

Fixed an issue that could cause MC_Cleanup_Memory to free up less memory than
it could.

Fixed a problem in MC_Set_Next_Value_From_String() that resulted in the wrong
value count when the value set was an empty string ("").

Fixed some errors and inconsistencies in the Reference Manual and the User's
Manual.

Changed the decoder to correctly deal with unknown length sequences attributes 
that have UN value representation. Previously the toolkit failed to decode such
attributes if they were defined in the data dictionary.

Fixed MC_Set_Value_From_Buffer() to reject uneven length buffers for VR's that
do not have a padding defined.

Fixed an issue on Linux platforms that caused memory corruption when accepting 
or requesting associations while the process had more than 1024 file descriptors
open.

Fixed a crash that occurred when AUTO_ECHO_SUPPORT was enabled and two echo
requests were received in parallel.

Removed a limitation that caused the toolkit to reject setting more than 
2^16 values for an attribute.
 
Fixed a problem that resulted in incorrect encoding after changing the VR of an
attribute from OW to US.


Enhancements in Version 4.1.0
==================================

Added support for the following DICOM Supplements to the data dictionary:
    43, Storage of 3D Ultrasound Images
    119, Instance and Frame Level Retrieve SOP Classes
    126, Colon Computer-Aided Detection SR SOP Class

Made changes to the data dictionary to address the following change proposals:
    750, 844, 849, 870, 875, 889, 895, 922, 923, 924, 925, 928, 932, 933, 935,
    936, 937, 938, 939, 940, 943, 945, 948, 949, 950  
    
Added support for all valid reject reasons in MC_Reject_Association(). 

Added support to limit the size of the printed values for the output of
MC_List_Message() and T2 logging. This feature is configurable through the 
following configuration parameters in mergecom.pro: LIST_VALUE_LIMIT, 
LIST_SQ_DEPTH_LIMIT and LIST_UN_ATTRIBUTES.

Added support for specifying paths relative to the initialization file for
the location of the configuration files in merge.ini.

Changed the code to tolerate reading DICOMDIR files that have the Referenced 
Lower-Level Directory Entity (0004,1420) attribute missing or empty in IMAGE
records.

Added sample applications for C-GET SCU and SCP services.



Updates in Version 4.0.0 IB1
=============================

Fixed an issue in which tabs in the mergecom.app file could lead to
MC_Open_Association() returning MC_CONFIG_INFO_MISSING.

Fixed a crash in MC_Delete_Current_Value() if MC_Get_Next_Value_To_Int() had
previously been called repeatedly to, for example, traverse the items in a
sequence, and finally returned MC_NO_MORE_VALUES.

Fixed an issue where MC_RLE_Compressor/Decompressor did not support the
photometric interpretation YBR_FULL.

Fixed an issue in MC_RLE_Decompressor() in which some multi-byte pixel
images (16-bit or RGB) failed to decompress.

Fixed an issue in which the Group 0 Length Element was generated only when
EXPORT_GROUP_LENGTHS_TO_NETWORK was turned on. This Element is now always
generated.

Fixed an issue on Linux introduced in 3.9.0 in which MC_Read_Message() would
always wait for one second irrespective of the timeout parameter passed in.

Fixed an issue in which MC_Open_File() would crash for some DICOMDIR files when
DICOMDIR_STREAM_STORAGE was turned on.

Fixed an issue introduced in 3.8.0 IB2 (secure buffer manipulation) in which
MC_List_File() would produce repeated blocks of hex output for the Part 10 File
Prefix.

Enhancements in Version 4.0.0 IB1
==================================

Added support for the following DICOM Supplements to the data dictionary:
    123, Structured Display
    125, Breast Tomosynthesis Image Storage SOP Class
    128, Cardiac Stress Testing Structured Reports
    132, Surface Segmentation Storage SOP Class
    133, Color Palette Storage, Query and Retrieval
    137, MPEG2 MP@HL Transfer Syntax
    141, Enhanced MR Color Image Storage SOP Class

Made changes to the data dictionary to address the following change proposals:
    363, 568, 817, 832, 837, 850, 851, 853, 854, 855, 856, 857, 858, 859,
    860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 871, 872, 873, 874,
    876, 877, 878, 879, 880, 881, 882, 883, 884, 885, 886, 887, 888, 892,
    893, 894, 897, 898, 899, 900, 901, 902, 903, 907, 908, 910, 911, 912,
    914, 915, 916, 917, 918, 919, 920, 921, 926

Turning on the T1_MESSAGE configuration option will now cause detailed memory
usage reporting to be logged when MC_Report_Memory() is called.

Updates in Version 3.9.2 IB1
=============================

Fixed an issue in which calling MC_Abort_Association() from one thread could
crash when another thread attempted to continue processing a message on the
same association.

Fixed a crash that occurred when validating or creating a message or file object
for a service and command that had private attributes defined.

Updates in Version 3.9.1 IB1
=============================

Updates when porting to 64-bit Solaris 10 on Intel.


Updates in Version 3.9.0 IB6
=============================

Fixed an issue introduced in 3.8.0 IB2 (secure buffer manipulation) in
which the log file could not be accessed by any viewer while the application
was running.

Fixed MC_Set_Value_Representation so that large LUTs (>64kb) encoded as VR US
in Implicit VR Transfer Syntax can be reset to OW in order to be valid for
re-encoding in Explicit VR.

Fixed file writing to not pass the first 132 bytes separately, in order to
prevent files from being written in two fragments on Windows regardless of
the value of the WORK_BUFFER_SIZE option.

Fixed an issue in which UT (unlimited text) attributes larger than
OBOW_BUFFER_SIZE would be split into multiple values when LARGE_DATA_STORE
was FILE.

Fixed an issue in which odd size frames were being padded by the built in
Standard and RLE decompressors.  The correct approach, according to DICOM,
is to pad the entire Pixel Data attribute if the pixels are 8-bit and the
number of rows, columns, and frames are all odd.

Fixed an issue in which the RLE decompressor would crash if the image was
multiframe with no offset table and, according to DICOM, one of the compressed
frames was padded to achieve even length.

Fixed the listing of Pixel Data attribute VR to list the actual VR instead of 
OW. This fix affects all MC_List... calls and mc3list utility.

Changed association negotiation to abort the association if an unknown
transfer syntax is detected by the requester in an association response.

Fixed an issue that caused MC_Abort_Association to have no effect if another
thread was waiting for a message on the association.

Fixed an issue that caused MC_FreeService to return MC_SERVICE_IN_USE even if 
the service was not in use. This happened if another service with the same SOP 
class and transfer syntax list was used by a service list object.

Fixed the documentation for MC_Register_Application that incorrectly listed
MC_NO_LICENSE and MC_INVALID_LICENSE as possible return values.

Fixed info.pfl for missing attributes and other minor typos.

Fixed division by zero issue when the Number Of Frames attribute had a value
of zero. Now the toolkit tolerates such values and assumes that the pixel data
has one frame.

Fixed a problem with Patient level moves in the Query/Retrieve provider sample
application.  Also, filtering added to remove duplicates from Patient level
query results. 

Enhancements in Version 3.9.0 IB6
=================================
Added support for the following DICOM Supplements to the data dictionary:
    117, Enhanced PET Image Storage SOP Class
    122, Specimen Identification and Revised Pathology
    130, Ophthalmic Refractive Structured Reports

Made changes to the data dictionary to address the following change proposals:
    128, 725, 767, 769, 781, 800, 801, 803, 805, 806, 807, 808, 809, 810,
    815, 816, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829,
    830, 831, 834, 839, 840, 841, 842, 843, 845, 846, 847, 848

Added more 1C and 2C type condition checks to validation.

Improved validation performance and significantly reduced the overhead 
associated with validation.

Integrated the latest Pegasus libraries. Now the toolkit distributes with
Pegasus version 2.00.559.

Updates in Version 3.8.0 IB6
=============================

Fixed an issue in MC_List_Message when printing hex views of unprintable
characters in attribute values, causing mc3list to terminate - from an
exception on Windows and as assert on Solaris.

Fixed a synchronization issue that could cause MC_Open_Association to fail if 
multiple threads were creating or updating the remote application object 
information simultaneously.

Fix to allow MC_Duplicate_Message to duplicate a message with attribute
that contains empty value.

Fixed memory leak when decompressing a 10 bit grayscale JPEG_EXTENDED_2_4
image.

Updates in Version 3.8.0 IB5
=============================

Fixed MC_Set_Value_Representation to allow an unknown VR attribute with empty 
value to change to other VR.

Fixed a synchronization issue that could have caused memory corruption when, in
the same application, an SCU and an SCP used the same service list and 
requested/received multiple associations at the same time.

Updates in Version 3.8.0 IB4
=============================

Fixed a problem introduced in 3.8.0 IB2 that caused a C-language character
string terminator (NULL) to appear in AE Titles during association negotiation,
causing problems when communicating with some implementations, including ADVT.

Fixed a crash in MC_FreeSyntaxList that occurs when the application creates 
and frees a custom transfer syntax list without creating a service list.

Fixed small memory leaks associated with custom transfer syntax list objects 
and application objects.

Fixed a problem that prevented the toolkit to receive N-EVENT_REPORT messages
for the Unified Procedure Step service.

Updates in Version 3.8.0 IB3
=============================

Fixed defect where JPEG 2000 compressed image without offset table and
less than 2K per frame was not decompressed properly.

Fixed a problem introduced in the previous release that causes mc3icomb 
utility to hang.

Enhancements in Version 3.8.0 IB2
=================================
Added support for the following DICOM Supplements to the data dictionary:
     74, Utilization of Worklist in Radiotherapy Treatment Delivery ( Frozen 
         Draft for Trial Implementation, 2007/10/08 )
     96, Unified Worklist and Procedure Step ( Frozen Draft for Trial Use,
         2007/10/08 )
    107, Verification of Substance Administration and Substance Information Query
    110, Ophthalmic Coherence Tomography (OCT) Storage SOP Class
    114, DICOM Encapsulation of CDA
    116, 3D X-Ray

Made changes to the data dictionary to address the following change proposals:
    617, 665, 668, 670, 681, 683, 684, 685, 688, 692, 695, 698, 699, 703,
    710, 715, 716, 720, 721, 727, 734, 744, 747, 748, 749, 754, 755, 763,
    764, 766

Integrated the latest Pegasus libraries and added support for dispatcher 
registration code setting. This fixes a crash that happens when using Pegasus
libraries on Windows Server 2003 with DEP (Data Execution Prevention) turned 
on.

Changed MC_Standard_Compressor and MC_Standard_Decompressor to allow lossless
Jpeg compression/decompression of images with the number of bits stored between 2
and 16. Previously only images with bits stored of 8, 10, 12 and 16 were accepted.

Added the current thread ID to the name of temporary files created on Windows.

On Windows platforms, changed calls to C Runtime buffer manipulation routines 
to their equivalent secure versions. Note that now the static version of the
toolkit is dependent on versions of the Microsoft C Runtime that implement 
these secure routines (MS Visual Studio 2005 or later).

Added a new function MC_Thread_Release() that can be called by the application
to release resources allocated for a specific thread. This call is needed to 
avoid a memory leak on Linux and Unix platforms with Pegasus compressor when
using with multiple threads.

Added synchronization to MC_Cleanup_Memory() to avoid memory corruption when
applications call MC_Cleanup_Memory() from different threads.

Sample application prnt_scu (prnt_scu.c) now accepts media type files.

Defects resolved in Version 3.8.0 IB2
=====================================

Fixed problem in which MC_Get_Next_Value_To_String() returned MC_NO_MORE_VALUES 
when retrieving key attributes in DICOMDIR records after sorting the DICOMDIR 
with MC_Dir_Sort().

Fixed crash when private services were defined having more than 35 characters.

Fixed problem in the breakup of bulk attributes for storage in memory that
led to the error message "Odd length buffer passed to FlushStreamBuffer".

Fixed a problem in validation that resulted in MC_MSGFILE_ERROR status being 
returned when element 0 in a private block was defined in the dictionary.

Fixed mc3icomb utility for missing items in the output when more than one 
item was specified in the [EXISTING_ITEM_SECTION] of the configuration file. 

Fixed linear/circular buffer interfacing with Pegasus library to resolve 
Pegasus related decompression problems. The toolkit previously had some 
inconsistent usage of the linear/circular buffer interfacing with the Pegasus 
library, which resulted in unsuccessful decompression of JPEG images. Some 
cleanups were also made to simplify buffer management when interfacing with 
the Pegasus library. 

JPEG encapsulated images with extra padding at the end of each fragment would 
previously cause the parser to fail decoding and return an error.

Fixed problem where an association abort from the remote peer was not accurately
reported by MC_Read_Message(); the status returned was MC_NETWORK_SHUT_DOWN.
MC_Read_Message() now returns MC_ASSOCIATION_ABORTED in this situation.

Fixed several problems in the Query/Retrieve SCP and SCU sample applications 
that resulted in zero matches for image level queries and a memory corruption
when executing queries with date or date range matching.


Updates in Version 3.7.0 IB14
=============================

Changed the way synchronization is handled to avoid frequent creation and 
deletion of synchronization objects and to avoid potential memory issues 
after calling MC_Library_Release().


Updates in Version 3.7.0 IB13
=============================
Fixed defect where the log file was not backed up properly when it became
full, even though LOG_FILE_BACKUP was configured ON.  The actual behavior
of this backup varied from platform to platform.  On Windows it did not
work at all.  Log file backup worked during library initialization only.


Updates in Version 3.7.0 IB12
=============================
Fixed defect related to private attributes that were not assigned to the 
first private block in a private group.  The MC_Get_pValue_... related
functions were returning that the tags did not exist in the message.

Fixed defect where when the T2 level logging was enabled, the 
MC_Get_Next_... routines would not properly return the first value of a 
tag within a message received over the network.

Resolved problem with the mergecom.pro file where the JPEG 2000 Multi-
Component transfer syntax UIDs were entered improperly.

Updated the PDF documentation to have bookmarks.

On Windows, removed the dependency introduced within 3.7.0 to the 
msvcr71.dll DLL file.  The mc3adv.dll file is now compiled with the /MT
option so that the contents of the C runtime is compiled into the DLL
file.  The DLL file has increased in size because of this change.


Updates in Version 3.7.0 IB11
=============================
Fixed defect with MC_Read_Message_To_Tag that would cause subsequent problems
with MC_Continue_Read_Message or MC_Continue_Read_Message_To_Stream.  When 
receiving Implicit Little Endian data, and a PDU was received where the last
data in the PDU was the tag length of the stop tag passed to 
MC_Read_Message_To_Tag, the function would not save the tag and length
for subsequent calls, and would cause a parsing failure.


Updates in Version 3.7.0 IB10
=============================
Final updates for the MacOS X on Intel toolkit.


Updates in Version 3.7.0 IB9
============================
Further updates for IRIX6.5.

Resolved defect with MC_Send_Response_Message.  When MergeCOM-3 was unable to
automatically set the Message ID Being Responded To tag, a semaphore was not
being released properly and other subsequent calls to network functions
would freeze and never return.   This would only occur on platforms that
support threading.

Fixed memory leak with MC_Wait_For_Connection and
MC_Wait_For_Connection_On_Port when they were called with a timeout other than
-1 and the function returned a value other than MC_NORMAL_COMPLETION.

Fixed memory leak with the T2 logging level.

Fixed defect with MC_Duplicate_Message where it didn't work properly when
making a copy of a compressed image.  In this case no decompressors were
registered, and the destination transfer syntax was the same as the source
transfer syntax. The encapsulation of image was being corrupted.


Updates in Version 3.7.0 IB8
============================
Updates when porting to IRIX 6.5 and HP-UX 11.


Updates in Version 3.7.0 IB7
============================
Updates when porting to Solaris 8 and updates for the Java Wrapper.


Updates in Version 3.7.0 IB6
============================
Updates when porting to Borland C++ Builder 2006 and 64-bit Windows.


Enhancements in Version 3.7.0
=============================
Added support for the following DICOM Supplements to the data dictionary:
    111, Segmentation Storage SOP Class
    112, Deformable Spatial Registration Storage SOP Class

Made changes to the data dictionary to address the following change proposals:
    457, 526, 550, 553, 554, 572, 574, 576, 578, 579, 582, 586, 587, 589,
    593, 599, 600, 610, 611, 614, 615, 616, 618, 627, 628, 642, 643, 649,
    651, 652, 655

Added support for IPv6 connections on operating systems that support IPv6.
The IP_TYPE configuration option has been added to control how IPv6 is
supported within MergeCOM-3.  When this option is set to IPV4, MergeCOM-3 will
attempt to only listen for IPv4 connections and will only use IPv4 addresses
when connecting to a remote system.  When IPV6 is configured for this option,
MergeCOM-3 will only attempt to use IPv6 for network communications.  When
AVAILABLE is configured, MergeCOM-3 will attempt to listen or connect with the
IPv4 or IPv6, depending on what is available.

Note that IPv6 IP addresses can be passed as a parameter to MC_Open_Association
or configured in the mergecom.pro file.  When a hostname is configured,
MergeCOM-3 will attempt to resolve this hostname to an IP address according to
the setting of the IP_TYPE configuration option.

As part of support for IPv6, changes were made in the
MC_Register_Network_Capture_Callbacks function.  Specifically, all callback
functions that included network addresses as their parameters have been changed
to use struct sockaddr pointers as the addresses.  Previously we used an
unsigned long to represent an IP address and an unsigned short to represent a
port.

Made some small performance improvements in various parts of the library after
profiling the library's network performance.

Added new FREE_DATA callback for Callbacks registered with
MC_Register_Callback_Function.  When the new USE_FREE_DATA_CALLBACK
configuration option is set to Yes, callback functions will be called with the
FREE_DATA parameter when the message that is associated with the callback is
freed by the library.

The Query/Retrieve SCP (qr_scp.c) sample application has been updated.  This
server is now a functional Query/Retrieve SCP server (as opposed to the
previous version which used fake data).  The application can receive C-STORE-RQ
messages, store them locally, and then respond to C-FIND-RQ and C-MOVE-RQ
messages properly based on the images its received.

Added support for DICOM Supplement 99, User Identity negotiation.  Several new
functions have been added to the library related to User Identity Negotiation:

    MC_Open_Association_With_Identity
    MC_Accept_Association_With_Identity
    MC_Get_User_Identity_Info
    MC_Get_User_Identity_Length

In addition, the AssocParms structure returned by MC_Get_Association_Info has
been extended to include user identity related information.  See the Reference
Manual for a complete description of these functions.  Finally, the Storage SCU
and SCP sample applications have been modified to show how to implement these
functions.

Updated the default maximum PDU size and the default TCP/IP send and receive
buffer sizes in the mergecom.pro file.  The maximum PDU size and TCP/IP Send
and receive buffer sizes are now set to a multiple of the TCP/IP MSS (maximum
segment size) of 1460 bytes in an effort to increase performance.  See the
frequently asked questions of the User's Manual or the discussion of the various
MergeCOM-3 configuration options in the Reference Manual for further details.

Added new configuration option, UPDATE_GROUP_0028_ON_DUPLICATE.  When set to
Yes, MergeCOM-3 will automatically update the group 0x0028 elements with a
duplicated message or file.  The Photometric Interpretation, Lossy Image
Compression, Lossy Image Compression Ratio, and Lossy Image Compression Method
tags will be updated if appropriate.  Note that on lossy compression, a new SOP
Instance UID may still need to be updated by the application.

Added the duplicate.c sample application as part of the distribution on all
platforms.  This can now be used with RLE compression on all platforms.


Defects Resolved in Version 3.7.0
=================================
Resolved defect introduced in the 3.6.0 release where in some cases the
MC_Send_Request_Message, MC_Send_Response_Message, and MC_Read_Message
routines were incorrectly returning MC_SYSTEM_ERROR on threaded platforms when
an association was aborted.  These routines will now return
MC_ASSOCIATION_ABORTED.

Addressed a problem where MergeCOM-3 could not read DICOM Part 10 format files
that had the incorrect value for Group 0x0002 length encoded in them.  We can
parse this type of file.

Removed a misleading log line from the log file when  MC_NewSyntaxList is
called.  Previous versions would display an error message that the syntax list
 being created by this routine could not be found.

Fixed two small memory leaks with MC_Duplicate_Message that totaled around 100
bytes.  The leak would occur when duplicating a message that had tags encoded
after the pixel data tag.

Fixed problem with MC_RLE_Compressor where it did not work with RGB images that
were an odd image size (and contained a padding byte).  These were 8 bit images
that have an odd value for both rows and columns.

Fixed small memory leak with the MC_Continue_Read_Message_To_Stream function.

Fixed problem with the COMPRESSION_RGB_TRANSFORM_FORMAT configuration option.
The option was not being read properly from the mergecom.pro file.

Resolved issue with the Storage SCU sample application where it could not
transfer more than 32000 images at one time due to how it tracked when a
response message was received.

Fixed data dictionary issue where the DIR_REC_IMAGE directory record did not
allow setting of the Frame of Reference UID.  Also added several other tags
that could not be set that should have been allowed.

Added fix where MC_List_Message/MC_List_File was not displaying FL/FD attributes
properly.  These values were displayed as longs, and thus did not display the
precision of the numbers.

Fixed problem with the Borland compiled Windows toolkit where standard
compressors and decompressor was not exported from the DLL properly.

Fixed problem with Borland compiled Windows toolkit where MC_List_Message/
MC_List_File would not display output properly when using the DLL.

Fixed problem with MC_Standard_Compressor where if we encountered an image
where the pixel data attribute was too small, we would fail silently instead
of logging an error.  We now log an error when encountering this situation.

Fixed problem where the attribute immediately preceding a private attribute when
a message that was read into MergeCOM-3 could not be retrieved with a call to
one of the MC_Get_Next_Value routines.  One of the MC_Get_Value routines would
have to be called first.

Fixed problem where the MC_Validate_Message routine would not work properly
when pixel data was contained within a registered callback function.

Changed MC_Register_Compression_Callbacks to return MC_INVALID_MESSAGE_ID
instead of MC_SYSTEM_ERROR when it is called with an invalid message ID.



Updates in Version 3.6.1 IB4
============================
Updated the Storage SCU service list to include all available Storage
services.

Modified the Maximum PDU size and the TCP/IP buffer sizes in the mergecom.pro
file to match with the MTU size in order to increase performance.

Made updates in how the enhanced memory log callback function is declared
for the .NET toolkit.

Made a first round of general improvements to the Query/Retrieve SCP sample
application.



Updates in Version 3.6.1 IB3
============================
Added new routines, MC_Set_Value_From_Buffer and MC_Set_pValue_From_Buffer
for setting UN VR attributes or OB/OW/OF attributes.  These routines
can be used in place of MC_Set_Value_From_Function to encode pixel data
from a single buffer.  See the mc3msg.h file for the prototype of these
functions.

Fixed memory leak with MC_Continue_Read_Message_To_Stream().



Updates in Version 3.6.1 IB2
============================
Minor updates for MacOS X on Intel/PowerPC.

Added additional logging statement to give error information when opening the
data dictionary file fails.

Fixed problem in the Query/Retrieve SCP sample application where we were
leaking a handle each time a C-FIND-RQ was processed.

Resolved problem where validation of messages was not working properly when
a registered callback function was used to manage pixel data.

Resolved problem related to calling MC_Duplicate_Message on a file object.
MC_Duplicate_Message should now work properly when working with file objects.



Known Issue in Version 3.6.1 IB1
================================
On Linux and Solaris systems, when using multiple threads with the standard
compressor or decompressor, there is a memory leak.  The problem only occurs
on these operating systems when using multiple threads.  Specifically, there
is a Pegasus routine that should be called to release resources associated
with a thread before that thread terminates.  The following is a prototype of
the Pegasus function:

    extern void PegasusLibThreadTerm(void);

This Pegasus function should be called directly from any Linux or Solaris
application where the standard compressor is called from a thread which later
exits.  The call should be made from the thread before it exits.  In a future
release, a new MergeCOM-3 function will be introduced so applications do not
have to call this Pegasus function directly.



Enhancements in Version 3.6.1 IB1
=================================
Updates to introduce the Pegasus libraries for Lossy and Lossless JPEG (JPEG
2000 is not available at this time) on Fedora Core 3 for x86-64.

Ported the library MacOS X on Intel.  Universal binaries are now supplied for
32-bit PowerPC and Intel based MacOS X systems.  Added support back in for
dynamic libraries on MacOS X on Intel.



Defects Resolved in Version 3.6.1 IB1
=====================================
Resolved defect introduced with the changes in listing of messages/files with
the 3.6.0 release.  A crash could occur in the library when T2 level logging
was enabled or when the MC_List_Message or MC_List_File routines were called.
The crash could occur when the library was listing a multi-valued text
attribute that had a null component.

Resolved defect introduced in the 3.6.0 release where in some cases the
MC_Send_Request_Message, MC_Send_Response_Message, and MC_Read_Message routines
were incorrectly returning MC_SYSTEM_ERROR on threaded platforms when an
association was aborted.  These routines will now return
MC_ASSOCIATION_ABORTED.

Fixed defect in the data dictionary where the STANDARD_OPHTHALMIC_16_BIT and
STANDARD_OPHTHALMIC_8_BIT images incorrectly did not have the Sop Common module
included with them.  Instead, one of the Enhanced MR modules was included with
these image types.

Resolved problem on 32-bit Linux operating systems where a crash was occurring
with the Pegasus libraries when doing compression or decompression on an Intel
EM64T based processor systems.

Made some minor changes to the sample applications in how they report timings.
Also made some minor changes with some callback functions to make them work
better when we compile the library on Windows with __stdcall calling convention
(for the new .NET wrapper) instead of _cdecl.



For a list of changes prior to 3.6.1 please contact MergeCOM-3 Support.
