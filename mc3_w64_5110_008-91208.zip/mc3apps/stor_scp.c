
/*******************************************************************************
 *                                                                             *
 *       System: Merge DICOM Toolkit                                           *
 *                                                                             *
 *       Author: Merge Healthcare                                              *
 *                                                                             *
 *  Description: This is a sample service class provider application           *
 *               for the Storage Service Class and the Storage Commitment      *
 *               service class.                                                *
 *                                                                             *
 *******************************************************************************
 *                                                                             *
 *   Copyright (C) IBM Corporation 2016, 2020.                                 *
 *   Copyright (C) Merge Healthcare 2005, 2016.                                *
 *                                                                             *
 *   All rights reserved.                                                      *
 *                                                                             *
 *  This software is furnished under license and may be used and copied only   *
 *  in accordance with the terms of such license and with the inclusion of the *
 *  above copyright notice.                                                    *
 *                                                                             *
 *  This software or any other copies thereof may not be provided or otherwise *
 *  made available to any other person. No title to and ownership of the       *
 *  software is hereby transferred.                                            *
 *                                                                             *
 *******************************************************************************/

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <conio.h>
#include <time.h>
#include <signal.h>
#include <process.h>
#include <sys/timeb.h>

#include <mcstatus.h>
#include <mergecom.h>
#include <mc3msg.h>
#include <mc3media.h>
#include <diction.h>
#include <mc3services.h>
#include <mc3items.h>

#include "general_util.h"

/*
 *  Local definitions
 */
#ifdef INTEL_BCC /* bcc only current platform without intptr_t */
typedef long intptr_t; /* can also declare uintptr_t, ptrdiff_t */
#endif

#define AE_LENGTH 16
#define UI_LENGTH 64
#define SVC_LENGTH 130

#define MAX_THREAD_SERVERS 5
#define THREAD_STACK_SIZE  16384
#define TIME_OUT 30

#define BINARY_READ "rb"
#define BINARY_WRITE "wb"
#define BINARY_APPEND "rb+"
#define BINARY_READ_APPEND "a+b"
#define BINARY_CREATE "w+b"
#define TEXT_READ "r"
#define TEXT_WRITE "w"

/*
 * Structure to store local application information
 */
typedef struct stor_scp_options
{
    int     ApplicationID;
    char    LocalAE[AE_LENGTH+2];
    char    ServiceList[SVC_LENGTH+2];
    int     ListenPort;
    TRANSFER_SYNTAX SaveSyntax;
    SAMP_BOOLEAN    Verbose;
    SAMP_BOOLEAN    ListMessages;
    SAMP_BOOLEAN    SaveStream;
    SAMP_BOOLEAN    SaveFile;
    SAMP_BOOLEAN    ReadStream;
    SAMP_BOOLEAN    ReadStreamAPI;
    SAMP_BOOLEAN    UserIdentity;
    SAMP_BOOLEAN    Exceptions;
} STORAGE_OPTIONS;

/*
 *  Structure passed to our callback functions
 */
typedef struct CALLBACKINFO
{
   FILE*  fp;
   char   filename[256];
   int    append;
   int    messageID;
   char*  serviceName;
   char   prefix[30];
} CBinfo;

/*
 * Structure to maintain list of instances sent
 */
typedef struct instance_node
{
    char   SOPClassUID[UI_LENGTH+2];
    char   SOPInstanceUID[UI_LENGTH+2];
    struct instance_node* Next;
} InstanceNode;


typedef struct transaction_node
{
    char  RemoteAE[AE_LENGTH+2];
    char  TransactionUID[UI_LENGTH+2];
    InstanceNode* InstanceList;
    struct transaction_node* Next;
} TransactionNode;

/*
 *  Module static variables
 */
CRITICAL_SECTION G_CriticalSection;
static int       G_threadCount;
static int       G_imageSaveNumber = 0;
STORAGE_OPTIONS  G_options;

/*
 *  Module function prototypes
 */
int main(int argc, char** argv );

static void         PrintCmdLine( void );
static SAMP_STATUS  TestCmdLine(int A_argc, char* A_argv[], STORAGE_OPTIONS* A_options );
static void         Handle_Association(void* A_arg );
static SAMP_STATUS  HandleStorageCommitMessage(STORAGE_OPTIONS* A_options, int A_associationID, int A_messageID, char* A_transactionUID, TransactionNode** A_list );
static SAMP_STATUS  ParseStorageCommitMessage(STORAGE_OPTIONS* A_options, int A_messageID, char* A_remoteAE, TransactionNode** A_node );
static SAMP_STATUS  SendStorageCommitNEvent(STORAGE_OPTIONS* A_options, TransactionNode** A_list );
static SAMP_STATUS  SetAndSendNEventMessage(STORAGE_OPTIONS* A_options, int A_associationID, TransactionNode* A_node );
static SAMP_STATUS  WriteToMessage(STORAGE_OPTIONS* A_options, char* A_filename, int* A_msgID, char* A_messageType );
static SAMP_STATUS  WriteToMedia(STORAGE_OPTIONS* A_options, char* A_filename, int* A_msgID, char* A_messageType, char *A_remoteAE);
static SAMP_STATUS  ReadRawAndWriteToMedia(STORAGE_OPTIONS* A_options, char* A_filename, int* A_msgID, char* A_messageType, int A_assocID, char *A_remoteAE);
static SAMP_STATUS  AddGroup2Elements(STORAGE_OPTIONS* A_options, TRANSFER_SYNTAX A_transSyntax, int A_fileID, char *A_remoteAE);
static SAMP_STATUS  AddGroup2ElementsFromGroup0(STORAGE_OPTIONS* A_options, int A_fileID, char *A_remoteAE);

static MC_STATUS  NOEXP_FUNC  FileObjToMedia(char* A_filename, void* A_userInfo, int A_dataSize, void* A_dataBuffer, int A_isFirst, int A_isLast );
static MC_STATUS  NOEXP_FUNC  MsgObjToFile(int A_msgID, void* A_userInfo, int A_dataSize, void* A_dataBuffer, int A_isFirst, int A_isLast );
static MC_STATUS  NOEXP_FUNC  StreamToFile(int A_msgID, void* A_userInfo, int A_dataSize, void* A_dataBuffer, int A_isFirst, int A_isLast );

static void     PrintError(char* A_string, MC_STATUS A_status );
static void     End_Thread(const char *msg);
static void     Exception_Handler(int A_signo );

/****************************************************************************
 *
 *  Function    :   main
 *  Description :   Loops waiting for associations or quit key press
 *
 ****************************************************************************/
int main( int argc, char** argv )
{
    SAMP_STATUS     sampStatus;
    MC_STATUS       mcStatus;
    unsigned long   threads_id;
    MC_SOCKET       theSocket;

    printf("stor_scp:\n");

    sampStatus = TestCmdLine(argc, argv, &G_options);
    if (sampStatus != SAMP_SUCCESS)
        return(EXIT_FAILURE);

    printf("\n");
    printf("\tPress 'Q' or Esc to cancel server and\n");
    printf("\tserver will stop when session ends.\n");
	fflush(stdout);
    /*
     * Initialize the critical section before any threads are created.
     * This insures that the critical section is ready before a thread
     * tries to use it.
     */
    InitializeCriticalSection ( &G_CriticalSection );

    /* ------------------------------------------------------- */
    /* This call MUST be the first call made to the library!!! */
    /* ------------------------------------------------------- */
    mcStatus = MC_Library_Initialization ( NULL, NULL, NULL );
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to initialize library",mcStatus);
        return ( EXIT_FAILURE );
    }

    /*
     *  Register this DICOM application
     */
    mcStatus = MC_Register_Application(&G_options.ApplicationID, G_options.LocalAE);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to register \"MERGE_STORE_SCP\"",mcStatus);
        return(EXIT_FAILURE);
    }

    /*
     * If a listen port has been specified, set the port.  This must be
     * done before the first call to MC_Wait_For_Association is made.
     */
    if (G_options.ListenPort != -1)
    {
        mcStatus = MC_Set_Int_Config_Value( TCPIP_LISTEN_PORT, G_options.ListenPort );
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            PrintError("Unable to set listen port, defaulting", mcStatus);
        }
    }

    /* Each thread will handle shutdown and exceptions*/
    signal(SIGINT, Exception_Handler );
    signal(SIGBREAK, Exception_Handler );

    if (G_options.Exceptions)
    {
        mcStatus =  MC_Set_Library_Exception_Handler(Exception_Handler);
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            PrintError("Unable to set Toolkit exception handler", mcStatus);
        }
    }

    /*
     *  Loop, handling associations - waiting for quit keypress
     */
    for (;;)
    {
        /*
         * Poll in a platform specific way if a quit key has ben pressed.
         */
        if (PollInputQuitKey())
            break;

        /*
         * A one second timeout has been chosen so the UI is responsive to the quit keys, although it causes heavy system load.  
         * In most applications, this timeout should be increased.
         */
        mcStatus = MC_Wait_For_Connection( 1, &theSocket );
        if (mcStatus == MC_TIMEOUT)
            continue;
        else if (mcStatus != MC_NORMAL_COMPLETION)
        {
            PrintError("Error on MC_Wait_For_Connection",mcStatus);
            printf("\t\tProgram aborted.\n");
            fflush(stdout);
            break;
        }

        /*
         * Start up a thread to handle the association, if we exceed the limit, the thread will be automatically rejected.
         */
        threads_id =(unsigned long) _beginthread( Handle_Association, (unsigned)THREAD_STACK_SIZE, (void *)theSocket );
        switch ( threads_id )
        {
            case -1:
                printf ( "\tUnable to begin server thread.\n" );
                printf ( "\tProgram aborted.\n" );
                fflush(stdout);
                exit ( EXIT_FAILURE );

            default:
                G_threadCount++;
                break;
        }
    }   /* Loop till quit requested or error */

    mcStatus = MC_Release_Application(&G_options.ApplicationID);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("MC_Release_Application failed",mcStatus);
    }

    if (MC_Library_Release() != MC_NORMAL_COMPLETION)
        printf("Error releasing the library.\n");

    printf("End of program\n");
    fflush(stdout);
    return(EXIT_SUCCESS);
}   /* END main() */

/********************************************************************
 *
 *  Function    :   PrintCmdLine
 *
 *  Parameters  :   none
 *
 *  Returns     :   nothing
 *
 *  Description :   Prints program usage
 *
 ********************************************************************/
static void PrintCmdLine(void)
{
    printf("\nUsage stor_scp -a local_ae -p listen_port -f -i -l svc_list -o -r -R -s -t syntax -v\n\n");
    printf("\t -a local_ae      optional specify the local Application Title (default: MERGE_STORE_SCP)\n");
    printf("\t -p listen_port   optional specify the local listen port (default: found in the mergecom.pro file)\n");
    printf("\t -i               support User Identity Negotiation if supplied in request\n");
    printf("\t -l svc_list      specify the storage service list to use (optional, default: Storage_SCP_Service_List)\n");
    printf("\t -f               save contents of received messages in DICOM Part 10 format\n");
    printf("\t -o               list contents of received messages to stdout\n");
    printf("\t -r               read the dataset without parsing (raw mode) and save the content in DICOM Part 10 format\n");
    printf("\t -R               same as \"-r\" option, but the data reading is done using toolkit API\n");
    printf("\t -s               save contents of received messages in DICOM \"stream\" format\n");
    printf("\t -t syntax        specify the transfer syntax of received objects, where syntax equals:\n");
    printf("\t                      il for Implicit VR Little Endian\n");
    printf("\t                      el for Explicit VR Little Endian\n");
    printf("\t                      eb for Explicit VR Big Endian\n");
    printf("\t -v               execute in verbose mode, print detailed information\n\n");
    printf("\t Image files are stored in the current directory and named \n");
    printf("\t 0.img, 1.img, 2.img, etc. for stream format\n");
} /* end PrintCmdLine() */

/*************************************************************************
 *
 *  Function    :   TestCmdLine
 *
 *  Parameters  :   Aargc   - Command line arguement count
 *                  Aargv   - Command line arguements
 *                  A_options - Local application options read in.
 *
 *  Return value:   SAMP_TRUE
 *                  SAMP_FAILURE
 *
 *  Description :   Test command line for valid arguements.  If problems
 *                  are found, display a message and return SAMP_FAILURE
 *
 *************************************************************************/
static SAMP_STATUS TestCmdLine(int A_argc, char* A_argv[], STORAGE_OPTIONS* A_options )
{
    int i = 0, argCount = 0;

    /*
     * Set default values
     */
    strcpy(A_options->LocalAE, "MERGE_STORE_SCP");
    strcpy(A_options->ServiceList, "Storage_SCP_Service_List");

    A_options->ListMessages = SAMP_FALSE;
    A_options->SaveStream = SAMP_FALSE;
    A_options->SaveFile = SAMP_FALSE;
    A_options->ReadStream = SAMP_FALSE;
    A_options->ReadStreamAPI = SAMP_FALSE;
    A_options->ListenPort = -1;
    A_options->SaveSyntax = IMPLICIT_LITTLE_ENDIAN;
    A_options->UserIdentity = SAMP_FALSE;
    A_options->Exceptions = SAMP_FALSE;
    A_options->Verbose = SAMP_FALSE;

    /*
     * Loop through each arguement and store configuration information
     * in A_options
     */
    for (i = 1; i < A_argc; i++)
    {
        if ( !strcmp(A_argv[i], "-h") || !strcmp(A_argv[i], "/h") ||
             !strcmp(A_argv[i], "-H") || !strcmp(A_argv[i], "/H") ||
             !strcmp(A_argv[i], "-?") || !strcmp(A_argv[i], "/?"))
        {
            PrintCmdLine();
            return SAMP_FAILURE;
        }
        else if ( !strcmp(A_argv[i], "-a") || !strcmp(A_argv[i], "-A"))
        {
            /*
             * Set the Local AE
             */
            i++;
            strcpy(A_options->LocalAE, A_argv[i]);
        }
        else if ( !strcmp(A_argv[i], "-f") || !strcmp(A_argv[i], "-F"))
        {
            /*
             * Save received objects in the DICOM Part 10 format
             */
            A_options->SaveFile = SAMP_TRUE;
        }
        else if ( !strcmp(A_argv[i], "-i") || !strcmp(A_argv[i], "-I"))
        {
            /*
             * Support user identity if in association request
             */
            A_options->UserIdentity = SAMP_TRUE;
        }
        else if ( !strcmp(A_argv[i], "-l") || !strcmp(A_argv[i], "-L"))
        {
            /*
             * Set the Service List
             */
            i++;
            strcpy(A_options->ServiceList, A_argv[i]);
        }
        else if ( !strcmp(A_argv[i], "-o") || !strcmp(A_argv[i], "-O"))
        {
            /*
             * List messages
             */
            A_options->ListMessages = SAMP_TRUE;
        }
        else if ( !strcmp(A_argv[i], "-p") || !strcmp(A_argv[i], "-P"))
        {
            /*
             * Local Port Number
             */
            i++;
            A_options->ListenPort = atoi(A_argv[i]);
        }
        else if ( !strcmp(A_argv[i], "-r") )
        {
            /*
             * Received object in raw mode (un-parse) and save in the DICOM Part 10 format using group 0 info
             */
            A_options->ReadStream = SAMP_TRUE;
        }
        else if ( !strcmp(A_argv[i], "-R") )
        {
            /*
             * Received object in raw mode (un-parse) using API and save in the DICOM Part 10 format using group 0 info
             */
            A_options->ReadStreamAPI = SAMP_TRUE;
        }
        else if ( !strcmp(A_argv[i], "-s") || !strcmp(A_argv[i], "-S"))
        {
            /*
             * Save streamed objects in the
             */
            A_options->SaveStream = SAMP_TRUE;
        }
        else if ( !strcmp(A_argv[i], "-v") || !strcmp(A_argv[i], "-V"))
        {
            /*
             * Verbose mode
             */
            A_options->Verbose = SAMP_TRUE;
        }
        else if ( !strcmp(A_argv[i], "-t") || !strcmp(A_argv[i], "-T"))
        {
            /*
             * A save transfer syntax has been specified
             */
            i++;
            A_options->SaveFile = SAMP_TRUE;
            if ( !strcmp(A_argv[i], "il") || !strcmp(A_argv[i], "IL"))
            {
                A_options->SaveSyntax = IMPLICIT_LITTLE_ENDIAN;
            }
            else if ( !strcmp(A_argv[i], "el") || !strcmp(A_argv[i], "EL"))
            {
                A_options->SaveSyntax = EXPLICIT_LITTLE_ENDIAN;
            }
            else if ( !strcmp(A_argv[i], "eb") || !strcmp(A_argv[i], "EB"))
            {
                A_options->SaveSyntax = EXPLICIT_BIG_ENDIAN;
            }
            else
                printf("Ignoring unkown transfer syntax: %s\n",A_argv[i]);
        }
        else if ( !strcmp(A_argv[i], "-e") || !strcmp(A_argv[i], "-E"))
        {
            A_options->Exceptions = SAMP_TRUE;
        }
        else
        {
            printf("Ignoring unkown option: %s\n",A_argv[i]);

        }
        fflush(stdout);
    }

    /*
     * If using -r / -R raw set mode, the other Save mode will be ignored
     */
    if (A_options->ReadStream || A_options->ReadStreamAPI)
    {
        A_options->SaveFile = SAMP_FALSE;
        A_options->SaveStream = SAMP_FALSE;
    }

    if (A_options->Verbose)
    {
        if (A_options->ListMessages)
            printf("\tList received images.\n");

        if (A_options->SaveFile)
        {
            printf("\tWrite received images to file in DICOM Part 10 (media) format.\n");
            printf("\tImage files will be named x.img, where \"x\" is a number.\n");
        }
        else if (A_options->SaveStream)
        {
            printf("\tWrite received images to file in DICOM \"stream\" format.\n");
            printf("\tImage files will be named x.img, where \"x\" is a number.\n");
        }
        else if (A_options->ReadStream)
        {
            printf("\tImages are read in raw mode (no parsing) and written to file in DICOM Part 10 format.\n");
            printf("\tImage files will be named x.img, where \"x\" is a number.\n");
        }
        else if (A_options->ReadStreamAPI)
        {
            printf("\tImages are read in raw mode (no parsing) using Toolkit API and written to file in DICOM Part 10 format.\n");
            printf("\tImage files will be named x.img, where \"x\" is a number.\n");
        }
        else
        {
            printf("\t\"Bit bucket\" operation.\n");
        }
        fflush(stdout);
    }
    return SAMP_SUCCESS;

}/* TestCmdLine() */



/*************************************************************************
 *
 *  Function    :   PollQuitKey
 *
 *  Parameters  :   none
 *
 *  Return value:   SAMP_SUCCESS if quit key pressed
 *                  SAMP_FAILURE all other conditions
 *
 *  Description :   Platform specific code to test if a quit key has been
 *                  pressed.
 *
 *************************************************************************/
static SAMP_BOOLEAN PollQuitKey(void)
{

#if defined(INTEL_BCC)
    if ( kbhit () )
#else
    if ( _kbhit () )
#endif
    {
        switch ( _getch () )
        {
            case    0:      /* Ignore function keys */
                _getch();
                break;

            case   'Q':    /* Quit */
            case   'q':
            case    27:
                return SAMP_TRUE;
        }
    }
    return SAMP_FALSE;
}

/****************************************************************************
 *
 *  Function    :    Handle_Association
 *  Parameters  :    Aoptions - Structure that holds configuration parameters
 *  Returns     :    nothing
 *  Description :    Processes a received association requests
 *
 ****************************************************************************/
static void Handle_Association(void* A_arg)
{
    static int  quota_message = 1;

    MC_STATUS   mcStatus;
    MC_COMMAND  command;
    MC_SOCKET   theSocket;

    SAMP_STATUS sampStatus;
    RESP_STATUS respStatus = C_STORE_SUCCESS;
    
    void        *startTime = NULL, *imageStartTime = NULL;
    char        fname[32] = {0}, prefix[30] = {0}, msg[256] = {0};
    int         assocID = -1, msgID = -1, rspMsgID = -1, nimages = 0, calledApplicationID = -1;
    double      seconds = 0.0, perSecond = 0.0;

    AssocInfo   asscInfo = {0};
    ServiceInfo servInfo = {0};

    TransactionNode *transactionList = (TransactionNode*)NULL;

    /*
     * Now, copy the association ID out of the options structure and save it in a local variable, then exit the critical section.
     */
    theSocket = (int)(intptr_t)A_arg;

    /* Process the association request */
    mcStatus = MC_Process_Association_Request( theSocket, G_options.ServiceList, &calledApplicationID, &assocID );
    if (mcStatus == MC_ASSOCIATION_CLOSED)
    {
        End_Thread("\tAn echo association was automatically processed.\n");
        return;
    }
    else if (mcStatus == MC_ASSOCIATION_REJECTED)
    {
        End_Thread("\tInvalid association rejected.\n");
        return;
    }
    else if (mcStatus == MC_NEGOTIATION_ABORTED)
    {
        End_Thread("\tAssociation aborted during negotiation \n");
        return;
    }
    else if (mcStatus != MC_NORMAL_COMPLETION)
    {   
        sprintf(msg, "\tError when processing association request: %s \n", MC_Error_Message(mcStatus));        
        End_Thread(msg);
        return;
    }

    if ( G_threadCount > MAX_THREAD_SERVERS )
    {
        if ( quota_message )
            quota_message = 0;

        mcStatus = MC_Reject_Association(assocID, TRANSIENT_LOCAL_LIMIT_EXCEEDED);
        End_Thread("Server Quota readched at least once\n");
        return;
    }

    if (calledApplicationID != G_options.ApplicationID)
    {
        mcStatus = MC_Reject_Association(assocID, TRANSIENT_LOCAL_LIMIT_EXCEEDED);
        End_Thread("\tUnexpected application identifier on MC_Wait_For_Association.\n\t\tProgram aborted.\n");
        return;
    }

    /*
     *  Need thread ID number for messages displayed
     */
    sprintf ( prefix, "TID(%lu)", GetCurrentThreadId () );
    startTime = GetIntervalStart();

    mcStatus = MC_Get_Association_Info( assocID, &asscInfo);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("MC_Get_Association_Info failed", mcStatus);
    }
    else
    {
        if (G_options.Verbose)
        {
            printf("Connection from Remote Application:\n");
            printf("  Remote AE Title:            %s\n", asscInfo.RemoteApplicationTitle);
            printf("  Local (requested) AE Title: %s\n", asscInfo.LocalApplicationTitle);
            printf("  Host name:                  %s\n", asscInfo.RemoteHostName);
            printf("  IP Address:                 %s\n", asscInfo.RemoteIPAddress);
            printf("  Local Max PDU Size:         %d\n", asscInfo.LocalMaximumPDUSize);
            printf("  Remote Max PDU Size:        %d\n", asscInfo.RemoteMaximumPDUSize);
            printf("  Max operations invoked:     %d\n", asscInfo.MaxOperationsInvoked);
            printf("  Max operations performed:   %d\n", asscInfo.MaxOperationsPerformed);
            printf("  Implementation Version:     %s\n", asscInfo.RemoteImplementationVersion);

            /*
             * Check if user identity information is included in the
             * association request, and print to the screen relevent
             * information if it is negotiated as described in DICOM
             * Supplement 99.
             */
            if (asscInfo.UserIdentityType == NO_USER_IDENTITY)
            {
                printf("  User Identity type:         None\n\n\n");
            }
            else
            {
                unsigned short fieldLength;
                char primaryField[1024];
                char secondaryField[1024];

                primaryField[0] = '\0';
                secondaryField[0] = '\0';

                /*
                 * Get the primary and secondary fields contained in
                 * the association negotiation user identity information
                 * if it has been received.
                 */
                mcStatus = MC_Get_User_Identity_Length(assocID, PRIMARY_FIELD, &fieldLength);
                if (mcStatus != MC_NORMAL_COMPLETION)
                {
                    PrintError("Unable to get user identity primary field length",mcStatus);

                    MC_Reject_Association(assocID, TRANSIENT_NO_REASON_GIVEN);
                    End_Thread(NULL);
                }
                if (fieldLength > 0)
                {
                    mcStatus = MC_Get_User_Identity_Info( assocID, PRIMARY_FIELD, primaryField, sizeof(primaryField));
                    if (mcStatus != MC_NORMAL_COMPLETION)
                    {
                        PrintError("Unable to get user identity primary field",mcStatus);

                        MC_Reject_Association(assocID, TRANSIENT_NO_REASON_GIVEN);
                        End_Thread(NULL);
                    }
                    /* The field may or may not be null terminated, ensure
                     * that it is */
                    primaryField[fieldLength] = '\0';
                }

                /*
                 * Get the secondary field, this would only find data if USERNAME_AND_PASSCODE identity is specified.
                 */
                mcStatus = MC_Get_User_Identity_Length(assocID, SECONDARY_FIELD, &fieldLength);
                if (mcStatus != MC_NORMAL_COMPLETION)
                {
                    PrintError("Unable to get user identity secondary field length",mcStatus);

                    MC_Reject_Association(assocID, TRANSIENT_NO_REASON_GIVEN);
                    End_Thread(NULL);
                }
                if (fieldLength > 0)
                {
                    mcStatus = MC_Get_User_Identity_Info( assocID, SECONDARY_FIELD, secondaryField, sizeof(secondaryField));
                    if (mcStatus != MC_NORMAL_COMPLETION)
                    {
                        PrintError("Unable to get user identity secondary field",mcStatus);

                        MC_Reject_Association(assocID, TRANSIENT_NO_REASON_GIVEN);
                        End_Thread(NULL);
                    }
                    /* The field may or may not be null terminated, ensure
                     * that it is */
                    secondaryField[fieldLength] = '\0';
                }

                /* Now print the identity details */
                if (asscInfo.UserIdentityType == USERNAME)
                {
                    printf("  User Identity type:         Username\n");
                    printf("  Username:                   %s\n", primaryField);
                }
                else if (asscInfo.UserIdentityType == USERNAME_AND_PASSCODE)
                {
                    printf("  User Identity type:         Username and Passcode\n");
                    printf("  Username:                   %s\n", primaryField);
                    printf("  Password:                   %s\n", secondaryField);
                }
                else if (asscInfo.UserIdentityType == KERBEROS_SERVICE_TICKET)
                {
                    printf("  User Identity type:         Kerberos Service Ticket\n");
                    printf("  Kerberos Service Ticket:    %s\n", primaryField);
                }
                else if (asscInfo.UserIdentityType == SAML_ASSERTION)
                {
                    printf("  User Identity type:         SAML Assertion\n");
                    printf("  SAML Assertion:             %s\n", primaryField);
                }
                else if (asscInfo.UserIdentityType == JSON_WEB_TOKEN)
                {
                    printf("  User Identity type:         JSON Web Token\n");
                    printf("  JSON Web Token:             %s\n", primaryField);
                }

                if (asscInfo.PositiveResponseRequested)
                    printf("  Positive response requested: Yes\n\n\n");
                else
                    printf("  Positive response requested: No\n\n\n");
            }
        }
    }


    if (G_options.Verbose)
    {
        printf("Services and transfer syntaxes negotiated:\n");

        /*
         * This the services negotiated
         */
        mcStatus = MC_Get_First_Acceptable_Service(assocID,&servInfo);
        while (mcStatus == MC_NORMAL_COMPLETION)
        {
            printf("   %-30s: %s\n", servInfo.ServiceName, GetSyntaxDescription(servInfo.SyntaxType));
            mcStatus = MC_Get_Next_Acceptable_Service(assocID,&servInfo);
        }

        /*
         * Catch error, but because it doesn't impact operation, don't do
         * anything about it.
         */
        if (mcStatus != MC_END_OF_LIST)
            PrintError("Warning: Unable to get service info",mcStatus);

        printf("\n\n");
    }
    else
        printf("%s\n\tAssociation Received.\n\n", prefix);


     fflush(stdout);

    /*
     * We only are responding to Username & Username and Passcode identity information in the association request.  
     * SAML Assertion and Kerberos Service Ticket will be ignored.
     */
    if (((asscInfo.UserIdentityType == USERNAME) || (asscInfo.UserIdentityType == USERNAME_AND_PASSCODE))
         && asscInfo.PositiveResponseRequested
         && G_options.UserIdentity )
    {
        printf("\tSending positive response to user identity negotiation.\n\n");
        /*
         * We just accept, and don't put anything in the
         * server response field.
         */
        mcStatus = MC_Accept_Association_With_Identity(assocID, NULL, 0);
    }
    else
    {
        if ((asscInfo.UserIdentityType != NO_USER_IDENTITY) && asscInfo.PositiveResponseRequested)
            printf("\tIgnoring user identity negotiation information.\n\n");

        mcStatus = MC_Accept_Association(assocID);
    }

    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        /* Make sure the association is cleaned up. */
        PrintError("Error on MC_Accept_Association", mcStatus);

        MC_Reject_Association(assocID, TRANSIENT_NO_REASON_GIVEN);
        End_Thread(NULL);
        return;
    }
    fflush(stdout);

    for (;;)
    {
        char *serviceName = NULL;
        char servNameKeep[256] = {0};

        EnterCriticalSection ( &G_CriticalSection );
        sprintf(fname, "%d.img", G_imageSaveNumber++);
        LeaveCriticalSection ( &G_CriticalSection );

        imageStartTime = GetIntervalStart();

        if (G_options.ReadStream)
        {
            /* read only the group 0 (command) part of the message */
            mcStatus = MC_Read_Message_To_Tag( assocID, TIME_OUT, 0x00010000, &msgID, &serviceName, &command);
        }
        else if (G_options.ReadStreamAPI)
        {
            /* read the entire message to stream */
            CBinfo  callbackInfo = {0};
            strcpy(callbackInfo.filename, fname);
            mcStatus = MC_Read_To_Stream( assocID, TIME_OUT, &serviceName, &command, callbackInfo.filename, &callbackInfo, StreamToFile );
        }
        else
        {
            /* read the entire message */
            mcStatus = MC_Read_Message( assocID, TIME_OUT, &msgID, &serviceName, &command);
        }

        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            if(msgID > 0)
                MC_Free_Message(&msgID);
            if (mcStatus == MC_ASSOCIATION_CLOSED)
            {
                G_imageSaveNumber--;

                printf("%s\tAssociation Closed.\n", prefix);
                seconds = GetIntervalElapsed(startTime);
                if (nimages)
                {
                    perSecond = seconds / nimages;
                    printf ("%s\t\tElapsed time = %.3f seconds - %d images, %.3f seconds per image\n", prefix, seconds, nimages, perSecond);
                }
                else
                    printf ("%s\t\tNo images received\n", prefix);
                break;
            }
            else if (mcStatus == MC_NETWORK_SHUT_DOWN
                 ||  mcStatus == MC_ASSOCIATION_ABORTED
                 ||  mcStatus == MC_INVALID_MESSAGE_RECEIVED
                 ||  mcStatus == MC_CONFIG_INFO_ERROR)
            {
                /*
                 * In this case, the association has already been closed for us.
                 */
                PrintError("Unexpected event", mcStatus);
                break;
            }

            PrintError("Error on MC_Read_Message", mcStatus);
            MC_Abort_Association(&assocID);
            break;
        }

        if (!strcmp(serviceName, Services.STORAGE_COMMITMENT_PUSH))
        {
            sampStatus = HandleStorageCommitMessage( &G_options, assocID, msgID, asscInfo.RemoteApplicationTitle, &transactionList );
            if (G_options.ListMessages)
            {
                MC_List_Message( msgID, NULL );
            }

            mcStatus = MC_Free_Message(&msgID);
            if (mcStatus != MC_NORMAL_COMPLETION)
            {
                PrintError("MC_Free_Message for request message error", mcStatus);
                MC_Abort_Association(&assocID);
                break;
            }

            continue;
        }

        /*
         * Set the number of images and the status to success
         */
        nimages++;
        respStatus = C_STORE_SUCCESS;
        sampStatus = SAMP_SUCCESS;

        /*
         * First, if list message has been specified, list the objects.
         */
        if (G_options.ListMessages)
        {
            MC_List_Message(msgID, NULL);
        }

        /* Save service name as the message object is going to be freed */
        strcpy(servNameKeep, serviceName);
        serviceName = servNameKeep;

        if (G_options.ReadStream || G_options.ReadStreamAPI)
        {
            if (G_options.ReadStream)
            {
                /*
                 * The message object will be freed by ReadRawAndWriteToMedia
                 */
                sampStatus = ReadRawAndWriteToMedia(&G_options, fname, &msgID, serviceName, assocID, asscInfo.RemoteApplicationTitle);
            }
            respStatus = (sampStatus == SAMP_SUCCESS) ? C_STORE_SUCCESS : C_STORE_FAILURE_PROCESSING_FAILURE;
        }
        else if (G_options.SaveFile)
        {
            /*
             * The message object will be freed by WriteToFile
             */
            sampStatus = WriteToMedia(&G_options, fname, &msgID, serviceName, asscInfo.RemoteApplicationTitle);
            respStatus = (sampStatus == SAMP_SUCCESS) ? C_STORE_SUCCESS : C_STORE_FAILURE_PROCESSING_FAILURE;
        }
        else if (G_options.SaveStream)
        {
            /*
             * The message object will be freed by WriteToMessage
             */
            sampStatus = WriteToMessage( &G_options, fname, &msgID, serviceName);
            respStatus = (sampStatus == SAMP_SUCCESS) ? C_STORE_SUCCESS : C_STORE_FAILURE_PROCESSING_FAILURE;
        }
        else
        {
            printf ("%s\tImage %d received (%s)", prefix, nimages, serviceName);

            mcStatus = MC_Free_Message(&msgID);
            if (mcStatus != MC_NORMAL_COMPLETION)
            {
                PrintError("MC_Free_Message for request message error", mcStatus);
                MC_Abort_Association(&assocID);
                break;
            }
        }

        /*
         *  Acquire a response message object, send it, and free it
         */
        mcStatus = MC_Open_Message (&rspMsgID, serviceName, C_STORE_RSP);
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            PrintError("MC_Open_Message failed", mcStatus);
            MC_Abort_Association(&assocID);
            break;
        }

        mcStatus = MC_Send_Response_Message(assocID, respStatus, rspMsgID);
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            PrintError("MC_Send_Response_Message failed", mcStatus);
            MC_Abort_Association(&assocID);
            MC_Free_Message(&rspMsgID);
            break;
        }

        mcStatus = MC_Free_Message(&rspMsgID);
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            PrintError("MC_Free_Message for response message failed", mcStatus);
            MC_Abort_Association(&assocID);
            break;
        }

        seconds = GetIntervalElapsed(imageStartTime);
        printf("\t%.3f seconds\n", seconds);
    }

    if (transactionList)
    {
        printf("Sending storage commitment N-EVENT message\n");
        SendStorageCommitNEvent(&G_options, &transactionList );
    }

    /*
     * Ending the thread so do the cleanup
     */
    sprintf(msg, "%s\tEnding thread naturally.\n", prefix);
    End_Thread(msg);
    fflush(stdout);

    return;
}

/********************************************************************
 *
 *  Function    :    HandleStorageCommitMessage
 *
 *  Parameters  :    A_associationID - Association identifier
 *                   A_messageID - ID of message received
 *                   A_list      - List of transactions.
 *
 *  Returns     :    SAMP_SUCCESS - if not errors occurred
 *                   SAMP_FAILURE - if errors occurred
 *
 *  Description :
 *
 ********************************************************************/
static SAMP_STATUS HandleStorageCommitMessage(STORAGE_OPTIONS* A_options, int A_associationID, int A_messageID, char* A_remoteAE, TransactionNode** A_list )
{
    TransactionNode* node;
    InstanceNode*    instanceNode;
    MC_STATUS        mcStatus;
    SAMP_STATUS      sampStatus;
    int              rspMessageID;

    mcStatus = MC_Open_Message (&rspMessageID, Services.STORAGE_COMMITMENT_PUSH, N_ACTION_RSP);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("MC_Open_Message error for n-action-rsp", mcStatus);
        return ( SAMP_FAILURE );
    }

    sampStatus = ParseStorageCommitMessage(A_options, A_messageID, A_remoteAE, &node );
    if ( sampStatus == SAMP_SUCCESS )
    {
        /*
         * Save in the transaction list
         */
        node->Next = *A_list;
        *A_list = node;

        mcStatus = MC_Send_Response_Message(A_associationID, N_ACTION_SUCCESS, rspMessageID);
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            PrintError("MC_Send_Response_Message error", mcStatus);
            MC_Free_Message(&rspMessageID);
            return SAMP_FAILURE;
        }
    }
    else
    {
        if (node)
        {
            while( node->InstanceList )
            {
                instanceNode = node->InstanceList;
                node->InstanceList = node->InstanceList->Next;

                free( instanceNode );
            }
            free( node );
        }

        printf("Sending processing failure status for N-ACTION-RQ\n");

        mcStatus = MC_Send_Response_Message(A_associationID, N_ACTION_PROCESSING_FAILURE, rspMessageID);
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            PrintError("MC_Send_Response_Message error", mcStatus);
            MC_Free_Message(&rspMessageID);
            return ( SAMP_FAILURE );
        }
    }

    mcStatus = MC_Free_Message(&rspMessageID); /* Free the response object */
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("MC_Send_Response_Message error:\n", mcStatus);
        return ( SAMP_FAILURE );
    }

    return ( SAMP_SUCCESS );
}

/********************************************************************
 *
 *  Function    :    ParseStorageCommitMessage
 *
 *  Parameters  :    A_messageID - ID of message received
 *                   A_remoteAE  - Remote Application Entity Title
 *                   A_node      - Transaction node allocated in this
 *                                 function
 *
 *  Returns     :    SAMP_SUCCESS - if not errors occurred
 *                   SAMP_FAILURE - if errors occurred
 *
 *  Description :
 *
 ********************************************************************/
static SAMP_STATUS ParseStorageCommitMessage(STORAGE_OPTIONS* A_options, int A_messageID, char* A_remoteAE, TransactionNode** A_node )
{
    InstanceNode*    instanceNode;
    MC_STATUS        mcStatus;
    int              itemID;

    *A_node = malloc(sizeof(TransactionNode));
    if (!*A_node)
    {
        PrintError("Unable to allocate object to store storage commitment information", MC_NORMAL_COMPLETION);
        return ( SAMP_FAILURE );
    }

    (*A_node)->InstanceList = NULL;
    strncpy((*A_node)->RemoteAE, A_remoteAE, sizeof((*A_node)->RemoteAE));

    mcStatus = MC_Get_Value_To_String(A_messageID, MC_ATT_TRANSACTION_UID, sizeof((*A_node)->TransactionUID), (*A_node)->TransactionUID);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("MC_Get_Value_To_String for Transaction UID failed", mcStatus);
        return(SAMP_FAILURE);
    }

    if (A_options->Verbose)
    {
        printf("Received Storage Commitment N-ACTION-RQ from %s for\n", A_remoteAE);
        printf("    transaction UID: %s\n", (*A_node)->TransactionUID );
        printf("    Objects:\n");
    }
    else
        printf("Received Storage Commitment N-ACTION-RQ\n\n");

    mcStatus = MC_Get_Next_Value_To_Int( A_messageID, MC_ATT_REFERENCED_SOP_SEQUENCE, &itemID );
    while ( mcStatus == MC_NORMAL_COMPLETION )
    {
        instanceNode = malloc(sizeof(InstanceNode));
        if (!instanceNode)
        {
            PrintError("Unable to allocate InstanceNode object", MC_NORMAL_COMPLETION);
            return ( SAMP_FAILURE );
        }

        mcStatus = MC_Get_Value_To_String( itemID, MC_ATT_REFERENCED_SOP_CLASS_UID, sizeof(instanceNode->SOPClassUID), instanceNode->SOPClassUID );
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            PrintError("Unable to get SOP Class UID in n-action message", mcStatus);
            free(instanceNode);
            return ( SAMP_FAILURE );
        }

        mcStatus = MC_Get_Value_To_String( itemID, MC_ATT_REFERENCED_SOP_INSTANCE_UID, sizeof(instanceNode->SOPInstanceUID), instanceNode->SOPInstanceUID );
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            PrintError("Unable to get SOP Instance UID in n-action message", mcStatus);
            free(instanceNode);
            return ( SAMP_FAILURE );
        }

        if (A_options->Verbose)
        {
            printf("       SOP Class UID: %s\n", instanceNode->SOPClassUID );
            printf("    SOP Instance UID: %s\n\n", instanceNode->SOPInstanceUID );
        }

        instanceNode->Next = (*A_node)->InstanceList;
        (*A_node)->InstanceList = instanceNode;

        mcStatus = MC_Get_Next_Value_To_Int( A_messageID, MC_ATT_REFERENCED_SOP_SEQUENCE, &itemID );
    }
    return ( SAMP_SUCCESS );
}


/********************************************************************
 *
 *  Function    :    SendStorageCommitNEvent
 *
 *  Parameters  :    A_appID     - application ID
 *                   A_node      - Transaction node allocated in this
 *                                 function
 *
 *  Returns     :    SAMP_SUCCESS - if not errors occurred
 *                   SAMP_FAILURE - if errors occurred
 *
 *  Description :
 *
 ********************************************************************/
static SAMP_STATUS SendStorageCommitNEvent(STORAGE_OPTIONS* A_options, TransactionNode** A_list )
{
    TransactionNode* node;
    InstanceNode*    instanceNode;
    int           associationID = -1;
    SAMP_STATUS   sampStatus;
    MC_STATUS     mcStatus;

    if (!*A_list)
    {
        printf("No objects to commit.\n");
        return ( SAMP_SUCCESS );
    }

    node = *A_list;
    while ( node )
    {
        if (A_options->Verbose)
            printf("\nOpening N-EVENT-REPORT association to %s\n", node->RemoteAE);

        mcStatus = MC_Open_Association( A_options->ApplicationID, &associationID, node->RemoteAE, NULL, NULL, "Storage_Commit_SCP_Service_List" );
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            printf("Unable to open association with \"%s\":\n",node->RemoteAE);
            printf("\t%s\n", MC_Error_Message(mcStatus));
            return ( SAMP_FAILURE );
        }

        sampStatus = SetAndSendNEventMessage( A_options, associationID, node );
        if ( !sampStatus )
        {
            MC_Abort_Association(&associationID);
        }
        else
        {
            /*
             * When the close association fails, there's nothing really to be
             * done.  Let's still continue on and wait for an N-EVENT-REPORT
             */
            mcStatus = MC_Close_Association( &associationID);
            if (mcStatus != MC_NORMAL_COMPLETION)
            {
                PrintError("Close association failed", mcStatus);
                MC_Abort_Association(&associationID);
            }

            if (A_options->Verbose)
                printf("Closing N-EVENT-REPORT association\n\n");
        }

        while ( node->InstanceList )
        {
            instanceNode = node->InstanceList->Next;
            free( node->InstanceList );
            node->InstanceList = instanceNode;
        }

        *A_list = node->Next;
        free ( node );
        node = *A_list;
    }
    return ( SAMP_SUCCESS );
}

/****************************************************************************
 *
 *  Function    :   SetAndSendNEventMessage
 *
 *  Parameters  :   A_options  - Pointer to structure containing input
 *                               parameters to the application
 *                  A_associationID - Association ID registered
 *                  A_list     - List of objects to request commitment for.
 *
 *  Returns     :   SAMP_SUCCESS
 *                  SAMP_FAILURE
 *
 *  Description :   Perform storage commitment for a set of storage objects.
 *                  When completed, the list of objects is freed.
 *
 ****************************************************************************/
static SAMP_STATUS SetAndSendNEventMessage(STORAGE_OPTIONS* A_options, int A_associationID, TransactionNode* A_node)
{
    MC_STATUS      mcStatus;
    int            messageID = -1, itemID = -1, responseMessageID = -1, responseStatus = -1;
    InstanceNode*  instanceNode;
    char           *responseService = (char*)NULL;
    MC_COMMAND     responseCommand;


    mcStatus = MC_Open_Message( &messageID, Services.STORAGE_COMMITMENT_PUSH, N_EVENT_REPORT_RQ );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintError("Error opening Storage Commitment n-event-report-rq message",mcStatus);
        return ( SAMP_FAILURE );
    }

    /*
     * Set the well-known SOP instance for storage commitment Push, as
     * listed in DICOM PS3.4, J.3.5
     */
    mcStatus = MC_Set_Value_From_String( messageID, MC_ATT_AFFECTED_SOP_INSTANCE_UID, "1.2.840.10008.1.20.1.1");
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("MC_Set_Value_From_String for requested sop instance uid failed",mcStatus);
        MC_Free_Message(&messageID);
        return ( SAMP_FAILURE );
    }

    mcStatus = MC_Set_Next_Value_From_Int( messageID, MC_ATT_EVENT_TYPE_ID, 1 );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintError("Unable to set event type ID in n-action message", mcStatus);
        MC_Free_Message( &messageID );
        return ( SAMP_FAILURE );
    }

    /*
     * Set the transaction UID.  Note that in a real storage commitment
     * application, this UID should be tracked and associated with the
     * SOP instances asked for commitment with this request.  That way if
     * multiple storage commitment requests are outstanding, and an
     * N-EVENT-REPORT comes in, we can associate the message with the
     * proper storage commitment request.
     */
    mcStatus = MC_Set_Value_From_String( messageID, MC_ATT_TRANSACTION_UID, A_node->TransactionUID );
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("MC_Set_Value_From_String for transaction uid failed",mcStatus);
        MC_Free_Message(&messageID);
        return ( SAMP_FAILURE );
    }


    instanceNode = A_node->InstanceList;
    while (instanceNode)
    {
        mcStatus = MC_Open_Item( &itemID, Items.REF_SOP_MEDIA_AE );
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            MC_Free_Item( &itemID );
            MC_Free_Message( &messageID );
            return ( SAMP_FAILURE );
        }

        mcStatus = MC_Set_Next_Value_From_Int( messageID, MC_ATT_REFERENCED_SOP_SEQUENCE, itemID );
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            PrintError("Unable to set ItemID in n-event message", mcStatus);
            MC_Free_Item( &itemID );
            MC_Free_Message( &messageID );
            return ( SAMP_FAILURE );
        }

        mcStatus = MC_Set_Value_From_String( itemID, MC_ATT_REFERENCED_SOP_CLASS_UID, instanceNode->SOPClassUID );
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            PrintError("Unable to set SOP Class UID in n-event message", mcStatus);
            MC_Free_Message( &messageID );
            return ( SAMP_FAILURE );
        }

        mcStatus = MC_Set_Value_From_String( itemID, MC_ATT_REFERENCED_SOP_INSTANCE_UID, instanceNode->SOPInstanceUID );
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            PrintError("Unable to set SOP Instance UID in n-event message", mcStatus);
            MC_Free_Message( &messageID );
            return ( SAMP_FAILURE );
        }
        instanceNode = instanceNode->Next;
    }

    if ( A_options->Verbose )
        printf("Sending N-EVENT-REPORT message\n");

    /*
     * Once the message has been built, we are then able to perform the
     * N-EVENT-REPORT-RQ on it.
     */
    mcStatus = MC_Send_Request_Message( A_associationID, messageID );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintError("Unable to send N-ACTION-RQ message",mcStatus);
        MC_Free_Message( &messageID );
        return ( SAMP_FAILURE );
    }

    /*
     * After sending the message, we free it.
     */
    mcStatus = MC_Free_Message( &messageID );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintError("Unable to free N-ACTION-RQ message",mcStatus);
        return ( SAMP_FAILURE );
    }

    /*
     *  Wait for response
     */
    mcStatus = MC_Read_Message(A_associationID, TIME_OUT, &responseMessageID, &responseService, &responseCommand);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("MC_Read_Message failed for N-EVENT-REPORT-RSP", mcStatus);
        return ( SAMP_FAILURE );
    }

    mcStatus = MC_Get_Value_To_Int(responseMessageID, MC_ATT_STATUS, &responseStatus);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("MC_Get_Value_To_Int for N-EVENT-REPORT-RSP status failed",mcStatus);
        MC_Free_Message(&responseMessageID);
        return ( SAMP_FAILURE );
    }

    switch (responseStatus)
    {
        case N_EVENT_PROCESSING_FAILURE:
            printf("N-EVENT-REPORT-RSP failed because of processing failure\n");
            MC_Free_Message(&responseMessageID);
            return ( SAMP_FAILURE );
        case N_EVENT_SUCCESS:
            if ( A_options->Verbose )
                printf("N-EVENT-REPORT message received with SUCCESS status\n");
            break;
        default:
            printf("N-EVENT-REPORT-RSP failure, status=%x\n",responseStatus);
            MC_Free_Message(&responseMessageID);
            return ( SAMP_FAILURE );
    }

    mcStatus = MC_Free_Message( &responseMessageID );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintError("Unable to free N-EVENT_REPORT-RSP message",mcStatus);
        return ( SAMP_FAILURE );
    }
    return( SAMP_SUCCESS );

} /* End of SetAndSendNActionMessage */

/********************************************************************
 *
 *  Function    :    WriteToMessage
 *
 *  Parameters  :    Aoptions   - Structure that holds configuration
 *                                parameters
 *                   A_filename - Filename to write to
 *                   A_msgID    - ID of message to write
 *                   A_msgType  - Character string describing the
 *                                message type
 *
 *  Returns     :    SAMP_SUCCESS - if not errors occurred
 *                   SAMP_FAILURE - if errors occurred
 *
 *  Description :    Function is used to write a message received
 *                   over the network to a file in the DICOM "stream"
 *                   format.
 *
 ********************************************************************/
static SAMP_STATUS WriteToMessage( STORAGE_OPTIONS* A_options, char* A_filename, int* A_msgID, char* A_messageType )
{
    MC_STATUS        mcStatus;
    int              retStatus;
    CBinfo           callbackInfo;
    TRANSFER_SYNTAX  resultSyntax;
    TRANSFER_SYNTAX  messageSyntax;
    char             sopInstanceUID[UI_LENGTH+2] = {0};

    /*
     * Get the transfer syntax that the message was transfered over
     * the network as.  This is to determine if it is an encapsulated/
     * JPEG transfer syntax.  Note that by default the program does
     * not support encapsulated transfer syntaxes.  Transfer syntax lists
     * containing the encapsualted syntaxes must be added the service
     * lists.
     */
    mcStatus = MC_Get_Message_Transfer_Syntax( *A_msgID, &messageSyntax );
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Warning: error on MC_Get_Message_Transfer_Syntax", mcStatus);
        resultSyntax = A_options->SaveSyntax;
    }
    else
    {
        switch (messageSyntax)
        {
            case IMPLICIT_LITTLE_ENDIAN:
            case EXPLICIT_LITTLE_ENDIAN:
            case EXPLICIT_BIG_ENDIAN:
            case IMPLICIT_BIG_ENDIAN:
                resultSyntax = A_options->SaveSyntax;
                break;

            case HEVC_H265_M10P_LEVEL_5_1:
            case HEVC_H265_MP_LEVEL_5_1:
            case JPEG_2000:
            case JPEG_2000_LOSSLESS_ONLY:
            case JPEG_2000_MC:
            case JPEG_2000_MC_LOSSLESS_ONLY:
            case JPEG_BASELINE:
            case JPEG_EXTENDED_2_4:
            case JPEG_EXTENDED_3_5:
            case JPEG_SPEC_NON_HIER_6_8:
            case JPEG_SPEC_NON_HIER_7_9:
            case JPEG_FULL_PROG_NON_HIER_10_12:
            case JPEG_FULL_PROG_NON_HIER_11_13:
            case JPEG_LOSSLESS_NON_HIER_14:
            case JPEG_LOSSLESS_NON_HIER_15:
            case JPEG_EXTENDED_HIER_16_18:
            case JPEG_EXTENDED_HIER_17_19:
            case JPEG_SPEC_HIER_20_22:
            case JPEG_SPEC_HIER_21_23:
            case JPEG_FULL_PROG_HIER_24_26:
            case JPEG_FULL_PROG_HIER_25_27:
            case JPEG_LOSSLESS_HIER_28:
            case JPEG_LOSSLESS_HIER_29:
            case JPEG_LOSSLESS_HIER_14:
            case JPEG_LS_LOSSLESS:
            case JPEG_LS_LOSSY:
            case JPIP_REFERENCED:
            case JPIP_REFERENCED_DEFLATE:
            case MPEG2_MPML:
            case MPEG2_MPHL:
            case MPEG4_AVC_H264_HP_LEVEL_4_1:
            case MPEG4_AVC_H264_BDC_HP_LEVEL_4_1:
            case MPEG4_AVC_H264_HP_LEVEL_4_2_2D:
            case MPEG4_AVC_H264_HP_LEVEL_4_2_3D:
            case MPEG4_AVC_H264_STEREO_HP_LEVEL_4_2:
            case PRIVATE_SYNTAX_1:
            case PRIVATE_SYNTAX_2:
            case RLE:
                resultSyntax = messageSyntax;
                printf("Warning: Encapsulated transfer syntax (%s) image specified\n", GetSyntaxDescription(messageSyntax));
                printf("         Not sending image.\n");
                MC_Free_File(A_msgID);
                return SAMP_FAILURE;
        }
    }

    if (A_options->Verbose)
    {
        /*
         * Get the SOP Instance UID from the message, and then print out image information
         */
        mcStatus = MC_Get_Value_To_String( *A_msgID, MC_ATT_SOP_INSTANCE_UID, sizeof(sopInstanceUID), sopInstanceUID );
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            PrintError("Unable to get SOP Instance UID from image file",mcStatus);
        }

        printf("Writing image in DICOM \"Stream\" format:\n");
        printf("\tMessage Type: %s\n", A_messageType);
        printf("\tFile Name: %s\n", A_filename);
        printf("\tStored Transfer syntax: %s\n", GetSyntaxDescription(resultSyntax));
        printf("\tSOP Instance UID: %s\n", sopInstanceUID );

    }
    else
        printf("Writing %s image in DICOM \"Stream\" format:  %s\n", A_messageType, A_filename);
    fflush(stdout);


    callbackInfo.fp = fopen(A_filename, BINARY_WRITE);
    if (!callbackInfo.fp)
    {
        printf("\tUnable to open output file: %s\n", A_filename);
        MC_Free_Message(A_msgID);
        return SAMP_FAILURE;
    }

    retStatus = setvbuf(callbackInfo.fp, (char *)NULL, _IOFBF, 32768);
    if ( retStatus != 0 )
    {
        printf("WARNING:  Unable to set IO buffering on input file.\n");
    }

    /*
     * do the callback to copy all the elements into the new file which is
     *  just stream formatted.
     */
    mcStatus = MC_Message_To_Stream( *A_msgID, 0x00000000, 0xFFFFFFFF, A_options->SaveSyntax, (void*)&callbackInfo, MsgObjToFile );
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        if (callbackInfo.fp)
            fclose(callbackInfo.fp);
        PrintError("Error in message to stream", mcStatus);
        MC_Free_Message(A_msgID);
        return SAMP_FAILURE;
    }

    if (callbackInfo.fp)
        fclose(callbackInfo.fp);

    mcStatus = MC_Free_Message(A_msgID);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("MC_Free_Message for request message error", mcStatus);
        return SAMP_FAILURE;
    }

    return SAMP_SUCCESS;
} /* WriteToMessage() */



/********************************************************************
 *
 *  Function    :    WriteToMedia
 *
 *  Parameters  :    Aoptions   - Structure that holds configuration
 *                                parameters
 *                   A_filename - Filename to write to
 *                   A_msgID    - ID of message received to write
 *                   A_msgType  - Character string describing the
 *                                message type
 *                   A_remoteAE - remote application entity title
 *
 *  Returns     :    SAMP_SUCCESS - If successful
 *                   SAMP_FAILURE - If error occurred
 *
 *  Description :    Converts a message received over the network
 *                   into a DICOM-3 formatted file.
 *
 ********************************************************************/
static SAMP_STATUS WriteToMedia(STORAGE_OPTIONS* A_options, char* A_filename, int* A_msgID, char* A_messageType, char *remoteAE)
{
    MC_STATUS        mcStatus;
    SAMP_STATUS      sampStatus;
    CBinfo           callbackInfo;
    TRANSFER_SYNTAX  messageSyntax, resultSyntax;
    char             sopInstanceUID[UI_LENGTH+2] = {0};

    /*
     * Get the transfer syntax that the message was transfered over
     * the network as.  This is to determine if it is JPEG encoded.
     */
    mcStatus = MC_Get_Message_Transfer_Syntax( *A_msgID, &messageSyntax );
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Error on MC_Get_Message_Transfer_Syntax", mcStatus);
        MC_Free_Message(A_msgID);
        return SAMP_FAILURE;
    }
    else
    {
        /*
         * For the standard syntaxes, save in the configured syntax.
         * For all the encapsualted/compressed syntaxes, save in the
         * syntax received.
         */
        switch (messageSyntax)
        {
            case IMPLICIT_LITTLE_ENDIAN:
            case EXPLICIT_LITTLE_ENDIAN:
            case EXPLICIT_BIG_ENDIAN:
            case IMPLICIT_BIG_ENDIAN:
                resultSyntax = A_options->SaveSyntax;
                break;

            default:
                resultSyntax = messageSyntax;
                break;
        }
    }

    /*
     * Now convert message object to a file object.  This changes the
     * tool kit's internal representation of the file from a message to a
     * file object.  It also allows the group 0x0002 elements to be used
     * in the object.  Any other attributes within the message can still
     * be dealt with when it is classified as a file.
     */
    mcStatus = MC_Message_To_File( *A_msgID, A_filename );
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Conversion of message to file", mcStatus);
        MC_Free_File(A_msgID);
        return SAMP_FAILURE;
    }

    /*
     * Add the group 2 elements to the object.
     */
    sampStatus = AddGroup2Elements(A_options, resultSyntax, *A_msgID, remoteAE);
    if ( sampStatus == SAMP_FAILURE )
    {
        PrintError("Adding group two elements", mcStatus);
        MC_Free_File(A_msgID);
        return SAMP_FAILURE;
    }

    if (A_options->Verbose)
    {
        /*
         * Get the SOP Instance UID from the message, and then print out
         * image information
         */
        mcStatus = MC_Get_Value_To_String( *A_msgID, MC_ATT_SOP_INSTANCE_UID, sizeof(sopInstanceUID), sopInstanceUID );
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            PrintError("Unable to get SOP Instance UID from image file",mcStatus);
        }

        printf("Writing image in DICOM Part 10 format:\n");
        printf("\tMessage Type: %s\n", A_messageType);
        printf("\tFile Name: %s\n", A_filename);
        printf("\tStored Transfer syntax: %s\n", GetSyntaxDescription(resultSyntax));
        printf("\tSOP Instance UID: %s\n", sopInstanceUID );
    }
    else
        printf("Writing %s image in DICOM Part 10 format:  %s\n", A_messageType, A_filename);

     fflush(stdout);
    /*
     * Write out the new file.
     */
    mcStatus = MC_Write_File( *A_msgID, 0, &callbackInfo, FileObjToMedia );
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        if (callbackInfo.fp)
            fclose(callbackInfo.fp);
        PrintError("MC_Write_File failed", mcStatus);
        MC_Free_File(A_msgID);
        return SAMP_FAILURE;
    }

    if (callbackInfo.fp)
        fclose(callbackInfo.fp);

    mcStatus = MC_Free_File(A_msgID);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("MC_Free_File for converted message failed", mcStatus);
        return SAMP_FAILURE;
    }

    return SAMP_SUCCESS;
} /* WriteToMedia() */


/********************************************************************
 *
 *  Function    :    ReadRawAndWriteToMedia
 *
 *  Parameters  :    Aoptions       - Structure that holds configuration
 *                                    parameters
 *                   A_filename     - filename to write to
 *                   A_msgID        - ID of message received to write
 *                   A_messageType  - Character string describing the
 *                                    message type
 *                   A_assocID      - association ID 
 *                   A_remoteAE     - remote application entity title
 *
 *  Returns     :    SAMP_SUCCESS - If successful
 *                   SAMP_FAILURE - If error occurred
 *
 *  Description :    Converts a message received over the network
 *                   into a DICOM-3 formatted file.
 *
 ********************************************************************/
static SAMP_STATUS ReadRawAndWriteToMedia( STORAGE_OPTIONS* A_options, char* A_filename, int* A_msgID, char* A_messageType, int A_assocID, char *A_remoteAE)
{
    MC_STATUS        mcStatus;
    SAMP_STATUS      sampStatus;
    CBinfo           callbackInfo;
    TRANSFER_SYNTAX  messageSyntax, resultSyntax;
    char             sopInstanceUID[UI_LENGTH+2] = {0};

    /*
     * Get the transfer syntax that the message was transfered over
     * the network as.  This is to determine if it is JPEG encoded.
     */
    mcStatus = MC_Get_Message_Transfer_Syntax( *A_msgID, &messageSyntax );
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Error on MC_Get_Message_Transfer_Syntax", mcStatus);
        MC_Free_Message(A_msgID);
        return SAMP_FAILURE;
    }
    /*
     * Since the data set is read as raw, transfer syntax can't change
     */
    resultSyntax = messageSyntax;

    /*
     * Add the group 2 elements to the object using the group 0 elements.
     * MC_Message_To_File() will remove all group 0 elements, so group 2 elements must be added first.
     */
    sampStatus = AddGroup2ElementsFromGroup0(A_options, *A_msgID, A_remoteAE);
    if ( sampStatus == SAMP_FAILURE )
    {
        PrintError("Adding group two elements", sampStatus);
        MC_Free_Message(A_msgID);
        return SAMP_FAILURE;
    }

    /*
     * Now convert message object to a file object.  This changes the
     * tool kit's internal representation of the file from a message to a
     * file object.  It also allows the group 0x0002 elements to be used
     * in the object.  Any other attributes within the message can still
     * be dealt with when it is classified as a file.
     */
    mcStatus = MC_Message_To_File( *A_msgID, A_filename );
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Conversion of message to file", mcStatus);
        MC_Free_Message(A_msgID);
        return SAMP_FAILURE;
    }

    mcStatus = MC_Set_Message_Transfer_Syntax(*A_msgID, messageSyntax);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Setting Transfer Syntax to file", mcStatus);
        MC_Free_Message(A_msgID);
        return SAMP_FAILURE;
    }

    if (A_options->Verbose)
    {
        /*
         * Get the SOP Instance UID from the message, and then print out
         * image information
         */
        mcStatus = MC_Get_Value_To_String( *A_msgID, MC_ATT_MEDIA_STORAGE_SOP_INSTANCE_UID, sizeof(sopInstanceUID), sopInstanceUID );
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            PrintError("Unable to get SOP Instance UID from image file",mcStatus);
        }

        printf("Writing image in DICOM Part 10 format:\n");
        printf("\tMessage Type: %s\n", A_messageType);
        printf("\tFile Name: %s\n", A_filename);
        printf("\tStored Transfer syntax: %s\n", GetSyntaxDescription(resultSyntax));
        printf("\tSOP Instance UID: %s\n", sopInstanceUID );
    }
    else
        printf("Writing %s image in DICOM Part 10 format:  %s\n", A_messageType, A_filename);

     fflush(stdout);

    /*
     * Stream out the group 2 info (meta header)
     */
    callbackInfo.append = 0;  /* set append mode to false */
    strcpy(callbackInfo.filename, A_filename);

    mcStatus = MC_Message_To_Stream ( *A_msgID, 0x00020000, 0x0002FFFF, EXPLICIT_LITTLE_ENDIAN, &callbackInfo, StreamToFile );
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Failed to stream out meta header", mcStatus);
        MC_Free_Message(A_msgID);
        return SAMP_FAILURE;
    }

    /*
     * Read the entire data set as raw (no parsing) and directly write to stream
     */
    callbackInfo.append = 1; /* append the data set after the meta header */
    mcStatus = MC_Continue_Read_Message_To_Stream( A_assocID, A_msgID, &callbackInfo, StreamToFile);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Failed to read and stream out data set", mcStatus);
        MC_Free_File(A_msgID);
        return SAMP_FAILURE;
    }

    mcStatus = MC_Free_File(A_msgID);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("MC_Free_File for converted message failed", mcStatus);
        return SAMP_FAILURE;
    }

    return SAMP_SUCCESS;
} /* ReadRawAndWriteToMedia() */

/********************************************************************
 *
 *  Function    :   FileMetaInfoVersion
 *
 *  Parameters  :
 *
 *  Returns     :   MC_NORMAL_COMPLETION
 *
 *  Description :   Adds group 2 element for File Meta Information Version
 *                  to the preamble of the DICOM file object
 *
 ********************************************************************/
static MC_STATUS NOEXP_FUNC FileMetaInfoVersion(int A_msgID,
                                                unsigned long A_tag,
                                                int A_isFirst,
                                                void* A_info, 
                                                int* A_dataSize, 
                                                void** A_dataBufferPtr, 
                                                int* A_isLastPtr)
{
    static char version[] = {0x00,0x01};

    *A_dataSize = 2;
    *A_dataBufferPtr = version;
    *A_isLastPtr = 1;

    return MC_NORMAL_COMPLETION;

} /* FileMetaInfoVersion() */

/****************************************************************************
 *
 *  Function    :   AddGroup2Elements
 *
 *  Parameters  :   A_options     - Input parameters
 *                  A_transSyntax - structure for config options
 *                  A_fileID      - File to add meta information to
 *                  A_remoteAE    - remote application entity title
 *
 *  Returns     :   SAMP_STATUS
 *
 *  Description :   Sets group two information in a media file
 *
 ****************************************************************************/
static SAMP_STATUS AddGroup2Elements( STORAGE_OPTIONS* A_options, TRANSFER_SYNTAX A_transSyntax, int A_fileID, char *A_remoteAE)
{
    MC_STATUS mcStatus;
    char      uidBuffer[UI_LENGTH+2] = {0}, syntaxUID[UI_LENGTH+2] = {0};

    /*
     * Get the correct UID for the new transfer syntax
     */
    mcStatus = MC_Get_Transfer_Syntax_From_Enum(A_transSyntax, syntaxUID, sizeof(syntaxUID));
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to get Transfer Syntax UID", mcStatus);
        return SAMP_FAILURE;
    }

    /*
     * Set the new transfer syntax for this message
     */
    mcStatus = MC_Set_Value_From_String(A_fileID, MC_ATT_TRANSFER_SYNTAX_UID, syntaxUID);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to set Transfer Syntax UID in group 2 elements", mcStatus);
        return SAMP_FAILURE;
    }

    /*
     * Set other media group 2 elements
     */
    mcStatus = MC_Set_Value_From_Function( A_fileID, MC_ATT_FILE_META_INFORMATION_VERSION, NULL, FileMetaInfoVersion );
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to add File Meta Information Version", mcStatus);
        return SAMP_FAILURE;
    }

    mcStatus = MC_Get_Value_To_String( A_fileID, MC_ATT_SOP_CLASS_UID, sizeof(uidBuffer), uidBuffer );
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to get SOP Class UID from image file", mcStatus);
        return SAMP_FAILURE;
    }

    mcStatus = MC_Set_Value_From_String( A_fileID, MC_ATT_MEDIA_STORAGE_SOP_CLASS_UID, uidBuffer);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to add Media Storage SOP Class UID", mcStatus);
        return SAMP_FAILURE;
    }

    mcStatus = MC_Get_Value_To_String(A_fileID, MC_ATT_SOP_INSTANCE_UID, sizeof(uidBuffer), uidBuffer);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to get SOP Instance UID from image file",mcStatus);
        return SAMP_FAILURE;
    }

    mcStatus = MC_Set_Value_From_String( A_fileID, MC_ATT_MEDIA_STORAGE_SOP_INSTANCE_UID, uidBuffer);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to add Media Storage SOP Instance UID",mcStatus);
        return SAMP_FAILURE;
    }

    mcStatus = MC_Set_Value_From_String( A_fileID, MC_ATT_SOURCE_APPLICATION_ENTITY_TITLE, A_options->LocalAE);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to add Source Application Entity Title",mcStatus);
        return SAMP_FAILURE;
    }

    if(A_remoteAE != NULL)
    {
        mcStatus = MC_Set_Value_From_String(A_fileID, MC_ATT_SENDING_APPLICATION_ENTITY_TITLE, A_remoteAE);
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            PrintError("Unable to add Sending Application Entity Title",mcStatus);
            return SAMP_FAILURE;
        }
    }

    mcStatus = MC_Set_Value_From_String(A_fileID, MC_ATT_RECEIVING_APPLICATION_ENTITY_TITLE, A_options->LocalAE);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to add Receiving Application Entity Title",mcStatus);
        return SAMP_FAILURE;
    }

    return SAMP_SUCCESS;

} /* AddGroup2Elements() */


/****************************************************************************
 *
 *  Function    :   AddGroup2ElementsFromGroup0
 *
 *  Parameters  :   A_options  - Input parameters
 *                  A_fileID   - File to add meta information to
 *                  A_remoteAE - remote application entity title
 *
 *  Returns     :   SAMP_STATUS
 *
 *  Description :   Sets group two information in a media file
 *
 ****************************************************************************/
static SAMP_STATUS AddGroup2ElementsFromGroup0(STORAGE_OPTIONS* A_options, int A_fileID, char *A_remoteAE)
{
    MC_STATUS mcStatus;
    char      uidBuffer[UI_LENGTH+2] = {0}, syntaxUID[UI_LENGTH+2] = {0}, buffer[UI_LENGTH+2] = {0};
    TRANSFER_SYNTAX messageSyntax;

    /*
     * Get the message transfer syntax
     */
    mcStatus = MC_Get_Message_Transfer_Syntax(A_fileID, &messageSyntax);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to get Transfer Syntax from message", mcStatus);
        return SAMP_FAILURE;
    }

    /*
     * Get the correct UID for the new transfer syntax
     */
    mcStatus = MC_Get_Transfer_Syntax_From_Enum(messageSyntax, syntaxUID, sizeof(syntaxUID));
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to translate Transfer Syntax UID", mcStatus);
        return SAMP_FAILURE;
    }

    /*
     * Set the new transfer syntax for this message
     */
    mcStatus = MC_Set_Value_From_String(A_fileID, MC_ATT_TRANSFER_SYNTAX_UID, syntaxUID);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to set Transfer Syntax UID in group 2 elements", mcStatus);
        return SAMP_FAILURE;
    }

    /*
     * Set other media group 2 elements
     */
    mcStatus = MC_Set_Value_From_Function( A_fileID, MC_ATT_FILE_META_INFORMATION_VERSION, NULL, FileMetaInfoVersion );
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to add File Meta Information Version", mcStatus);
        return SAMP_FAILURE;
    }

    mcStatus = MC_Get_Value_To_String( A_fileID, MC_ATT_AFFECTED_SOP_CLASS_UID, sizeof(uidBuffer), uidBuffer );
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to get SOP Class UID from image file", mcStatus);
        return SAMP_FAILURE;
    }

    mcStatus = MC_Set_Value_From_String( A_fileID, MC_ATT_MEDIA_STORAGE_SOP_CLASS_UID, uidBuffer);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to add Media Storage SOP Class UID", mcStatus);
        return SAMP_FAILURE;
    }

    mcStatus = MC_Get_Value_To_String(A_fileID, MC_ATT_AFFECTED_SOP_INSTANCE_UID, sizeof(uidBuffer), uidBuffer);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to get SOP Instance UID from image file", mcStatus);
        return SAMP_FAILURE;
    }

    mcStatus = MC_Set_Value_From_String( A_fileID, MC_ATT_MEDIA_STORAGE_SOP_INSTANCE_UID, uidBuffer);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to add Media Storage SOP Instance UID", mcStatus);
        return SAMP_FAILURE;
    }

    mcStatus = MC_Set_Value_From_String( A_fileID, MC_ATT_SOURCE_APPLICATION_ENTITY_TITLE, A_options->LocalAE);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to add Source Application Entity Title", mcStatus);
        return SAMP_FAILURE;
    }

    if(A_remoteAE != NULL)
    {
        mcStatus = MC_Set_Value_From_String(A_fileID, MC_ATT_SENDING_APPLICATION_ENTITY_TITLE, A_remoteAE);
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            PrintError("Unable to add Sending Application Entity Title", mcStatus);
            return SAMP_FAILURE;
        }
    }

    mcStatus = MC_Set_Value_From_String(A_fileID, MC_ATT_RECEIVING_APPLICATION_ENTITY_TITLE, A_options->LocalAE);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to add Receiving Application Entity Title", mcStatus);
        return SAMP_FAILURE;
    }

    mcStatus = MC_Get_String_Config_Value(IMPLEMENTATION_CLASS_UID, sizeof(buffer), buffer);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to get Implementation Class UID from config", mcStatus);
        return SAMP_FAILURE;
    }

    mcStatus = MC_Set_Value_From_String( A_fileID, MEDIA_IMPLEMENTATION_CLASS_UID, buffer);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to add Implementation Class UID",mcStatus);
        return SAMP_FAILURE;
    }

    mcStatus = MC_Get_String_Config_Value(IMPLEMENTATION_VERSION, sizeof(buffer), buffer);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to get Implementation Version Name from config", mcStatus);
        return SAMP_FAILURE;
    }

    mcStatus = MC_Set_Value_From_String( A_fileID, MEDIA_IMPLEMENTATION_VER_NAME, buffer);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintError("Unable to add Implementation Version Name", mcStatus);
        return SAMP_FAILURE;
    }
    return SAMP_SUCCESS;

} /* AddGroup2ElementsFromGroup0() */



/****************************************************************************
 *
 *  Function    :   FileObjToMedia
 *
 *  Parameters  :   A_filename   - Filename to write to
 *                  A_userInfo   - Information to store between calls to this
 *                                 function
 *                  A_dataSize   - Size of A_dataBuffer
 *                  A_dataBuffer - Buffer containing data to write
 *                  A_isFirst    - set to true on first call
 *                  A_isLast     - Is set to true on the final call
 *
 *  Returns     :   MC_NORMAL_COMPLETION on success, any other MC_STATUS
 *                  value on failure.
 *
 *  Description :   Callback function used to write DICOM file object to
 *                  media.  A pointer to this function is passed to
 *                  MC_Write_File
 *
 ****************************************************************************/
static MC_STATUS NOEXP_FUNC FileObjToMedia( char*    A_filename,
                                            void*    A_userInfo,
                                            int      A_dataSize,
                                            void*    A_dataBuffer,
                                            int      A_isFirst,
                                            int      A_isLast)
{
    size_t     count;
    CBinfo*    cbInfo = (CBinfo*)A_userInfo;
    int        retStatus;

    if (A_isFirst)
    {
        cbInfo->fp = fopen(A_filename, BINARY_WRITE);

        retStatus = setvbuf(cbInfo->fp, (char *)NULL, _IOFBF, 32768);
        if ( retStatus != 0 )
        {
            printf("WARNING:  Unable to set IO buffering on input file.\n");
        }
    }

    if (!cbInfo->fp)
       return MC_CANNOT_COMPLY;

    count = fwrite(A_dataBuffer, 1, A_dataSize, cbInfo->fp);
    if (count != (size_t)A_dataSize)
    {
        printf("fwrite error");
        return MC_CANNOT_COMPLY;
    }

    /*1-2WAPH*/
    retStatus = fflush(cbInfo->fp);
    if ( retStatus != 0 )
    {
        printf("\tfflush error\n");
        fclose(cbInfo->fp);
        cbInfo->fp = NULL;
        return MC_CANNOT_COMPLY;
    }
    if (A_isLast)
    {
        /*
         * NULL ->fp so that the routine calling MC_Write file knows
         * not to close the stream.
         */
        retStatus = fclose(cbInfo->fp);
        if ( retStatus != 0 )
        {
            printf("\tfclose error\n");
            cbInfo->fp = NULL;
            return MC_CANNOT_COMPLY;
        }
        cbInfo->fp = NULL;
    }

    return MC_NORMAL_COMPLETION;

} /* FileObjToMedia() */

/*************************************************************************
 *
 *  Function    :   MsgObjToFile
 *
 *  Parameters  :   A_msgID      - Message id of message being read
 *                  A_userInfo   - Information to store between calls to
 *                                 this function
 *                  A_dataSize   - Length of data read
 *                  A_dataBuffer - Buffer where read data is stored
 *                  A_isFirst    - Flag to tell if this is the first call
 *                  A_isLast     - Flag to tell if this is the last call
 *
 *  Returns     :   MC_NORMAL_COMPLETION on success, any other MC_STATUS
 *                  value on failure.
 *
 *  Description :   This function is used to write data in the "Stream"
 *                  format.  A pointer to the function is passed as a
 *                  parameter to MC_Message_To_Stream.
 *
 **************************************************************************/
static MC_STATUS NOEXP_FUNC MsgObjToFile(   int      A_msgID,
                                            void*    A_userInfo,
                                            int      A_dataSize,
                                            void*    A_dataBuffer,
                                            int      A_isFirst,
                                            int      A_isLast )
{
    CBinfo*     callbackInfo = (CBinfo*)A_userInfo;
    size_t      count;
    int         retStatus;

    if (!callbackInfo->fp)
    {
        printf("\tUnable to open output file\n");
        return MC_CANNOT_COMPLY;
    }

    count = fwrite(A_dataBuffer, 1, A_dataSize, callbackInfo->fp);
    if (count != (size_t)A_dataSize)
    {
        printf("\tfwrite error\n");
        return MC_CANNOT_COMPLY;
    }

    /*1-2WAPH*/
    retStatus = fflush(callbackInfo->fp);
    if ( retStatus != 0 )
    {
        printf("\tfflush error\n");
        fclose(callbackInfo->fp);
        callbackInfo->fp = NULL;
        return MC_CANNOT_COMPLY;
    }
    if (A_isLast)
    {
        retStatus = fclose(callbackInfo->fp);
        if ( retStatus != 0 )
        {
            printf("\tfclose error\n");
            callbackInfo->fp = NULL;
            return MC_CANNOT_COMPLY;
        }
        callbackInfo->fp = NULL;
    }

    return MC_NORMAL_COMPLETION;
} /* MsgObjToFile() */


/*************************************************************************
 *
 *  Function    :   StreamToFile
 *
 *  Parameters  :   A_msgID      - Message id of message being read
 *                  A_userInfo   - Information to store between calls to
 *                                 this function
 *                  A_dataSize   - Length of data read
 *                  A_dataBuffer - Buffer where read data is stored
 *                  A_isFirst    - Flag to tell if this is the first call
 *                  A_isLast     - Flag to tell if this is the last call
 *
 *  Returns     :   MC_NORMAL_COMPLETION on success, any other MC_STATUS
 *                  value on failure.
 *
 *  Description :   This function is used to write data in the "Stream"
 *                  format.  A pointer to the function is passed as a
 *                  parameter to MC_Message_To_Stream.
 *
 **************************************************************************/
static MC_STATUS NOEXP_FUNC StreamToFile(   int      A_msgID,
                                            void*    A_userInfo,
                                            int      A_dataSize,
                                            void*    A_dataBuffer,
                                            int      A_isFirst,
                                            int      A_isLast   )
{
    CBinfo*     callbackInfo = (CBinfo*)A_userInfo;
    size_t      count;
    int         retStatus;

    if (A_isFirst)
    {
        callbackInfo->fp = fopen(callbackInfo->filename, BINARY_READ_APPEND);
    }

    if (!callbackInfo->fp)
    {
        printf("\tUnable to open output file\n");
        return MC_CANNOT_COMPLY;
    }

    count = fwrite(A_dataBuffer, 1, A_dataSize, callbackInfo->fp);
    if (count != (size_t)A_dataSize)
    {
        printf("\tfwrite error\n");
        return MC_CANNOT_COMPLY;
    }

    /*1-2WAPH*/
    retStatus = fflush(callbackInfo->fp);
    if ( retStatus != 0 )
    {
        printf("\tfflush error\n");

        fclose(callbackInfo->fp);    
        callbackInfo->fp = NULL;

        return MC_CANNOT_COMPLY;
    }

    if (A_isLast)
    {
        retStatus = fclose(callbackInfo->fp);
        callbackInfo->fp = NULL;

        if ( retStatus != 0 )
        {
            printf("\tfclose error\n");
            return MC_CANNOT_COMPLY;
        }

    }
    return MC_NORMAL_COMPLETION;
} /* StreamToFile() */

/****************************************************************************
 *
 *  Function    :   PrintError
 *
 *  Description :   Display a text string on one line and the error message
 *                  for a given error on the next line.
 *
 ****************************************************************************/
static void PrintError(char* A_string, MC_STATUS A_mcStatus)
{
    char        prefix[30] = {0};
    /*
     *  Need process ID number for messages
     */
#ifdef UNIX
    sprintf(prefix, "PID %d", getpid() );
#endif
    printf("%s\t%s:\n",prefix,A_string);
    printf("%s\t\t%s\n", prefix,MC_Error_Message(A_mcStatus));
    fflush(stdout);
}

/****************************************************************************
 *
 *  Function    :   Exception_Handler
 *
 *  Description :   This is our SIGINT routine (The user wants to shut down)
 *
 ****************************************************************************/
static void Exception_Handler(int Asigno)
{
    int    Return   = EXIT_SUCCESS;
    DWORD  ThreadId = GetCurrentThreadId();

    if ((Asigno == SIGINT) || (Asigno == SIGBREAK))
    {
        /* The G_threadCount variable is a shared global.  Therefore, before using it we must enter a critical section. */
        printf( "TID(%lu)\tEnding thread by a SIGNAL.", ThreadId );

        EnterCriticalSection ( &G_CriticalSection );
        --G_threadCount;
        LeaveCriticalSection ( &G_CriticalSection );

        exit(Return);
    }

    printf("TID(%lu)\tMergecom Toolkit exception, code %X\n", GetCurrentThreadId(), Asigno );
    fflush(stdout);
}

void End_Thread(const char *msg)
{
    if ((msg != (char*)NULL) && (strlen(msg) != 0))
        printf("%s", msg);

    EnterCriticalSection ( &G_CriticalSection );
    --G_threadCount;
    LeaveCriticalSection ( &G_CriticalSection );

    _endthread();
}

