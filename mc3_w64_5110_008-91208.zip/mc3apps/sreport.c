
/*******************************************************************************
 *                                                                             *
 *      System: Merge DICOM Tool Kit Sample Applications                       *
 *                                                                             *
 *      Author: Merge Healthcare, an IBM Company                               *
 *                                                                             *
 *      Description: Structure Report Sample Application.                      *
 *                                                                             *
 *******************************************************************************
 *                                                                             *
 *   Copyright (C) IBM Corporation 2016, 2020.                                 *
 *   Copyright (C) Merge Healthcare 2005, 2016.                                *
 *                                                                             *
 *   All rights reserved.                                                      *
 *                                                                             *
 *  This software is furnished under license and may be used and copied only   *
 *  in accordance with the terms of such license and with the inclusion of the *
 *  above copyright notice.                                                    *
 *                                                                             *
 *  This software or any other copies thereof may not be provided or otherwise *
 *  made available to any other person. No title to and ownership of the       *
 *  software is hereby transferred.                                            *
 *                                                                             *
 *******************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <string.h>
#include <memory.h>

#include "mc3media.h"
#include "mc3msg.h"
#include "mcstatus.h"
#include "mergecom.h"
#include "diction.h"
#include "mc3services.h"

#ifdef _WIN32
    #pragma warning(disable : 4996)
#endif

#include <fcntl.h>

/* Mark unreferenced variables/functions with UNUSED to avoid compiler warnings. */
#ifdef __GNUC__
#define UNUSED __attribute__((__unused__))
#else
#define UNUSED /* empty */
#endif

#ifdef BIG_END
#define LONG_FROM_LITTLE_ENDIAN(SOURCE, DEST) \
    { \
      ((unsigned char*)(DEST))[0] = ((unsigned char*)(SOURCE))[3]; \
      ((unsigned char*)(DEST))[1] = ((unsigned char*)(SOURCE))[2]; \
      ((unsigned char*)(DEST))[2] = ((unsigned char*)(SOURCE))[1]; \
      ((unsigned char*)(DEST))[3] = ((unsigned char*)(SOURCE))[0]; \
    }
#else
#define LONG_FROM_LITTLE_ENDIAN(SOURCE, DEST) \
    { \
      ((unsigned char*)(DEST))[0] = ((unsigned char*)(SOURCE))[0]; \
      ((unsigned char*)(DEST))[1] = ((unsigned char*)(SOURCE))[1]; \
      ((unsigned char*)(DEST))[2] = ((unsigned char*)(SOURCE))[2]; \
      ((unsigned char*)(DEST))[3] = ((unsigned char*)(SOURCE))[3]; \
    }
#endif

#define EXIT_SUCCESS      0
#define EXIT_FAILURE      1
#define FILENAME_LEN      512
#define MC_FAILED(STATUS) STATUS != MC_NORMAL_COMPLETION
#define WORK_BUFFER_SIZE  28*1024

/*
 *  Internal MC Toolkit structure, SHOULD NOT be changed
 */
typedef struct FileOpInfo_struct
{
    char*       FileName;
    int         BufferSize;
    void*       Buffer;
    MTI_BOOLEAN Readonly;
    MTI_BOOLEAN Truncate;
    MTI_BOOLEAN FileOpen;
    FILE*       FileHandle;
    int         LastOp;
    long        Offset;
    long        Size;
} FileOpInfo;

typedef struct app_config
{
    int         applicationID;
    char        inputFile[FILENAME_LEN];
    MTI_BOOLEAN read;
    MTI_BOOLEAN write;
} AppConfig;

/* structure used in SetAttributes */
typedef struct AttributeValueStruct
{
    unsigned long   tag;
    char            type; 
                    /*  s = string, 
                        u = unsigned long, 
                        t = long string (the value is the number of characters) 
                        i = int
                        j = unsigned int
                        k = long int
                        e = end (the last element in an array of AttributeValue array 
                        n = set value to null
                        m = set value to empty
                        d = double (the value is a pointer to double)
                        f = float
                        x = add attribute only, no value 
                        h = unsigned short
                        z = string, set value only 
                        q = an empty value 
                    */
    union
    {
        char*           svalue;
        long            lvalue;
        double*         dvalue;
        float*          fvalue;
        unsigned short* hvalue;  
    } val;
} AttributeValue;

static void ShowUsage(void);
static void CleanUp(AppConfig *appConfig);
static int  GetOptions(int A_argc, char **A_argv, AppConfig *appConfig);
static void Replace(char *string, char oldCh, char newCh);
static int  LastIndexOf(char *string, char ch);

static int  Read(AppConfig *appConfig);
static int  ReadSR(int msgID);
static void ReadSRContent(int id);
static void ReadSRRelationship(int id, SR_RELATIONSHIP relationship);
static void ReadSRType(int id, SR_CONTENT_TYPE type);
static char* GetSRContentType(SR_CONTENT_TYPE type);

static int  Write(AppConfig *appConfig);
static char* GenerateUID(char* buffer);
static void SetAttributes(int msg, AttributeValue* values);

MC_STATUS FileWriteCallbackFunction( int msgID, void* userInfo, int dataSize, void* dataBuffer, int isFirst, int isLast );
MC_STATUS FileReadCallbackFunction(char* filename, void* AuserInfo, int* AdataSizePtr, void** AdataBufferPtr, int AisFirst, int* AisLastPtr);

static int  recur = 0;
static char *recurstr = "-------------------------------------------------------------------------------------------------";

static AttributeValue srAttribs[] = {
                    { MEDIA_FILE_META_INFO_VER, 'h', { (char*) 0x0100 } },
                    { MEDIA_TRANSFER_SYNTAX_UID, 's', { "1.2.840.10008.1.2.1" } },
                    { MEDIA_IMPLEMENTATION_CLASS_UID, 's', { "2.16.840.1.113669.2.931128" } },
                    { MEDIA_IMPLEMENTATION_VER_NAME, 's', { "MergeCOM3_1.0" } },
                    { MEDIA_STORAGE_SOP_CLASS_UID, 's', { "1.2.840.10008.5.1.4.1.1.88.33" } },
                    { MEDIA_STORAGE_SOP_INSTANCE_UID, 's', {"1.2.3.4.5.6.7.300" } },
                    { 0x00080016, 's', { "1.2.840.10008.5.1.4.1.1.88.33" } },
                    { 0x00080018, 's', { "1.2.3.4.5.6.7.300" } },
                    { 0x00080020, 's', { "19991029" } },
                    { 0x00080023, 's', { "19991029" } },
                    { 0x00080030, 's', { "154500" } },
                    { 0x00080033, 's', { "154510" } },
                    { 0x00080050, 's', { "123456" } },
                    { 0x00080060, 's', { "SR" } },
                    { 0x00080070, 's', { "MERGE" } },
                    { 0x00080090, 's', { "Luke^Will^^Dr.^M.D." } },
                    { 0x00081111, 'q', { "NULL" } },
                    { 0x00100010, 's', { "Jane^Doo" } },
                    { 0x00100020, 's', { "234567" } },
                    { 0x00100030, 's', { "19991109" } },
                    { 0x00100040, 's', { "F" } },
                    { 0x0020000D, 's', { "1.2.3.4.5.6.7.100" } },
                    { 0x0020000E, 's', { "1.2.3.4.5.6.7.200" } },
                    { 0x00200010, 's', { "345678" } },
                    { 0x00200011, 's', { "1" } },
                    { 0x00200013, 's', { "1" } },
                    { 0x0040A491, 's', { "COMPLETE" } },
                    { 0x0040A493, 's', { "UNVERIFIED" } },
                    { 0x0040A372, 'q', { "NULL" } },
                    { 0, 'e', {NULL} }
};

static char versionString[256];

/*****************************************************************************
**
** NAME
**    main - SR sample main program
**
** SYNOPSIS
**    SR
**
** DESCRIPTION
**
**  Structure Report sample is used to demonstrate a reading and writing structure report data using SR API.
**
**************** SR Writing ******************
**
**         MC_STATUS MC_SRH_Create_SR 
**         MC_STATUS MC_SRH_Free_SR
**         MC_STATUS MC_SRH_Add_TEXT_Child
**         MC_STATUS MC_SRH_Add_CODE_Child
**         MC_STATUS MC_SRH_Set_NUM_Qualifier
**         MC_STATUS MC_SRH_Set_NUM_Next_Data
**         MC_STATUS MC_SRH_Add_NUM_Child
**         MC_STATUS MC_SRH_Add_DATETIME_Child
**         MC_STATUS MC_SRH_Add_DATE_Child
**         MC_STATUS MC_SRH_Add_TIME_Child
**         MC_STATUS MC_SRH_Add_UIDREF_Child
**         MC_STATUS MC_SRH_Add_PNAME_Child
**         MC_STATUS MC_SRH_Add_SCOORD_Child
**         MC_STATUS MC_SRH_Set_SCOORD_Next_Data
**         MC_STATUS MC_SRH_Add_SCOORD3D_Child
**         MC_STATUS MC_SRH_Set_SCOORD3D_Next_Data
**         MC_STATUS MC_SRH_Add_TCOORD_R_Child
**         MC_STATUS MC_SRH_Set_TCOORD_R_Next_Data
**         MC_STATUS MC_SRH_Add_TCOORD_O_Child
**         MC_STATUS MC_SRH_Set_TCOORD_O_Next_Data
**         MC_STATUS MC_SRH_Add_TCOORD_D_Child
**         MC_STATUS MC_SRH_Set_TCOORD_D_Next_Data
**         MC_STATUS MC_SRH_Add_COMPOSITE_Child
**         MC_STATUS MC_SRH_Add_IMAGE_Child
**         MC_STATUS MC_SRH_Set_IMAGE_Frames
**         MC_STATUS MC_SRH_Add_WAVEFORM_Child
**         MC_STATUS MC_SRH_Set_WAVEFORM_Channels
**         MC_STATUS MC_SRH_Add_CONTAINER_Child
**         MC_STATUS MC_SRH_Set_Concept_Name
**         
**************** SR Reading ****************
**         
**         MC_STATUS MC_SRH_Get_NodeType
**         MC_STATUS MC_SRH_Get_First_Child
**         MC_STATUS MC_SRH_Get_Next_Child
**         MC_STATUS MC_SRH_Get_Concept_Name
**         MC_STATUS MC_SRH_Get_TEXT_Data 
**         MC_STATUS MC_SRH_Get_CODE_Data
**         MC_STATUS MC_SRH_Get_NUM_Data
**         MC_STATUS MC_SRH_Get_NUM_Next_Data
**         MC_STATUS MC_SRH_Get_NUM_Qualifier
**         MC_STATUS MC_SRH_Get_DATETIME_Data 
**         MC_STATUS MC_SRH_Get_DATE_Data 
**         MC_STATUS MC_SRH_Get_TIME_Data 
**         MC_STATUS MC_SRH_Get_UIDREF_Data 
**         MC_STATUS MC_SRH_Get_PNAME_Data
**         MC_STATUS MC_SRH_Get_SCOORD_First_Data
**         MC_STATUS MC_SRH_Get_SCOORD_Next_Data
**         MC_STATUS MC_SRH_Get_SCOORD3D_First_Data
**         MC_STATUS MC_SRH_Get_SCOORD3D_Next_Data
**         MC_STATUS MC_SRH_Get_TCOORD_D_First_Data 
**         MC_STATUS MC_SRH_Get_TCOORD_D_Next_Data
**         MC_STATUS MC_SRH_Get_TCOORD_O_First_Data 
**         MC_STATUS MC_SRH_Get_TCOORD_O_Next_Data
**         MC_STATUS MC_SRH_Get_TCOORD_R_First_Data 
**         MC_STATUS MC_SRH_Get_TCOORD_R_Next_Data 
**         MC_STATUS MC_SRH_Get_COMPOSITE_Data
**         MC_STATUS MC_SRH_Get_IMAGE_Data
**         MC_STATUS MC_SRH_Get_IMAGE_Frames
**         MC_STATUS MC_SRH_Get_WAVEFORM_Data
**         MC_STATUS MC_SRH_Get_WAVEFORM_Channels
**         MC_STATUS MC_SRH_Get_CONTAINER_Data
**         MC_STATUS MC_SRH_Get_Reference
**
******************* UTILITY FUNCTIONS *******************
**
**         MC_STATUS EXP_FUNC MC_SRH_Add_Child
**         MC_STATUS EXP_FUNC MC_SRH_Add_Reference
**         MC_STATUS EXP_FUNC MC_SRH_Create_TEXT_Node 
**         MC_STATUS EXP_FUNC MC_SRH_Create_CODE_Node
**         MC_STATUS EXP_FUNC MC_SRH_Create_NUM_Node
**         MC_STATUS EXP_FUNC MC_SRH_Create_DATETIME_Node
**         MC_STATUS EXP_FUNC MC_SRH_Create_DATE_Node
**         MC_STATUS EXP_FUNC MC_SRH_Create_TIME_Node
**         MC_STATUS EXP_FUNC MC_SRH_Create_UIDREF_Node
**         MC_STATUS EXP_FUNC MC_SRH_Create_PNAME_Node
**         MC_STATUS EXP_FUNC MC_SRH_Create_SCOORD_Node
**         MC_STATUS EXP_FUNC MC_SRH_Create_SCOORD3D_Node
**         MC_STATUS EXP_FUNC MC_SRH_Create_TCOORD_R_Node
**         MC_STATUS EXP_FUNC MC_SRH_Create_TCOORD_O_Node
**         MC_STATUS EXP_FUNC MC_SRH_Create_TCOORD_D_Node
**         MC_STATUS EXP_FUNC MC_SRH_Create_COMPOSITE_Node
**         MC_STATUS EXP_FUNC MC_SRH_Create_IMAGE_Node
**         MC_STATUS EXP_FUNC MC_SRH_Create_WAVEFORM_Node
**         MC_STATUS EXP_FUNC MC_SRH_Create_CONTAINER_Node
**
*****************************************************************************/
int main(int argc, char** argv)
{
    MC_STATUS   mcStatus;
    AppConfig   appConfig = {0};

    /*
     * Set up the default variables and get the command line options
     */
    if(GetOptions(argc, argv, &appConfig))
    {
        /*
         *  SR sample reads the input structure report file from data storage, creates and writes output structure report file.
         */
        ShowUsage();
        return EXIT_FAILURE;
    }

    /* ------------------------------------------------------- */
    /* This call MUST be the first call made to the library!!! */
    /* ------------------------------------------------------- */
    mcStatus = MC_Library_Initialization(NULL, NULL, NULL);
    if(MC_FAILED(mcStatus))
    {
        printf("Unable to initialize MC library\n");
        return(EXIT_FAILURE);
    }

    mcStatus = MC_Get_Version_String(sizeof(versionString), versionString);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        printf("Unable to get MC Library Version\n");
        return(EXIT_FAILURE);
    }

    /*
     * Register local application title
     */
    mcStatus = MC_Register_Application(&appConfig.applicationID, "SR_SAMPLE");
    if(MC_FAILED(mcStatus))
    {
        printf("Failed to register MCapplication\n");
        return(EXIT_FAILURE);
    }

    /*
     *  Read() a structure report file
     */
    if(appConfig.read)
    {
        printf("Reading SR file [%s]\n", appConfig.inputFile);

        if (Read(&appConfig))
        {
            printf("Read failed\n");
            CleanUp(&appConfig);

            return(EXIT_FAILURE);
        }
    }

    /*
     *  Write() a structure report file
     */
    if(appConfig.write)
    {
        printf("Writing SR file [%s]\n", appConfig.inputFile);

        if (Write(&appConfig))
        {
            printf("Read failed\n");
            CleanUp(&appConfig);

            return(EXIT_FAILURE);
        }
    }

    printf("Completed...\n");
    CleanUp(&appConfig);

    return(EXIT_SUCCESS);

} /* main */

static void ShowUsage()
{
    printf("\n");
    printf("Structure Report sample, Version %s\n", versionString);
    printf("(c) 2020 Merge Healthcare, an IBM Company\n");
    printf("All rights reserved.\n\n");
    printf("Usage:\n");
    printf("    sreport|sreportd|sreports [-w] [-r] [-f file_path]\n");
    printf("Options:\n");
    printf("    -w              Write demo SR file (default './srdemo.dcm')\n");
    printf("    -r              Read SR file (file_path mandatory)\n");
    printf("    -f file_path    File to read/write\n");
    
    printf("\n");
}

static void CleanUp(AppConfig* appConfig)
{
    MC_STATUS status;

    status = MC_Release_Application(&appConfig->applicationID);
    if(MC_FAILED(status))
    {
        printf("Failed to release MCapplication\n");
        return;
    }

    status = MC_Library_Release();
    if(MC_FAILED(status))
    {
        printf("Failed to release the library\n");
        return;
    }
}

static int GetOptions(int A_argc, char **A_argv, AppConfig* appConfig)
{
    int ai = 0, ci = 0, error = 0;

    if (A_argc == 1)
    {
        /* use default settings */
        appConfig->write = MTI_TRUE;
        strcpy(appConfig->inputFile,"./srdemo.dcm");
       
        return 0;
    }

    for ( ai = 1; ai < A_argc && strcmp ( A_argv[ai], "--" ) != 0; ai ++ )
    {
        if ( A_argv[ai][0] == '-' )
        {
            for ( ci = 1; ci < (int)strlen ( A_argv[ai] ); ci++ )
            {
                switch ( A_argv[ai][ci] )
                {
                case 'f':        /* Data storage folder */
                    if ( A_argv[ai][ci+1] != '\0' )
                    {
                        error = 1;
                    } 
                    else if ( (ai + 1) == A_argc )
                    {
                        error = 1;
                    } 
                    else
                    {
                        strcpy ( appConfig->inputFile, &(A_argv[ai+1][0]) );
                        ai++;
                        ci = (int)strlen ( A_argv[ai] );
                    }
                    break;
                
                case 'r':
                    appConfig->read = MTI_TRUE;
                    break;
                
                case 'w':
                    appConfig->write = MTI_TRUE;
                    break;

                default:
                    break;

                } /* switch argv */

                if ( error )
                    return error;
            }
        }
    }

    if (appConfig->read)
    {
        appConfig->write = MTI_FALSE;
        if (appConfig->inputFile[0] == 0)
            error = 1;
    }
    else if (appConfig->write)
    {
        appConfig->read = MTI_FALSE;
        if (appConfig->inputFile[0] == 0)
            strcpy(appConfig->inputFile, "./srdemo.dcm");
    }

    return error;
}


/* 
 * Read structure report file using callback mechanism 
 */
static int Read(AppConfig *appConfig)
{
    MC_STATUS   status;
    FileOpInfo  fileOpInfo = {0};
    int fileID = -1;

    fileOpInfo.FileName = appConfig->inputFile;
    
    /* 
     * Create an empty DICOM file
     */
    status = MC_Create_Empty_File(&fileID, fileOpInfo.FileName);
    if(MC_FAILED(status))
    {
        printf("MC_Create_Empty_File failed for %s, error %d (%s)\n", fileOpInfo.FileName, status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    /*
     * Open file and read DICOM attributes using FileReadCallbackFunction
     */
    status = MC_Open_File(appConfig->applicationID, fileID, &fileOpInfo, FileReadCallbackFunction );
    if(MC_FAILED(status))
    {
         printf("MC_Open_File failed for %s, error %d (%s)\n", fileOpInfo.FileName, status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_File_To_Message(fileID);
    if(MC_FAILED(status))
    {
        printf("MC_File_To_Message error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    /* Read Structure Report content */
    if (ReadSR(fileID))
    {
        printf("Failed to read SR %s", fileOpInfo.FileName);
        return(EXIT_FAILURE);
    }

     /* Clean up */
     MC_SRH_Free_SR(fileID);

    return EXIT_SUCCESS;
}


/* 
 * Write structure report file using callback mechanism 
 */
static int Write(AppConfig *appConfig)
{
    MC_STATUS       status;
    char            uid[64] = {0};
    int             srID = -1, childID = -1, currentID = -1, id = -1, refID = -1;

    POINT3D         point3d[] = {{1.0, 2.0, 3.0}, {4.0, 5.0, 6.0}, {7.0, 8.0, 9.0}};
    long            refFrames[] = { 1, 2, 3, 4, 5 };
    unsigned short  refChannels[] = { 1, 2, 3, 4, 5, 6 };

    FileOpInfo      fileOpInfo = {0};
    fileOpInfo.FileName = appConfig->inputFile;

    /*
     * Create OB-GYN ULTRASOUND REPORT. 
     * Template ID "5000"
     * Concept Name Value "125000"
     * Concept Name Scheme "DCM"
     * Concept Name Meaning "OB-GYN Ultrasound Procedure Report"
     */
    status = MC_SRH_Create_SR(Services.STANDARD_ENHANCED_SR, "5000", SR_CC_SEPARATE, "125000","DCM", "OB-GYN Ultrasound Procedure Report", &srID );
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Create_SR failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    /*
    ** Create image library
    */
    status = MC_SRH_Add_CONTAINER_Child(srID, SR_REL_CONTAINS, SR_CC_SEPARATE, NULL, &childID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Add_CONTAINER_Child failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Set_Concept_Name(childID, "111028", "DCM", "Image Library");
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_Concept_Name failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Add_COMPOSITE_Child(childID, SR_REL_CONTAINS, "1.2.3.4.2", "1.2.3.4.5.2", &currentID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Add_COMPOSITE_Child failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Add_IMAGE_Child(childID, SR_REL_CONTAINS, "1.2.3.4.1", "1.2.3.4.5.1", &currentID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Add_IMAGE_Child failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    /*
     *  Store Image child ID for future Reference
     */
    refID = currentID;

    status = MC_SRH_Set_IMAGE_Frames(currentID, refFrames, sizeof(refFrames)/sizeof(long));
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_IMAGE_Frames failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Add_WAVEFORM_Child(childID, SR_REL_CONTAINS, "1.2.3.4.3", "1.2.3.4.5.3", &currentID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Add_WAVEFORM_Child failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Set_WAVEFORM_Channels(currentID, refChannels, sizeof(refChannels)/sizeof(short));
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_WAVEFORM_Channels failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    /*
     * Create Patient Characteristics
     */
    status = MC_SRH_Add_CONTAINER_Child(srID, SR_REL_CONTAINS, SR_CC_SEPARATE, NULL, &childID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Add_CONTAINER_Child failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Set_Concept_Name(childID, "121118", "DCM", "Patient Characteristics");
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_Concept_Name failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Add_TEXT_Child(childID, SR_REL_CONTAINS, "121106", "DCM", "Comment", "Patient is ok", &currentID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Add_TEXT_Child failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Add_NUM_Child(childID, SR_REL_CONTAINS, "8302-2", "LN", "Patient Height", "1.85", "m", "LN", "meters", &currentID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Add_NUM_Child failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    /*
     *  Create Procedure Summary
     */ 
    status = MC_SRH_Add_CONTAINER_Child(srID, SR_REL_CONTAINS, SR_CC_SEPARATE, NULL, &childID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Add_CONTAINER_Child failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Set_Concept_Name(childID, "121111", "DCM", "Summary");
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_Concept_Name failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Add_DATE_Child(childID, SR_REL_CONTAINS, "11955-2", "LN", "LMP", "19991029", &currentID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Add_DATE_Child failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Add_TIME_Child(childID, SR_REL_CONTAINS, "11955", "MERGE", "Proceedure Time", "102900", &currentID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Add_TIME_Child failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Add_DATETIME_Child(childID, SR_REL_CONTAINS, "122146", "DCM", "Procedure DateTime", "19991029102900", &currentID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Add_DATETIME_Child failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    /*
     *  Create Procedure Fetus Summary
     */
    status = MC_SRH_Add_CONTAINER_Child(childID, SR_REL_CONTAINS, SR_CC_SEPARATE, NULL , &currentID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Add_CONTAINER_Child failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Set_Concept_Name(currentID, "125008", "DCM", "Fetus Summary");
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_Concept_Name failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Add_PNAME_Child(currentID, SR_REL_HAS_OBS_CONTEXT, "121036", "DCM", "Mother of fetus", "Jane^Doe", &id);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Add_PNAME_Child failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Add_UIDREF_Child(currentID, SR_REL_HAS_OBS_CONTEXT, "121028", "DCM", "Subject UID", "1.2.3.123", &id);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Add_UIDREF_Child failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    /*
     * Create Findings
     */
    status = MC_SRH_Add_CONTAINER_Child(srID, SR_REL_CONTAINS, SR_CC_SEPARATE, NULL, &childID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Add_CONTAINER_Child failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Set_Concept_Name(childID, "121070", "DCM", "Findings");
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_Concept_Name failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Add_CODE_Child(childID, SR_REL_HAS_CONCEPT_MOD, "G-C0E3", "SRT", "Finding Site", "T-87000", "SRT", "Ovary", &currentID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Add_CODE_Child failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Add_NUM_Child(childID, SR_REL_CONTAINS, "000222", "LNDemo", "Diameter", "0.23", "m", "LN","meters",    &currentID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Add_NUM_Child failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Set_NUM_Next_Data(currentID, "0.24");
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_NUM_Next_Data failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Set_NUM_Qualifier(currentID, "121070", "MERGE", "Qualifier");
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_NUM_Qualifier failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    /* Create SCOORD Spatial Coordinate Macro */
    status = MC_SRH_Add_SCOORD_Child(childID, SR_REL_INFERRED_FROM, (float)1.1, (float)2.2, SR_GRT_MULTIPOINT, &currentID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_NUM_Qualifier failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Set_SCOORD_Next_Data(currentID, (float)3.3, (float)4.4 );
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_NUM_Qualifier failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Set_SCOORD_Next_Data(currentID, (float)5.5, (float)6.6 );
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_NUM_Qualifier failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    /* Create SCOORD3D Spatial Coordinate Macro */
    status = MC_SRH_Add_SCOORD3D_Child(childID, SR_REL_INFERRED_FROM, GenerateUID( uid ), point3d[0], SR_GRT_MULTIPOINT, &currentID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_NUM_Qualifier failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Set_SCOORD3D_Next_Data(currentID, point3d[1]);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_NUM_Qualifier failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Set_SCOORD3D_Next_Data(currentID, point3d[2] );
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_NUM_Qualifier failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    /* Create TCOORD Coordinate Macro */
    status = MC_SRH_Add_TCOORD_D_Child( childID, SR_REL_INFERRED_FROM, "20001010203040", SR_TRT_MULTIPOINT, &currentID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_NUM_Qualifier failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Set_TCOORD_D_Next_Data(currentID, "20001010203041");
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_NUM_Qualifier failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Set_TCOORD_D_Next_Data(currentID, "20001010203042" );
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_NUM_Qualifier failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Add_TCOORD_O_Child( childID, SR_REL_INFERRED_FROM, "203040", SR_TRT_MULTIPOINT, &currentID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_NUM_Qualifier failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Set_TCOORD_O_Next_Data(currentID, "203041");
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_NUM_Qualifier failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Set_TCOORD_O_Next_Data(currentID, "203042" );
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_NUM_Qualifier failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Add_TCOORD_R_Child( childID, SR_REL_INFERRED_FROM, 1, SR_TRT_MULTIPOINT, &currentID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_NUM_Qualifier failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Set_TCOORD_R_Next_Data(currentID, 2);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_NUM_Qualifier failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Set_TCOORD_R_Next_Data(currentID, 3 );
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_NUM_Qualifier failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    status = MC_SRH_Add_Reference(currentID, SR_REL_SELECTED_FROM, refID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SRH_Set_NUM_Qualifier failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    /*
     *  Convert to DIMSE Message
     */
    status = MC_SR_To_Message(srID);
    if( MC_FAILED( status ) )
    {
        printf("MC_SR_To_Message failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    /* 
     * Add top level Standard Attributes to SR
     */
    SetAttributes( srID, srAttribs );

#if defined(_WIN32)
    {
        char buffer[256] = {0};

        sprintf(buffer,"%s.txt",fileOpInfo.FileName);
	    MC_List_Message(srID, buffer);
    }
#endif

	/*
     *  Convert DIMSE message to DICOM file 
     */
	status = MC_Message_To_File(srID, fileOpInfo.FileName);
    if( MC_FAILED( status ) )
    {
        printf("MC_SR_To_Message failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    /*
     *  Save SR to DICOM file
     */
    status = MC_Message_To_Stream(srID, 0L, 0xFFFFFFFF, EXPLICIT_LITTLE_ENDIAN, &fileOpInfo, FileWriteCallbackFunction );
    if( MC_FAILED( status ) )
    {
        printf("MC_SR_To_Message failed, error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    return EXIT_SUCCESS;
}

static int ReadSR(int id)
{
    MC_STATUS   status;
    char name[512] = {0}, scheme[512] = {0}, meaning[512] = {0};

    if (id <= 0)
        return (EXIT_FAILURE);

    /*
     * Allows to read root level attributes from DIMSE message
     */
    status = MC_Message_To_SR(id);
    if(MC_FAILED(status))
    {
        printf("MC_Message_To_SR error %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    /* 
     * Get a concept name from the first CONTAINER node 
     */
    status = MC_SRH_Get_Concept_Name(id, name, sizeof(name), scheme, sizeof(scheme), meaning, sizeof(meaning));
    if(MC_FAILED(status))
    {
        printf("MC_SRH_Get_Concept_Name Error code %d (%s)", status, MC_Error_Message(status));
        return(EXIT_FAILURE);
    }

    printf("%.*s>Id [%d] ", recur, recurstr, id);
    printf("Document Title [%s] Scheme [%s] Meaning [%s]\n", name, scheme, meaning);

    /*
     *  Read SR Content
     */
    ReadSRContent(id);

    return EXIT_SUCCESS;
}


typedef struct _SR_CHILD_ID 
{
    SR_RELATIONSHIP relationship;
    SR_CONTENT_TYPE content_type;
    int             id;
} SR_CHILD_ID;

/*
 *   ReadSRType uses recursive call of ReadSRContent. It is not advised to use recursion in real DICOM applications,
 *   because of possibly large number of nested SR nodes.
 *
 *   This code is only for the demonstration of handling of different SR node types.
 */
static void ReadSRContent(int id)
{
    MC_STATUS   status;
    SR_CHILD_ID *ids = NULL;
    int childID = -1, isLast = 0, i = 0, count = 0;
    
    SR_CONTENT_TYPE    contentType;
    SR_RELATIONSHIP relationship;

    status = MC_SR_Get_Child_Count(id, &count);
    if ((status == MC_NORMAL_COMPLETION) && (count > 0))
    {
        printf("%.*s>Id [%d] ", recur, recurstr, id);
        printf("Number of Children [%d]\n", count);
    }

    if (count == 0)
        return;

    ++recur;

    /* Read the information about the child nodes */  
    status = MC_SRH_Get_First_Child(id, &childID, &relationship, &contentType, &isLast);
    if( MC_FAILED(status) )
        return;

    ids = malloc(count * sizeof(SR_CHILD_ID));
    if (ids == NULL)
        return;

    memset(ids, 0, count * sizeof(SR_CHILD_ID));

    ids[i].id = childID;
    ids[i].relationship = relationship;
    ids[i].content_type = contentType;

    i++;

    for(; i < count; i++)
    {
        status = MC_SRH_Get_Next_Child(id, &childID, &relationship, &contentType, &isLast);
        if( MC_FAILED(status) )
            break;

        ids[i].id = childID;
        ids[i].relationship = relationship;
        ids[i].content_type = contentType;

        if (isLast)
            break;
    }

    /* Read the content of the child nodes */
    for(i = 0; i < count; i++)
    {
        if (ids[i].id == 0)
            continue;

        ReadSRRelationship(ids[i].id, ids[i].relationship);
        ReadSRType(ids[i].id, ids[i].content_type);
    }

    free(ids);

    --recur;
}

static void ReadSRType(int id, SR_CONTENT_TYPE type)
{
    MC_STATUS   status;
    char value[512] = {0}, scheme[512] = {0}, meaning[512] = {0}, buffer[1024] = {0}, templateId[512] = {0};
    SR_CONT_CONTINUITY continuity;
    int count = 0;

    if (id <= 0)
        return;

    /* Print concept code + text value */
    status = MC_SRH_Get_Concept_Name(id, value, sizeof(value), scheme, sizeof(scheme), meaning, sizeof(meaning));
    if (status == MC_NORMAL_COMPLETION)
    {
        printf("%.*s>Id [%d] ", recur, recurstr, id);
        printf("Title [%s] Scheme [%s] Meaning [%s]\n", value, scheme, meaning);
    }

    printf("%.*s>Id [%d] ", recur, recurstr, id);

    if (type == SR_NODE_CODE)
    {
        status = MC_SRH_Get_CODE_Data(id, value, sizeof(value), scheme, sizeof(scheme), meaning, sizeof(meaning));
        if( MC_FAILED(status) )
        {
            printf("MC_SRH_Get_CODE_Data Error code %d (%s)\n", status, MC_Error_Message(status));
            return;
        }
        printf("%s\n", meaning);
    }
    else if (type == SR_NODE_NUM)
    {
        char value[512] = {0}, unitsvalue[512] = {0}, unitsscheme[512] = {0}, unitsmeaning[512] = {0};

        status = MC_SRH_Get_NUM_Data(id, value, sizeof(value), &count, unitsvalue, sizeof(unitsvalue), unitsscheme, sizeof(unitsscheme), unitsmeaning, sizeof(unitsmeaning));
        if( MC_FAILED(status) )
        {
            printf("MC_SRH_Get_NUM_Data Error code %d (%s)\n", status, MC_Error_Message(status));
            return;
        }
        printf("%s %s (%s)\n", value, unitsvalue, unitsmeaning);
    }
    else if (type == SR_NODE_UIDREF)
    {
        char uid[512] = {0};

        status = MC_SRH_Get_UIDREF_Data(id, uid, sizeof(uid));
        if( MC_FAILED(status) )
        {
            printf("MC_SRH_Get_UIDREF_Data Error code %d (%s)\n", status, MC_Error_Message(status));
            return;
        }
        printf("%s\n", uid);
    }
    else if (type == SR_NODE_TEXT)
    {
        status = MC_SRH_Get_TEXT_Data(id, buffer, sizeof(buffer));
        if( MC_FAILED(status) )
        {
            printf("MC_SRH_Get_TEXT_Data Error code %d (%s)\n", status, MC_Error_Message(status));
            return;
        }
        printf("%s\n", buffer);
    }
    else if(type == SR_NODE_IMAGE)
    {
        char classuid[512] = {0}, instanceuid[512] = {0};
        int  frames = 0;
        long framesRead[10] = {0};

        status = MC_SRH_Get_IMAGE_Data(id, classuid, sizeof(classuid), instanceuid, sizeof(instanceuid), &frames);
        if( MC_FAILED(status) )
        {
            printf("MC_SRH_Get_IMAGE_Data Error code %d (%s)\n", status, MC_Error_Message(status));
            return;
        }
        printf("Class UID [%s] Instance UID [%s]\n", classuid, instanceuid);

        status = MC_SRH_Get_IMAGE_Frames(id, framesRead, sizeof(framesRead)/sizeof(long));
        if( status == MC_NORMAL_COMPLETION )
        {
            printf("%.*s>Id [%d] ", recur, recurstr, id);
            printf("MC_SRH_Get_IMAGE_Frames gets frame numbers for Referenced SOP Instance [%s]\n", instanceuid);
        }
    }
    else if (type == SR_NODE_CONTAINER)
    {
        status = MC_SRH_Get_CONTAINER_Data(id, &continuity, templateId, sizeof(templateId));
        if( MC_FAILED(status) )
        {
            printf("MC_SRH_Get_CONTAINER_Data Error code %d (%s)\n", status, MC_Error_Message(status));
            return;
        }
        printf("Template ID: %s, Continuity: %d\n", templateId, continuity);
    }
    else if (type == SR_NODE_COMPOSITE)
    {
        char classuid[512] = {0}, instanceuid[512] = {0};

        status = MC_SRH_Get_COMPOSITE_Data(id, classuid,  sizeof(classuid), instanceuid, sizeof(instanceuid));
        if( MC_FAILED(status) )
        {
            printf("MC_SRH_Get_COMPOSITE_Data Error code %d (%s)\n", status, MC_Error_Message(status));
            return;
        }
        printf("Class UID [%s] Instance UID [%s]\n", classuid, instanceuid);
    }
    else if (type == SR_NODE_SCOORD)
    {
        float fv1 = 0.0f, fv2 = 0.0f;
        SR_GRAPHIC_TYPE graphicType;

        status = MC_SRH_Get_SCOORD_First_Data(id, &fv1, &fv2, &count, &graphicType);
        if( MC_FAILED(status) )
        {
            printf("MC_SRH_Get_SCOORD_First_Data Error code %d (%s)\n", status, MC_Error_Message(status));
            return;
        }

        printf("Graphic Type %d, count = %d\n", graphicType, count);
        
        printf("%.*s>Id [%d] ", recur, recurstr, id);
        printf("fv1 = %f fv2 = %f\n", fv1, fv2);

        if (count > 1)
        {
            int i = 1;
            for( ;i < count; i++)
            {
                status = MC_SRH_Get_SCOORD_Next_Data(id, &fv1, &fv2);
                if( MC_FAILED(status) )
                {
                    printf("MC_SRH_Get_SCOORD_First_Data Error code %d (%s)\n", status, MC_Error_Message(status));
                    return;
                }

                printf("%.*s>Id [%d] ", recur, recurstr, id);
                printf("fv1 = %f fv2 = %f\n", fv1, fv2);
            }
        }
    }
    else if ((type == SR_NODE_TCOORD_O) || (type == SR_NODE_TCOORD_R) || (type == SR_NODE_TCOORD_D))
    {
        SR_TRANGE_TYPE rangeType;
        unsigned long pos = 0;

        if (type == SR_NODE_TCOORD_O)
            status = MC_SRH_Get_TCOORD_O_First_Data(id, buffer, sizeof(buffer), &count, &rangeType);
        else if (type == SR_NODE_TCOORD_R)
            status = MC_SRH_Get_TCOORD_R_First_Data(id, &pos, &count, &rangeType);
        else if (type == SR_NODE_TCOORD_D)
            status = MC_SRH_Get_TCOORD_D_First_Data(id, buffer, sizeof(buffer), &count, &rangeType);

        if( MC_FAILED(status) )
        {
            printf("MC_SRH_Get_TCOORD_First_Data Error code %d (%s)\n", status, MC_Error_Message(status));
            return;
        }

        printf("Range Type %d, count = %d\n", rangeType, count);        
        printf("%.*s>Id [%d] ", recur, recurstr, id);
        if (type == SR_NODE_TCOORD_R)
            printf("%ld\n", pos);
        else
            printf("%s\n", buffer);

        if (count > 1)
        {
            int i = 1;
            for( ;i < count; i++)
            {
                if (type == SR_NODE_TCOORD_O)
                    status = MC_SRH_Get_TCOORD_O_Next_Data(id, buffer, sizeof(buffer));
                else if (type == SR_NODE_TCOORD_R)
                    status = MC_SRH_Get_TCOORD_R_Next_Data(id, &pos);
                else if (type == SR_NODE_TCOORD_D)
                    status = MC_SRH_Get_TCOORD_D_Next_Data(id, buffer, sizeof(buffer));

                if (MC_FAILED(status))
                {
                    printf("MC_SRH_Get_TCOORD_Next_Data Error code %d (%s)\n", status, MC_Error_Message(status));
                    return;
                }

                printf("%.*s>Id [%d] ", recur, recurstr, id);
                if (type == SR_NODE_TCOORD_R)
                    printf("%ld\n", pos);
                else
                    printf("%s\n", buffer);
            }
        }
    }
    else if (type == SR_REFERENCE)
    {
        int refID = -1;
        SR_CONTENT_TYPE contentType;

        status = MC_SRH_Get_Reference(id, &refID);
        if( MC_FAILED(status) )
        {
            printf("MC_SRH_Get_Reference Error code %d (%s)\n", status, MC_Error_Message(status));
            return;
        }

        status = MC_SRH_Get_NodeType(refID, &contentType);
        if (status == MC_NORMAL_COMPLETION)
            printf("Node Type [%s] Reference [%d]\n", GetSRContentType(contentType), refID);
    }
    else if (type == SR_NODE_DATE)
    {   
        status = MC_SRH_Get_DATE_Data(id, buffer, sizeof(buffer));
        if( MC_FAILED(status) )
        {
            printf("MC_SRH_Get_TCOORD_O_First_Data Error code %d (%s)\n", status, MC_Error_Message(status));
            return;
        }
        printf("%s\n", buffer);
    }
    else if (type == SR_NODE_TIME)
    {   
        status = MC_SRH_Get_TIME_Data(id, buffer, sizeof(buffer));
        if( MC_FAILED(status) )
        {
            printf("MC_SRH_Get_TCOORD_O_First_Data Error code %d (%s)\n", status, MC_Error_Message(status));
            return;
        }
        printf("%s\n", buffer);
    }
    else if (type == SR_NODE_DATETIME)
    {   
        status = MC_SRH_Get_DATETIME_Data(id, buffer, sizeof(buffer));
        if( MC_FAILED(status) )
        {
            printf("MC_SRH_Get_TCOORD_O_First_Data Error code %d (%s)\n", status, MC_Error_Message(status));
            return;
        }
        printf("%s\n", buffer);
    }
    else if (type == SR_NODE_WAVEFORM)
    {   
        char classuid[512] = {0}, instanceuid[512] = {0};
        int refChannelsCount = 0;

        status = MC_SRH_Get_WAVEFORM_Data(id, classuid, sizeof(classuid), instanceuid, sizeof(instanceuid), &refChannelsCount);
        if( MC_FAILED(status) )
        {
            printf("MC_SRH_Get_WAVEFORM_Data Error code %d (%s)\n", status, MC_Error_Message(status));
            return;
        }
        printf("Class UID [%s] Instance UID [%s] Channels [%d]\n", classuid, instanceuid, refChannelsCount);
    }
    else if (type == SR_NODE_PNAME)
    {
        status = MC_SRH_Get_PNAME_Data(id, buffer, sizeof(buffer));
        if( MC_FAILED(status) )
        {
            printf("MC_SRH_Get_PNAME_Data Error code %d (%s)\n", status, MC_Error_Message(status));
            return;
        }
        printf("%s\n", buffer);
    }
    else if (type == SR_NODE_SCOORD3D)
    {
        char *refuid = NULL;
        POINT3D pt3d = {0};
        SR_GRAPHIC_TYPE graphicType;

        status = MC_SRH_Get_SCOORD3D_First_Data(id, &refuid, &pt3d, &count, &graphicType);
        if( MC_FAILED(status) )
        {
            printf("MC_SRH_Get_SCOORD3D_First_Data Error code %d (%s)\n", status, MC_Error_Message(status));
            return;
        }

        printf("Graphic Type %d, count = %d\n", graphicType, count);
        printf("%.*s>Id [%d] ", recur, recurstr, id);
        printf("x = %f y = %f z = %f\n", pt3d.x, pt3d.y, pt3d.z);

        if (count > 1)
        {
            int i = 1;
            for( ;i < count; i++)
            {
                status = MC_SRH_Get_SCOORD3D_Next_Data(id, &pt3d);
                if (MC_FAILED(status))
                {
                    printf("MC_SRH_Get_SCOORD3D_First_Data Error code %d (%s)\n", status, MC_Error_Message(status));
                    return;
                }

                printf("%.*s>Id [%d] ", recur, recurstr, id);
                printf("x = %f y = %f z = %f\n", pt3d.x, pt3d.y, pt3d.z);
            }
        }
    }
    else
    {
        printf("Invaid Content Type: %d\n", type);
        return;
    }

    ReadSRContent(id);
}

static char* GetSRContentType(SR_CONTENT_TYPE type)
{
    switch(type)
    {
    case SR_NODE_TEXT:      return "TEXT"; 
    case SR_NODE_CODE:      return "CODE"; 
    case SR_NODE_NUM:       return "NUM"; 
    case SR_NODE_DATE:      return "DATE";
    case SR_NODE_DATETIME:  return "DATETIME"; 
    case SR_NODE_TIME:      return "TIME"; 
    case SR_NODE_UIDREF:    return "UIDREF"; 
    case SR_NODE_PNAME:     return "PNAME"; 
    case SR_NODE_SCOORD:    return "SCOORD"; 
    case SR_NODE_TCOORD_D:  return "TCOORD_D"; 
    case SR_NODE_TCOORD_O:  return "TCOORD_O"; 
    case SR_NODE_TCOORD_R:  return "TCOORD_R"; 
    case SR_NODE_COMPOSITE: return "COMPOSITE"; 
    case SR_NODE_IMAGE:     return "IMAGE"; 
    case SR_NODE_WAVEFORM:  return "WAVEFORM"; 
    case SR_NODE_CONTAINER: return "CONTAINER"; 
    case SR_REFERENCE:      return "REFERENCE"; 
    case SR_NODE_SCOORD3D:  return "SCOORD3D"; 
    }
    return "INVALID";
}

static void ReadSRRelationship(int id, SR_RELATIONSHIP relationship)
{
    char *str = NULL;

    if (id <= 0)
        return;

    switch(relationship)
    {
    case SR_REL_CONTAINS:
        str = "CONTAINS";
        break;
    case SR_REL_HAS_OBS_CONTEXT:
        str = "HAS OBSERVATION CONTEXT";
        break;
    case SR_REL_HAS_ACQ_CONTEXT:
        str = "HAS ACQUISITION CONTEXT";
        break;
    case SR_REL_HAS_CONCEPT_MOD:
        str = "HAS CONCEPT MODIFIER";
        break;
    case SR_REL_HAS_PROPERTIES:
        str = "HAS PROPERTIES";
        break;
    case SR_REL_INFERRED_FROM:
        str = "INFERRED FROM";
        break;
    case SR_REL_SELECTED_FROM:
        str = "SELECTED FROM";
        break;
    default:
        printf("Invalid Relationship for child %d\n", id);
        return;
    }

    printf("%.*s>Id [%d] Relationship Type [%s] \n", recur, recurstr, id, str);
}

/*
 *  Callback function to read DICOM data
 */
MC_STATUS FileReadCallbackFunction(char* filename, void* userInfo, int* dataSizePtr, void** dataBufferPtr, int isFirst, int* isLastPtr)
{
    static char buffer[WORK_BUFFER_SIZE];
    
    FileOpInfo* info = (FileOpInfo*) userInfo;
    size_t dataread = 0;

    if(isFirst)
    {
        FILE *fp = fopen(filename, "rb");
        if(!fp)
            return MC_CALLBACK_CANNOT_COMPLY;

        info->FileHandle = fp;
    }

    dataread = fread(buffer, 1, sizeof(buffer), info->FileHandle);

    if(feof(info->FileHandle))
    {
        *isLastPtr = 1;
        fclose(info->FileHandle);
    }

    if(dataread > 0)
        *dataSizePtr = (int)dataread;

    *dataBufferPtr = buffer;

    return MC_NORMAL_COMPLETION;
}

/*
 *  Callback function to write the content of DICOM file in MC_Write_File
 */
MC_STATUS FileWriteCallbackFunction( int msgID, void* userInfo, int dataSize, void* dataBuffer, int isFirst, int isLast )
{
    size_t bytes = 0;
    FileOpInfo* info = (FileOpInfo*) userInfo;

    if( isFirst )
    {
        info->FileHandle = fopen(info->FileName, "wb");
        if( !info->FileHandle )
        {
            printf("Failed to open file [%s]\n", info->FileName);
            return MC_CANNOT_COMPLY;
        }
    }

    if( dataSize )
    {
        bytes = fwrite( dataBuffer, 1, (size_t) dataSize, info->FileHandle );
        if( bytes != (size_t) dataSize )
        {
            fclose( info->FileHandle );
            printf("Error on writing to file [%s]\n", info->FileName);
            return MC_CANNOT_COMPLY;
        }
    }

    if( isLast ) 
        fclose( info->FileHandle );

    return MC_NORMAL_COMPLETION;
}

static int LastIndexOf(char *str, char ch)
{
    int i = 0, lastIndex = -1, len = 0;

    if ((str == NULL) || ((len = (int)strlen(str)) == 0))
        return lastIndex;

    for(; i < len; ++i)
        if(str[i] == ch)
            lastIndex = i;

    return lastIndex;
}

static void Replace(char *str, char oldCh, char newCh)
{
    int i = 0, len = 0;
    
    if ((str == NULL) || ((len = (int)strlen(str)) == 0))
        return;

    for(; i < len; ++i)
        if(str[i] == oldCh)
            str[i] = newCh;
}

static char* GenerateUID( char* buffer )
{
    static unsigned int instanceCounter = 0;

    if ((buffer == NULL) || sizeof(buffer) < 64)
    {
        instanceCounter = 0;
        return NULL;
    }

    instanceCounter++;
    sprintf( buffer, "1.2.840.%d", instanceCounter );

    return buffer;
}

static void SetAttributes( int msg, AttributeValue* values )
{
    MC_STATUS stat;
    char *p = (char*)NULL, nameBuffer[100] = { 0 };
    MTI_BOOLEAN nextVal;
    AttributeValue* val;
    MC_VR           vr;
    unsigned long tag = 0xFFFFFFFF;
    unsigned short  low, high;
    int i = 0, j = 0, count = 0;

    while( values[i].type != 'e' )
    {
        val = &values[i];
        nextVal = MTI_TRUE;

        if( val->tag != tag )
        {
            tag = val->tag;
            if( val->type != 'z' ) 
            {
                stat = MC_Add_Standard_Attribute( msg, tag );
                if( stat != MC_TAG_ALREADY_EXISTS && MC_FAILED( stat ) ) 
                {
                    return;
                }
            }
            nextVal = MTI_FALSE;
        }

        stat = MC_Get_Tags_Dict_Info(tag, nameBuffer, sizeof(nameBuffer), &vr, &low, &high);
        if(  stat != MC_NORMAL_COMPLETION ) 
        {
            vr = UNKNOWN_VR;
        }        

        switch( val->type )
        {
        case 'e':
            stat = MC_Set_Value_To_NULL( msg, tag );
            break;
        case 'i':
            if( nextVal ) stat = MC_Set_Next_Value_From_Int( msg, tag, (int) val->val.lvalue );
            else stat = MC_Set_Value_From_Int( msg, tag, (int) val->val.lvalue );
            break;
        case 's':
        case 'z':
            if( nextVal ) stat = MC_Set_Next_Value_From_String( msg, tag, val->val.svalue );
            else stat = MC_Set_Value_From_String( msg, tag, val->val.svalue );
            break;
        case 'u':
            if( nextVal ) stat = MC_Set_Next_Value_From_ULongInt( msg, tag, (unsigned long) val->val.lvalue );
            else stat = MC_Set_Value_From_ULongInt( msg, tag, (unsigned long) val->val.lvalue );
            break;
        case 'j':
            if(vr == OB)
            {
                stat = MC_Set_Value_From_Buffer( msg, tag, &(val->val.lvalue), sizeof(long));
            }
            else
            {
                if( nextVal ) stat = MC_Set_Next_Value_From_UInt( msg, tag, (unsigned int) val->val.lvalue );
                else stat = MC_Set_Value_From_UInt( msg, tag, (unsigned int) val->val.lvalue );
            }
            break;
        case 'h':
            if(vr == OB)
            {
                stat = MC_Set_Value_From_Buffer( msg, tag, &(val->val.hvalue), sizeof(short));
            }
            else
            {
                if( nextVal ) stat = MC_Set_Next_Value_From_UShortInt( msg, tag, *val->val.hvalue );
                else stat = MC_Set_Value_From_UShortInt( msg, tag, *val->val.hvalue );
            }
            break;
        case 'k':
            if( nextVal ) stat = MC_Set_Next_Value_From_LongInt( msg, tag, (long) val->val.lvalue );
            else stat = MC_Set_Value_From_LongInt( msg, tag, (long) val->val.lvalue );
            break;
        case 'd':
            if( nextVal ) stat = MC_Set_Next_Value_From_Double( msg, tag, *val->val.dvalue );
            else stat = MC_Set_Value_From_Double( msg, tag, *val->val.dvalue );
            break;
        case 'f':
            if( nextVal )
            {
                stat = MC_Set_Next_Value_From_Float( msg, tag, *val->val.fvalue );
            }
            else 
            {
                stat = MC_Set_Value_From_Float( msg, tag, *val->val.fvalue );
            }
            break;
        case 'm':
            stat = MC_Set_Value_To_Empty( msg, tag );
            break;
        case 't':
            {
                count = (int) val->val.lvalue;
                p = (char*) malloc( count + 1 );
                for( j = 0; j < count; j++ ) p[j] = 'B';
                p[count] = '\0';

                stat = MC_Set_Value_From_String( msg, tag, p );
                free( p );
            }
            break;
        case 'x':
            break;
        case 'q':
            stat = MC_Set_Value_To_NULL(msg, tag);
            break;
        }
        i++;  
        if( MC_FAILED( stat ) ) 
            return;
    }
}
