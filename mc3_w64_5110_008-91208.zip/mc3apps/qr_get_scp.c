
/*******************************************************************************
 *                                                                             *
 *       System: Merge DICOM Tool Kit Sample Applications                      *
 *                                                                             *
 *       Author: Merge Healthcare                                              *
 *                                                                             *
 *  Description: Q/R Sample Service Class Provider Application.                *
 *                                                                             *
 *******************************************************************************
 *                                                                             *
 *   Copyright (C) IBM Corporation 2016, 2020.                                 *
 *   Copyright (C) Merge Healthcare 2005, 2016.                                *
 *                                                                             *
 *   All rights reserved.                                                      *
 *                                                                             *
 *  This software is furnished under license and may be used and copied only   *
 *  in accordance with the terms of such license and with the inclusion of the *
 *  above copyright notice.                                                    *
 *                                                                             *
 *  This software or any other copies thereof may not be provided or otherwise *
 *  made available to any other person. No title to and ownership of the       *
 *  software is hereby transferred.                                            *
 *                                                                             *
 *******************************************************************************/

/* Default is unix */
#if !defined(_WIN32) && !defined(UNIX)
    #ifndef UNIX
        #define UNIX 1
    #endif
#endif

#ifdef UNIX
    #define SLASH "/"
#endif
#ifdef _WIN32
    #define SLASH "\\"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <fcntl.h>

#ifdef UNIX
    #include <sys/stat.h>
    #include <dirent.h>
    #ifdef STRINGS
        #include <strings.h>
    #endif
        #include <sys/time.h>
    #include <sys/wait.h>
    #include <errno.h>
    #include <signal.h>
#endif
#ifdef _WIN32
    #include <windows.h>
    #include <direct.h>
#endif

#include "mergecom.h"
#include "mcstatus.h"
#include "mc3media.h"
#include "diction.h"
#include "mc3items.h"
#include "mc3services.h"
#include "qr.h"

#include "general_util.h"

#ifdef __GNUC__
#define UNUSED __attribute__ ((__unused__))
#else
#define UNUSED /* empty */
#endif

/*
 * Structure to hold patient and study information
 */
typedef struct study_node
{
    char     pat_id[LO_LEN];
    char     pat_name[PN_LEN];
    char     pat_bday[DA_LEN];
    char     pat_sex[CS_LEN];

    char     stu_inst[UI_LEN];
    char     stu_date[DA_LEN];
    char     stu_time[TM_LEN];
    char     stu_anum[CS_LEN];
    char     stu_id[CS_LEN];
    char     stu_desc[LO_LEN];
    char     stu_physname[PN_LEN];

    LIST     SeriesList;
} StudyNode;

/*
 * Structure to hold series information
 */
typedef struct series_node
{
    char     ser_uid[UI_LEN];
    char     ser_num[IS_LEN];
    char     ser_mode[CS_LEN];

    LIST     InstanceList;

} SeriesNode;

/*
 * Structure to hold instance information
 */
typedef struct instance_node
{
    char     sop_uid[UI_LEN];
    char     sop_classuid[UI_LEN];
    char     img_num[IS_LEN];

} InstanceNode;

/*
 * Structure to hold Application Default Values
 */

typedef struct app_config
{
    char    TimeOut[TM_LEN];
    char    ApplicationTitle[AE_LEN];
    char    RemoteApplicationTitle[AE_LEN];
    char    ServiceList[SERVICELIST_LEN];
    char    StorageFolder[FILENAME_LEN];
    TRANSFER_SYNTAX SaveSyntax;
    int     ListenPort;
} AppConfig;

typedef struct CALLBACKINFO
{
    FILE*         stream;
    /*
     * Note!   The size of this buffer impacts toolkit performance.  Higher
     * values in general should result in increased performance of reading
     * files
     */
    char          buffer[64*1024];
    size_t        bytesRead;
} CBinfo;

/* Global Variables */
LIST StudyList;

static int signal_quit = 0;

/*
 * Function Prototypes
 */
static void GetOptions(
                int           A_argc,
                char**        A_argv,
                AppConfig*    A_myConfig );
static void SetProgramDefaults(
                AppConfig*    A_myConfig );
static void CreateDataFolder(
                char*         A_storage,
                char*         A_stu_inst,
                char*         A_ser_inst,
                char*         A_makedir,
                size_t        A_makedir_length);
static void InitDatabaseFromFolder(
                AppConfig*    A_myConfig,
                int           A_applicationID);
static int GetDataFromMessage(
                StudyNode*    A_study,
                SeriesNode*   A_series,
                InstanceNode* A_instance,
                int           A_messageID);
static void InsertInstance(
                StudyNode*    A_study,
                SeriesNode*   A_series,
                InstanceNode* A_instance);
static void GetFileList(
                char*         A_folder,
                LIST*         A_FileList);
static QR_STATUS HandleAssociation (
                int           A_applicationID,
                int           A_associationID,
                AppConfig*    A_myConfig );
static QR_STATUS ProcessCSTORERQ(
                AppConfig*    A_myConfig,
                int           A_applicationID,
                int           A_associationID,
                int           A_msgID,
                char*         A_serviceName);
static MC_STATUS NOEXP_FUNC MediaToFileObj(
                char*         A_filename,
                void*         A_userInfo,
                int*          A_dataSize,
                void**        A_dataBuffer,
                int           A_isFirst,
                int*          A_isLast);
static QR_STATUS GetValue (
                int           A_messageid,
                unsigned long A_tag,
                char*         A_value,
                int           A_size,
                char*         A_default );
static QR_STATUS  WriteToMedia(
                AppConfig*    A_myConfig,
                char*         A_filename,
                int*          A_msgID,
                char*         A_messageType );
static MC_STATUS  NOEXP_FUNC  FileObjToMedia(
                char*         A_filename,
                void*         A_userInfo,
                int           A_dataSize,
                void*         A_dataBuffer,
                int           A_isFirst,
                int           A_isLast );
static QR_STATUS  AddGroup2Elements(
                AppConfig*    A_myConfig,
                TRANSFER_SYNTAX A_transSyntax,
                int           A_fileID );
static MC_STATUS NOEXP_FUNC FileMetaInfoVersion(
                int           A_msgID,
                unsigned long A_tag,
                int           A_isFirst,
                void*         A_info,
                int*          A_dataSize,
                void**        A_dataBufferPtr,
                int*          A_isLastPtr);
static QR_STATUS ProcessCFINDRQ    (
                int           A_associationID,
                int           A_messageID,
                AppConfig*    A_myConfig,
                char          *serviceName);
static QR_STATUS SendCFINDComplete (
                int           A_associationID,
                AppConfig     *A_myConfig,
                RESP_STATUS   A_retStatus,
                char*         A_serviceName);
static QR_STATUS SearchDBStudyRootStudyLevel(
                char*         A_serviceName,
                int           A_associationID,
                int           A_messageID,
                AppConfig*    A_myConfig,
                RESP_STATUS   A_retStatus);
static QR_STATUS SearchDBPatientLevel(
                char*         A_serviceName,
                int           A_associationID,
                int           A_messageID,
                AppConfig*    A_myConfig,
                RESP_STATUS   A_retStatus );
static QR_STATUS SearchDBStudyLevel(
                char*         A_serviceName,
                int           A_associationID,
                int           A_messageID,
                AppConfig*    A_myConfig,
                RESP_STATUS   A_retStatus);
static QR_STATUS SearchDBSeriesLevel(
                char*         A_serviceName,
                int           A_associationID,
                int           A_messageID,
                AppConfig*    A_myConfig,
                RESP_STATUS   retStatus);
static QR_STATUS SearchDBImageLevel(
                char*         A_serviceName,
                int           A_associationID,
                int           A_messageID,
                AppConfig*    A_myConfig,
                RESP_STATUS   A_retStatus);
static int WildCardMatch(
                char*         A_string1,
                char*         A_string2);
static int DateAndTimeMatch(
                char*         A_range,
                char*         A_data);
static RESP_STATUS ProcessCGETRQ(
                int           A_applicationID,
                int           A_associationID,
                int           A_messageID,
                AppConfig*    A_myConfig,
                char*         A_serviceName);
static QR_STATUS SendCFINDReply(
                char*         A_serviceName,
                int           A_associationID,
                AppConfig*    A_myConfig,
                RESP_STATUS   A_retStatus,
                int           A_messageID,
                StudyNode*    A_study,
                SeriesNode*   A_series,
                InstanceNode* A_instance,
                int*          A_ackSent);
static void trim(char*        Astring);
static MC_STATUS RemoveBulks(int A_messageID);
static MC_STATUS ProcessCompInstRootRetRQ(int A_outMsgID, 
                                          int A_reqMsgID);
static MC_STATUS NOEXP_FUNC SetCompFrameFromFunction( int  CBmsgID,
                                unsigned long   ATag,
                                int             CBfirstCall,
                                void*           CBuserInfo,
                                int*            CBdataLen,
                                void**          CBdataBuffer,
                                int*            CBisLast);
static MC_STATUS NOEXP_FUNC SetUncompFrameFromFunction( int  CBmsgID,
                                unsigned long   ATag,
                                int             CBfirstCall,
                                void*           CBuserInfo,
                                int*            CBdataLen,
                                void**          CBdataBuffer,
                                int*            CBisLast);

#ifdef UNIX
#if defined(SUN_SOLNAT) || defined(SUN_SOL8) || defined(SOL_X86) || defined(SOL_X86_64) \
 || defined(ANDROID) || defined(MACOSX_INTEL) || defined(IOS)
static void sigint_routine( int Asigno );
#else
static void sigint_routine  (int Asigno, long Acode, struct sigcontext *Ascp);
#endif
#endif

/* Image Bulk attributes */

/* 
 * The extended list of Image Bulk attributes should also include the following attributes:
 * Overlay Data (60xx,3000), Curve Data (50xx,3000), Audio Sample Data (50xx,200C)
 */
static unsigned long BulkTags[] = { MC_ATT_PIXEL_DATA, MC_ATT_PIXEL_DATA_PROVIDER_URL, MC_ATT_SPECTROSCOPY_DATA };

/*****************************************************************************
**
** NAME
**    main - Query/Retrieve provider main program
**
** SYNOPSIS
**    qr_scp
**
** DESCRIPTION
**    This is the main routine of the Query/Retrieve SCP sample application.
**    It waits for associations, and then calls Handle_Association when one
**    arrives.
**
*****************************************************************************/
int main(int argc, char** argv);
int main(int argc, char** argv)
{
    AppConfig    myConfig;
    MC_STATUS    mcStatus;
    QR_STATUS    qrStatus;
    int          applicationID;
    int          calledApplicationID;
    int          associationID;
    AssocInfo    assocInfo;
    char         makedir[1000];

    /*
     * Set up the default variables and get the command line options
     */
    SetProgramDefaults ( &myConfig );
    GetOptions ( argc, argv, &myConfig );
    CreateDataFolder(myConfig.StorageFolder, NULL, NULL, makedir, sizeof(makedir));

    /*
     * Print the application header to the screen
     */
    printf ( "\n" );
    printf ( "QR_SCP - Query/Retrieve Storage Class Provider.\n" );
    printf ( "(c) 2020 Merge Healthcare\n");
    printf ( "All rights reserved.\n\n");
    printf ( "BEGINNING QR_SCP.\n\n" );


    /* ------------------------------------------------------- */
    /* This call MUST be the first call made to the library!!! */
    /* ------------------------------------------------------- */
    mcStatus = MC_Library_Initialization ( NULL, NULL, NULL );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage( myConfig.ApplicationTitle,
                           "MC_Library_Initialization",
                           mcStatus, "Unable to initialize the library" );
        return( EXIT_FAILURE );
    }


    /*
     * Register the Q/R SCP's local application title
     */
    mcStatus = MC_Register_Application ( &applicationID,
                                       myConfig.ApplicationTitle );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( myConfig.ApplicationTitle,
                            "MC_Register_Application",
                            mcStatus, NULL );
        return( EXIT_FAILURE );
    }

    /*if the user has supplied a port number */
    if(myConfig.ListenPort != 0)
    {
        mcStatus = MC_Set_Int_Config_Value(TCPIP_LISTEN_PORT, myConfig.ListenPort);
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            PrintErrorMessage ( myConfig.ApplicationTitle,
                                "MC_Set_Int_Config_Value",
                                mcStatus, NULL );
            return( EXIT_FAILURE );
        }
    }

    /*Initialize the Study linked list*/
    LLCreate( &StudyList, sizeof(StudyNode));

    /*fill the linked list with data from the storage folder*/
    InitDatabaseFromFolder( &myConfig, applicationID);

    printf ( "%s: Waiting for an association.\n", myConfig.ApplicationTitle );

#ifdef UNIX
    signal(SIGINT, (void (*)(int)) sigint_routine);
#endif

    while(!signal_quit && !PollInputQuitKey())
    {
        /*
         * Wait for an assoc. request from the remote DICOM app.
         */
        mcStatus = MC_Wait_For_Association (   myConfig.ServiceList,
                                             0,
                                             &calledApplicationID,
                                             &associationID );
        if ( mcStatus == MC_TIMEOUT )
            continue;
        else if ( mcStatus == MC_NEGOTIATION_ABORTED )
        {
            printf("%s: Association aborted during negotiation.\n",myConfig.ApplicationTitle);
            continue;
        } else if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            PrintErrorMessage ( myConfig.ApplicationTitle, "MC_Wait_For_Association",
                                mcStatus, NULL );
            break;
        }

        if ( calledApplicationID != applicationID )
        {
            MC_Reject_Association ( associationID, PERMANENT_CALLED_AE_TITLE_NOT_RECOGNIZED );
            PrintErrorMessage ( myConfig.ApplicationTitle, "MC_Wait_For_Association", -1,
                                "Unexpected application identifier from MC_Wait_For_Association" );
            break;
        }

        printf ( "%s: Association received\n", myConfig.ApplicationTitle );

        /*
         * Get the remote AE title.  This is needed later to fill in
         * a field in the C-STORE-RQ messages.
         */
        mcStatus = MC_Get_Association_Info(associationID, &assocInfo);
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            MC_Reject_Association ( associationID, TRANSIENT_NO_REASON_GIVEN );
            PrintErrorMessage ( myConfig.ApplicationTitle,
                                "MC_Get_Association_Info", mcStatus,
                                "Originator application entity title" );
            break;
        }

        strcpy(myConfig.RemoteApplicationTitle,assocInfo.RemoteApplicationTitle);

        /*
         * Handle the association.  A real Q/R SCP would fork a child to handle
         * the association, or perhaps create a thread.
         */
        qrStatus = HandleAssociation ( applicationID, associationID, &myConfig );
        if ( qrStatus != QR_SUCCESS )
        {
            MC_Abort_Association ( &associationID );
            MC_Release_Application ( &applicationID );
            PrintErrorMessage ( myConfig.ApplicationTitle, "HandleAssociation", -1,
                                "Unexpected return value from HandleAssociation" );
            break;
        }
    }


    /*
     * We're finished: release the application
     */

    LLDestroy( &StudyList);

    mcStatus = MC_Release_Application ( &applicationID );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( myConfig.ApplicationTitle,
                            "MC_Release_Application", mcStatus, NULL );
        return( EXIT_FAILURE );
    }

    if ( MC_Library_Release() != MC_NORMAL_COMPLETION )
        printf("Error releasing the library.\n");

    printf ( "... %s FINISHED.\n\n",myConfig.ApplicationTitle );

    return( EXIT_SUCCESS );

} /* main */


/*****************************************************************************
**
** NAME
**    CreateDataFolder - Create a folder
**
** ARGUMENTS
**   char* A_storage       The storage folder
**   char* A_stu_inst      A study instance ID
**   char* A_ser_inst      A series instance ID
**   char* A_makedir       The resultant folder to create
**   size_t A_makedir_length The length of A_makedir
**
** DESCRIPTION
**    This function will create a folder for the
**    storage of a .dcm file. It will create it
**    as follows:
**
**          storage\stu_inst\ser_inst
**
** RETURNS
**    Nothing
**
*****************************************************************************/
static void CreateDataFolder(char* A_storage, char* A_stu_inst, char* A_ser_inst,
                             char* A_makedir, size_t A_makedir_length)
{
#if defined(_WIN32)
    _mkdir(A_storage);

    strncpy(A_makedir, A_storage, A_makedir_length);

    if ( A_stu_inst != NULL )
    {
        strncat(A_makedir, SLASH, A_makedir_length - strlen(A_makedir));
        strncat(A_makedir, A_stu_inst, A_makedir_length - strlen(A_makedir));
        _mkdir(A_makedir);
    }

    if ( A_ser_inst != NULL )
    {
        strncat(A_makedir, SLASH, A_makedir_length - strlen(A_makedir));
        strncat(A_makedir, A_ser_inst, A_makedir_length - strlen(A_makedir));
        _mkdir(A_makedir);
    }
#elif defined(UNIX)
    mkdir(A_storage, S_IRWXU);

    strncpy(A_makedir, A_storage, A_makedir_length);

    if ( A_stu_inst != NULL )
    {
        strncat(A_makedir, SLASH, A_makedir_length);
        strncat(A_makedir, A_stu_inst, A_makedir_length);
        mkdir(A_makedir, S_IRWXU);
    }

    if ( A_ser_inst != NULL )
    {
        strncat(A_makedir, SLASH, A_makedir_length - strlen(A_makedir));
        strncat(A_makedir, A_ser_inst, A_makedir_length - strlen(A_makedir));
        mkdir(A_makedir, S_IRWXU);
    }
#endif
} /* CreateDataFolder */


/*****************************************************************************
**
** NAME
**    InitDatabaseFromFolder - Init the internal database / structures
**
** ARGUMENTS
**   char* folder            The storage folder to begin at
**   int A_applicationID     The application ID
**
** DESCRIPTION
**    This function will create a list of filenames
**    which should be entered into the database.
**    Then, run through the list and add the files data
**    to the tree.
**
** RETURNS
**    Nothing
**
*****************************************************************************/
static void InitDatabaseFromFolder( AppConfig* A_myConfig, int A_applicationID)
{
    StudyNode       study;
    SeriesNode      series;
    InstanceNode    instance;
    char            fileName[FILENAME_LEN];
    int             ret;
    LIST            FileList;
    int             nodecount;
    int             i;
    int             fileID;
    CBinfo          callBackInfo;
    MC_STATUS       mcStatus;

    /*init the list of filenames*/
    LLCreate( &FileList, FILENAME_LEN);

    /*recurse through the storage dir adding the filenames found*/
    GetFileList(A_myConfig->StorageFolder, &FileList);

    /*for each filename in the list, add it to the tree structure*/
    nodecount = LLNodes( &FileList);
    LLRewind( &FileList);
    for ( i = 0; i < nodecount; i++ )
    {
        LLPopNode( &FileList, &fileName);

        /*open the .dcm file*/
        mcStatus = MC_Create_Empty_File(&fileID, fileName);
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            PrintErrorMessage ( A_myConfig->ApplicationTitle,
                            "MC_Create_Empty_File", mcStatus, NULL );
            continue;
        }

        mcStatus = MC_Open_File(A_applicationID, fileID, &callBackInfo, MediaToFileObj);
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            PrintErrorMessage ( A_myConfig->ApplicationTitle,
                            "MC_Open_File", mcStatus, NULL );
            continue;
        }

        /*get the data from the list and add it to the study, series, and instance structs*/
        ret = GetDataFromMessage(&study, &series, &instance, fileID);

        mcStatus = MC_Free_File(&fileID);
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            PrintErrorMessage ( A_myConfig->ApplicationTitle,
                            "MC_Free_File", mcStatus, NULL );
            continue;
        }

        if ( ret == FALSE )
        {
            printf("Error adding file: %s.\n", fileName);
            continue;
        }

        /*insert the structs in the tree*/
        InsertInstance(&study, &series, &instance);
    }

    LLDestroy(&FileList);
}

/*****************************************************************************
**
** NAME
**    GetFileList -- Search a directory and return the files
**
** ARGUMENTS
**    char* folder        The storage folder
**    LIST* FileList      The list of files
**
** DESCRIPTION
**    This function will is a recursive function
**    which will populate FileList with the names
**    of all files found in folder and its subfolders.
**    UNIX and Win32 implementations are available.
**    Other platforms can not read in the initial
**    directory
**
** RETURNS
**    Nothing
**
*****************************************************************************/
static void GetFileList(char* A_folder, LIST* A_fileList)
{
#if defined(_WIN32)
    WIN32_FIND_DATA FindFileData;
    HANDLE          hFind;
    char            search[FILENAME_LEN];
    char            fileName[FILENAME_LEN];

    strcpy(search, A_folder);
    strcat(search,"\\*");

    hFind = FindFirstFile(search, &FindFileData);

    /*for each file in the A_folder*/
    while ( FindNextFile(hFind, &FindFileData) )
    {
        /*skip if it is . or ..*/
        if ( strcmp(FindFileData.cFileName, ".") == 0
          || strcmp(FindFileData.cFileName, "..") == 0 )
            continue;

        /*if is a directory, recurse*/
        if ( FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY )
        {
            strcpy(search, A_folder);
            strcat(search, "\\");
            strcat(search, FindFileData.cFileName);
            GetFileList(search, A_fileList);
        } else
        {
            /*otherwise it's a file*/
            if ( strstr(FindFileData.cFileName,".dcm") != 0 )
            {
                strcpy(fileName, A_folder);
                strcat(fileName, "\\");
                strcat(fileName, FindFileData.cFileName);
                LLInsert( A_fileList, fileName);
            }
        }
    }
#elif defined(UNIX)
    DIR             *dp;
    struct dirent   *dir_entry;
    struct stat     stat_info;
    char            directory[FILENAME_LEN];


    if ( stat(A_folder, &stat_info)<0 )
    {
        fprintf(stderr, "path %s is not a valid directory\n", A_folder);
    }

    if ( S_ISDIR(stat_info.st_mode) == 0 )
    {
        fprintf(stderr, "path %s is not a valid directory.", A_folder);
        return;
    }
    if ( (dp = opendir(A_folder)) == NULL )
    {
        fprintf(stderr,"cannot open directory: %s\n", A_folder);
        return;
    }

    while ( (dir_entry = readdir(dp)) != NULL )
    {

        if ( strcmp(dir_entry->d_name, ".") == 0
         ||  strcmp(dir_entry->d_name, "..") == 0 )
            continue;
        sprintf(directory, "%s/%s", A_folder, dir_entry->d_name);
        lstat(directory,&stat_info);

        if ( S_ISDIR(stat_info.st_mode) )
        {
            GetFileList(directory, A_fileList);
        } else
        {
            if ( strstr(directory,".dcm") != 0 )
            {
                char* strptr = (char*)malloc(strlen(directory)+2);
                strcpy(strptr, directory);
                LLInsert( A_fileList, directory);
            }
        }
    }
    closedir(dp);
#else
    return;
#endif
}


/*****************************************************************************
**
** NAME
**    InsertInstance -- Insert records into our data structures
**
** ARGUMENTS
**    StudyNode* study        Pointer to struct to fill
**    SeriesNode* series      Pointer to struct to fill
**    InstanceNode* instance  Pointer to struct to fill
**
** DESCRIPTION
**    This function will insert the structs in the
**    parameter list into their correct location in
**    StudyList based on their UIDs.
**
** RETURNS
**    Nothing
**
*****************************************************************************/
static void InsertInstance(StudyNode* A_studyNode, SeriesNode* A_seriesNode, InstanceNode* A_instanceNode)
{
    int             i;
    StudyNode*      curStudy;
    SeriesNode*     curSeries;
    InstanceNode*   curInstance;
    int             studyCount;
    int             seriesCount;
    int             instanceCount;
    int             found;

    /*traverse the tree looking for the right place for our data, making new nodes if need be*/
    studyCount = LLNodes( &StudyList);
    if ( studyCount == 0 )
    {
        LLCreate(&A_studyNode->SeriesList, sizeof(SeriesNode));
        LLInsert( &StudyList, A_studyNode);
        curStudy = LLPopDataPtrN( &StudyList, 1);

    } else
    {
        found = FALSE;

        LLRewind( &StudyList);
        for ( i = 1; i <= studyCount; i++ )
        {
            curStudy = LLPopDataPtr( &StudyList );

            if ( strcmp(curStudy->stu_inst, A_studyNode->stu_inst) == 0 )
            {
                found = TRUE;
                break;
            }
        }

        if ( found == FALSE )
        {
            LLCreate(&A_studyNode->SeriesList, sizeof(SeriesNode));
            LLInsert( &StudyList, A_studyNode);
            curStudy = LLPopDataPtrN( &StudyList, i);
        }
    }

    seriesCount = LLNodes( &curStudy->SeriesList);
    if ( seriesCount == 0 )
    {
        LLCreate(&A_seriesNode->InstanceList, sizeof(InstanceNode));
        LLInsert( &curStudy->SeriesList, A_seriesNode);
        curSeries = LLPopDataPtrN( &curStudy->SeriesList, 1);
    } else
    {
        found = FALSE;
        LLRewind( &curStudy->SeriesList);
        for ( i = 1; i <= seriesCount; i++ )
        {
            curSeries = LLPopDataPtr( &curStudy->SeriesList);

            if ( strcmp(curSeries->ser_uid, A_seriesNode->ser_uid) == 0 )
            {
                found = TRUE;
                break;
            }
        }

        if ( found == FALSE )
        {
            LLCreate(&A_seriesNode->InstanceList, sizeof(InstanceNode));
            LLInsert( &curStudy->SeriesList, A_seriesNode);
            curSeries = LLPopDataPtrN( &curStudy->SeriesList, i);
        }
    }

    instanceCount = LLNodes( &curSeries->InstanceList);
    if ( instanceCount == 0 )
    {
        LLInsert( &curSeries->InstanceList, A_instanceNode);
        curInstance = LLPopDataPtrN( &curSeries->InstanceList, 1);
    } else
    {
        found = FALSE;

        LLRewind( &curSeries->InstanceList);
        for ( i = 1; i <= instanceCount; i++ )
        {
            curInstance = LLPopDataPtr( &curSeries->InstanceList );

            if ( strcmp(curInstance->sop_uid, A_instanceNode->sop_uid) == 0 )
            {
                found = TRUE;
                break;
            }
        }

        if ( found == FALSE )
        {
            LLInsert( &curSeries->InstanceList, A_instanceNode);
        }
    }
}


/*****************************************************************************
**
** NAME
**    GetDataFromMessage - Get Study / Series / Instance info from message
**
** ARGUMENTS
**    StudyNode* study        Pointer to struct to fill
**    SeriesNode* series      Pointer to struct to fill
**    InstanceNode* instance  Pointer to struct to fill
**    int messageID           ID of message to get data from
**
** DESCRIPTION
**    This function will fill the structs in the
**    parameter list with data from the specified
**    message.
**
** RETURNS
**    QR_SUCCESS if the routine finishes properly.
**    QR_FAILURE if the routine detects an error.
**
*****************************************************************************/
static int GetDataFromMessage(StudyNode* study, SeriesNode* series, InstanceNode* instance, int messageID)
{
    /*
     * Get Patient data
     */
    if ( GetValue ( messageID, MC_ATT_PATIENT_ID,
                    study->pat_id, sizeof ( study->pat_id ),
                    "" ) == QR_FAILURE )
        return( QR_FAILURE );
    trim(study->pat_id);

    if ( GetValue ( messageID, MC_ATT_PATIENTS_NAME,
                    study->pat_name, sizeof ( study->pat_name ),
                    "" ) == QR_FAILURE )
        return( QR_FAILURE );
    trim(study->pat_name);

    if ( GetValue ( messageID, MC_ATT_PATIENTS_BIRTH_DATE,
                    study->pat_bday, sizeof ( study->pat_bday ),
                    "" ) == QR_FAILURE )
        return( QR_FAILURE );
    trim(study->pat_bday);

    if ( GetValue ( messageID, MC_ATT_PATIENTS_SEX,
                    study->pat_sex, sizeof ( study->pat_sex ),
                    "" ) == QR_FAILURE )
        return( QR_FAILURE );
    trim(study->pat_sex);

    /*
     * Get Study Data
     */
    if ( GetValue ( messageID, MC_ATT_STUDY_INSTANCE_UID,
                    study->stu_inst, sizeof ( study->stu_inst ),
                    "" ) == QR_FAILURE )
        return( QR_FAILURE );
    trim(study->stu_inst);

    if ( GetValue ( messageID, MC_ATT_STUDY_DATE,
                    study->stu_date, sizeof ( study->stu_date ),
                    "" ) == QR_FAILURE )
        return( QR_FAILURE );
    trim(study->stu_date);

    if ( GetValue ( messageID, MC_ATT_STUDY_TIME,
                    study->stu_time, sizeof ( study->stu_time ),
                    "" ) == QR_FAILURE )
        return( QR_FAILURE );
    trim(study->stu_time);

    if ( GetValue ( messageID, MC_ATT_ACCESSION_NUMBER,
                    study->stu_anum, sizeof ( study->stu_anum ),
                    "" ) == QR_FAILURE )
        return( QR_FAILURE );
    trim(study->stu_anum);

    if ( GetValue ( messageID, MC_ATT_STUDY_ID,
                    study->stu_id, sizeof ( study->stu_id ),
                    "" ) == QR_FAILURE )
        return( QR_FAILURE );
    trim(study->stu_id);

    if ( GetValue ( messageID, MC_ATT_STUDY_DESCRIPTION,
                    study->stu_desc, sizeof ( study->stu_desc ),
                    "" ) == QR_FAILURE )
        return( QR_FAILURE );
    trim(study->stu_desc);

    if ( GetValue ( messageID, MC_ATT_REFERRING_PHYSICIANS_NAME,
                    study->stu_physname, sizeof ( study->stu_physname ),
                    "" ) == QR_FAILURE )
        return( QR_FAILURE );
    trim(study->stu_physname);

    /*
     * Get Series Data
     */
    if ( GetValue ( messageID, MC_ATT_SERIES_INSTANCE_UID,
                    series->ser_uid, sizeof ( series->ser_uid ),
                    "" ) == QR_FAILURE )
        return( QR_FAILURE );
    trim(series->ser_uid);

    if ( GetValue ( messageID, MC_ATT_SERIES_NUMBER,
                    series->ser_num, sizeof ( series->ser_num ),
                    "" ) == QR_FAILURE )
        return( QR_FAILURE );
    trim(series->ser_num);

    if ( GetValue ( messageID, MC_ATT_MODALITY,
                    series->ser_mode, sizeof ( series->ser_mode ),
                    "" ) == QR_FAILURE )
        return( QR_FAILURE );
    trim(series->ser_mode);

    /*
     * Get Instance Data
     */
    if ( GetValue ( messageID, MC_ATT_SOP_INSTANCE_UID,
                    instance->sop_uid, sizeof ( instance->sop_uid ),
                    "" ) == QR_FAILURE )
        return( QR_FAILURE );
    trim(instance->sop_uid);

    if ( GetValue ( messageID, MC_ATT_SOP_CLASS_UID,
                    instance->sop_classuid, sizeof ( instance->sop_classuid ),
                    "" ) == QR_FAILURE )
        return( QR_FAILURE );
    trim(instance->sop_classuid);

    if ( GetValue ( messageID, MC_ATT_IMAGE_NUMBER,
                    instance->img_num, sizeof ( instance->img_num ),
                    "" ) == QR_FAILURE )
        return( QR_FAILURE );
    trim(instance->img_num);

    return QR_SUCCESS;
}


/*****************************************************************************
**
** NAME
**    HandleAssociation - Process the new DICOM association
**
** ARGUMENTS
**    A_applicationID    int            Application ID
**    A_associationID    int            Association ID for the first association
**    A_myConfig         AppConfig *    Configuration struct for file name
**
** DESCRIPTION
**    This routine handles the newly opened association.  It reads a message
**    from the network then processes that message by calling the appropriate
**    processing routine.
**
** RETURNS
**    QR_SUCCESS if the routine finishes properly.
**    QR_FAILURE if the routine detects an error.
**
** SEE ALSO
**    PrintErrorMessage
**    ProcessCFINDRQ
**    ProcessCGETRQ
**    MC_Accept_Association
**    MC_Free_Message
**    MC_Get_Value_To_String
**    MC_Read_Message
**
*****************************************************************************/
static QR_STATUS HandleAssociation ( int A_applicationID,
                                     int A_associationID,
                                     AppConfig* A_myConfig )
{
    static char       S_prefix[] = "HandleAssociation";
    MC_STATUS         mcStatus;
    QR_STATUS         qrStatus;
    MC_COMMAND        command;
    RESP_STATUS       retStatus;
    char              *serviceName;
    int               messageID;
    int               rspMsgID;
    time_t            startTime;

    time ( &startTime );

    /*
     * Accept the remote apps request for a DICOM session
     */
    mcStatus = MC_Accept_Association ( A_associationID );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "MC_Accept_Association",
                            mcStatus, NULL );
        return( QR_FAILURE );
    }

    DO_FOREVER
    {
        /*
         * Wait for the remote DICOM app to send a message
         */
        mcStatus = MC_Read_Message ( A_associationID,
                                   atoi ( A_myConfig->TimeOut ),
                                   &messageID,
                                   &serviceName,
                                   &command );
        if ( mcStatus == MC_TIMEOUT )
        {
            printf("Timed out waiting for a request message. Continuing.\n");
            continue;
        } else if ( mcStatus == MC_ASSOCIATION_CLOSED )
            return( QR_SUCCESS );
        else if ( mcStatus == MC_NETWORK_SHUT_DOWN
                  || mcStatus == MC_ASSOCIATION_ABORTED )
        {
            PrintErrorMessage ( S_prefix, "MC_Read_Message",
                                mcStatus, NULL );
            return( QR_SUCCESS );
        } else if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            MC_Free_Message ( &messageID );
            MC_Abort_Association ( &A_associationID );
            PrintErrorMessage ( S_prefix, "MC_Read_Message",
                                mcStatus, NULL );
            return( QR_FAILURE );
        }

        switch ( command )
        {
            case C_FIND_RQ:
                printf ( "%s: --- Received a C_FIND_RQ request.\n", S_prefix );
                qrStatus = ProcessCFINDRQ ( A_associationID,
                                            messageID,
                                            A_myConfig,
                                            serviceName);
                if ( qrStatus != QR_SUCCESS )
                {
                    MC_Free_Message ( &messageID );
                    PrintErrorMessage ( S_prefix, "ProcessCFINDRQ", -1,
                                        "Error processing find message" );
                    return( QR_FAILURE );
                }

                mcStatus = MC_Free_Message ( &messageID );
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage( S_prefix, "MC_Free_Message failed", mcStatus, NULL);
                    return( QR_FAILURE );
                }

                /*
                 * Note that the ProcessCFINDRQ function sends the
                 * appropriate response messages.  We do not have to
                 * send one here.
                 */
                printf ( "%s: --- Done processing C_FIND_RQ\n", S_prefix );
                fflush ( stdout );
                break;

            case C_GET_RQ:
                /*
                 * Process the Get request
                 */
                printf ( "%s: --- Received a C_GET_RQ request.\n", S_prefix );
                retStatus = ProcessCGETRQ ( A_applicationID,
                                            A_associationID,
                                            messageID,
                                            A_myConfig, serviceName);

                /*
                 * Send back an empty response message signaling the query is finished
                 */
                mcStatus = MC_Open_Message(&rspMsgID,serviceName,C_GET_RSP);
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage( S_prefix, "MC_Open_Message", mcStatus,
                                       "Unable to open empty request message");
                    return( QR_FAILURE );
                }

                /*
                 * Free the message. Note that this is done after the GET_RSP is
                 * created because the serviceName used in MC_Open_Message is released
                 * when the message is freed causing a potential memory access problem.
                 */
                mcStatus = MC_Free_Message ( &messageID );
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage( S_prefix, "MC_Free_Message", mcStatus, NULL);
                    return( QR_FAILURE );
                }

                mcStatus = MC_Send_Response_Message ( A_associationID,
                                                    retStatus,
                                                    rspMsgID );
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    MC_Free_Message ( &rspMsgID );
                    PrintErrorMessage ( S_prefix, "MC_Send_Response_Message",
                                        mcStatus, NULL );
                    return( QR_FAILURE );
                }

                mcStatus = MC_Free_Message(&rspMsgID);
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage( S_prefix, "MC_Free_Message", mcStatus, NULL);
                    return( QR_FAILURE );
                }

                printf ( "%s: --- Done processing C_GET_RQ\n", S_prefix );
                fflush ( stdout );
                break;

            case C_STORE_RQ:

                printf ( "%s: --- Received a C_STORE_RQ request.\n", S_prefix );

                qrStatus = ProcessCSTORERQ(A_myConfig, A_applicationID, A_associationID, messageID, serviceName);
                if ( qrStatus != QR_SUCCESS )
                {
                    printf( "%s: --- Error processing C_STORE_RQ\n", S_prefix );
                    return( QR_FAILURE );
                }

                printf ( "%s: --- Done processing C_STORE_RQ\n", S_prefix );
                fflush ( stdout );
                break;

        } /* switch command */

    } /* DO_FOREVER */
} /* HandleAssociation */


/*****************************************************************************
**
** NAME
**    ProcessCSTORERQ - Process a C-FIND Request
**
** ARGUMENTS
**    A_applicationID     int              Application ID
**    A_associationID     int              Association ID
**    A_msgID             int *            Message ID
**    A_myConfig          AppConfig *      Structure for data file name
**    serviceName         char *           Array of info to send back
**
** DESCRIPTION
**    This routine processes a C-STORE request. It updates the linked list, writes the image
**    to the defined storage directory, and updates the storage index file.
**
** RETURNS
**    QR_SUCCESS if the routine finishes properly.
**    QR_FAILURE if the routine detects an error.
**
*****************************************************************************/
static QR_STATUS ProcessCSTORERQ(AppConfig *A_myConfig, int A_applicationID,
                                 int A_associationID, int msgID, char* serviceName)
{
    char                fname[1024];
    MC_STATUS           mcStatus;
    QR_STATUS           qrStatus;
    RESP_STATUS         respStatus = C_STORE_SUCCESS;
    int                 rspMsgID;
    StudyNode           study;
    SeriesNode          series;
    InstanceNode        instance;

    /*get data from the message we just received*/
    if ( !GetDataFromMessage(&study, &series, &instance, msgID) )
    {
        respStatus = C_STORE_FAILURE_PROCESSING_FAILURE;
    }

    if ( respStatus == C_STORE_SUCCESS )
    {
        sprintf(fname, "%s%s%s.dcm", A_myConfig->StorageFolder, SLASH, instance.sop_uid);

        qrStatus = WriteToMedia(A_myConfig, fname, &msgID, serviceName);

        if(qrStatus == QR_SUCCESS)
        {
            InsertInstance(&study, &series, &instance);
        }
        else
        {
            respStatus = C_STORE_FAILURE_PROCESSING_FAILURE;
        }
    }

    /*send the response message*/
    mcStatus = MC_Open_Message (&rspMsgID, serviceName, C_STORE_RSP);
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->ApplicationTitle, "MC_Open_Message", mcStatus, NULL);
        MC_Abort_Association(&A_associationID);
        return( QR_FAILURE);
    }

    mcStatus = MC_Send_Response_Message(A_associationID, respStatus, rspMsgID);
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->ApplicationTitle, "MC_Send_Response_Message", mcStatus, NULL);
        MC_Abort_Association(&A_associationID);
        MC_Free_Message(&rspMsgID);
        return( QR_FAILURE);
    }

    /*free up the message*/
    mcStatus = MC_Free_Message(&rspMsgID);
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->ApplicationTitle, "MC_Free_Message", mcStatus,
                          "Error freeing response message");
        MC_Abort_Association(&A_associationID);
        return( QR_FAILURE);
    }

    return( QR_SUCCESS);
} /* ProcessCSTOREAssociation() */


/*****************************************************************************
**
** NAME
**    GetValue - Gets the value from a message for specific tags
**
** ARGUMENTS
**    A_messageid    int              Id of message the value is being set in
**    A_tag          unsigned long    Tag of message that is to be set
**    A_value        char *           Value of tag that is to be set
**    A_size         int              Size of the buffer to hold the tag value
**    A_default      char *           Default value of tag, if A_value is NULL
**
** DESCRIPTION
**    Gets the value of a tag from a given message id.
**
** RETURNS
**    QR_SUCCESS or QR_FAILURE
**
*****************************************************************************/
static QR_STATUS GetValue ( int A_messageid, unsigned long A_tag,
                            char *A_value, int A_size, char *A_default )
{
    MC_STATUS      mcStatus;
    static char    S_prefix[] = "GetValue";

    mcStatus = MC_Get_Value_To_String ( A_messageid, A_tag, A_size,
                                      A_value );
    if ( mcStatus == MC_NULL_VALUE || mcStatus == MC_EMPTY_VALUE  ||
         mcStatus == MC_INVALID_TAG )
    {
        if ( !A_default )
        {
            A_value[0] = '\0';
            return( QR_NOTAG );
        }
        strncpy ( A_value, A_default, A_size );
        A_value[A_size-1] = '\0';
    } else if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "MC_Get_Value_To_String", mcStatus, NULL );
        printf("%s: ***          Tag:  %lX\n", S_prefix, A_tag);
        return( QR_FAILURE );
    }
    return( QR_SUCCESS );
} /* GetValue() */


/********************************************************************
**
** NAME
**    WriteToMedia
**
** ARGUMENTS
**    Aoptions   - Structure that holds configuration
**                 parameters
**    A_filename - Filename to write to
**    A_msgID    - ID of message received to write
**    A_msgType  - Character string describing the
**                 message type
**
** RETURNS
**    QR_SUCCESS or QR_FAILURE
**
** DESCRIPTION
**    Converts a message received over the network
**    into a DICOM-3 formatted file.
**
*********************************************************************/
static QR_STATUS WriteToMedia( AppConfig*    A_myConfig,
                               char*         A_filename,
                               int*          A_msgID,
                               char*         A_messageType )
{
    MC_STATUS        mcStatus;
    QR_STATUS        qrStatus;
    CBinfo           callbackInfo;
    TRANSFER_SYNTAX  messageSyntax;
    TRANSFER_SYNTAX  resultSyntax;

    /*
     * Get the transfer syntax that the message was transferred over
     * the network as.  This is to determine if it is JPEG encoded.
     */
    mcStatus = MC_Get_Message_Transfer_Syntax( *A_msgID, &messageSyntax );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->ApplicationTitle, "MC_Get_Message_Transfer_Syntax", mcStatus, NULL);
        MC_Free_Message(A_msgID);
        return QR_FAILURE;
    }
    else
    {
        /*
         * For the standard syntaxes, save in the configured syntax.
         * For all the encapsualted/compressed syntaxes, save in the
         * syntax received.
         */
        switch ( messageSyntax )
        {
            case IMPLICIT_LITTLE_ENDIAN:
            case EXPLICIT_LITTLE_ENDIAN:
            case EXPLICIT_BIG_ENDIAN:
            case IMPLICIT_BIG_ENDIAN:
                resultSyntax = A_myConfig->SaveSyntax;
                break;

            default:
                resultSyntax = messageSyntax;
                break;
        }
    }

    /*
     * Now convert message object to a file object.  This changes the
     * toolkit's internal representation of the file from a message to a
     * file object.  It also allows the group 0x0002 elements to be used
     * in the object.  Any other attributes within the message can still
     * be dealt with when it is classified as a file.
     */
    mcStatus = MC_Message_To_File( *A_msgID, A_filename );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->ApplicationTitle, "MC_Message_To_File", mcStatus, NULL);
        MC_Free_File(A_msgID);
        return QR_FAILURE;
    }

    /*
     * Add the group 2 elements to the object.
     */
    qrStatus = AddGroup2Elements( A_myConfig, resultSyntax, *A_msgID );
    if ( qrStatus == QR_FAILURE )
    {
        PrintErrorMessage(A_myConfig->ApplicationTitle, "AddGroup2Elements", mcStatus, NULL);
        MC_Free_File(A_msgID);
        return QR_FAILURE;
    }

    printf("Writing %s image in DICOM Part 10 format:  %s\n", A_messageType, A_filename);

    /*
     * Write out the new file.
     */
    mcStatus = MC_Write_File( *A_msgID,
                              0,
                              &callbackInfo,
                              FileObjToMedia );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        if ( callbackInfo.stream )
            fclose(callbackInfo.stream);

        PrintErrorMessage(A_myConfig->ApplicationTitle, "MC_Write_File", mcStatus, NULL);
        MC_Free_File(A_msgID);
        return QR_FAILURE;
    }

    if ( callbackInfo.stream )
        fclose(callbackInfo.stream);

    mcStatus = MC_Free_File(A_msgID);
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->ApplicationTitle, "MC_Free_File", mcStatus, NULL);
        return QR_FAILURE;
    }

    return QR_SUCCESS;
} /* WriteToMedia() */


/****************************************************************************
**
** NAME
**    FileObjToMedia
**
** ARGUMENTS
**    A_filename   - Filename to write to
**    A_userInfo   - Information to store between calls to this
**                   function
**    A_dataSize   - Size of A_dataBuffer
**    A_dataBuffer - Buffer containing data to write
**    A_isFirst    - set to true on first call
**    A_isLast     - Is set to true on the final call
**
** RETURNS
**    MC_NORMAL_COMPLETION on success, any other MC_STATUS
**    value on failure.
**
** DESCRIPTION
**    Callback function used to write DICOM file object to
**    media.  A pointer to this function is passed to
**    MC_Write_File
**
*****************************************************************************/
static MC_STATUS NOEXP_FUNC FileObjToMedia( char*    A_filename,
                                            void*    A_userInfo,
                                            int      A_dataSize,
                                            void*    A_dataBuffer,
                                            int      A_isFirst,
                                            int      A_isLast)
{
    size_t     count;
    CBinfo*    cbInfo = (CBinfo*)A_userInfo;
    int        retStatus;

    if ( A_isFirst )
    {
        cbInfo->stream = fopen(A_filename, BINARY_WRITE);
        if(cbInfo->stream==NULL){
            printf("\nERROR: Can not open %s file. (errno=%d) \n",A_filename,errno);
            return MC_CANNOT_COMPLY;
        }

        retStatus = setvbuf(cbInfo->stream, (char *)NULL, _IOFBF, 32768);
        if ( retStatus != 0 )
        {
            printf("WARNING:  Unable to set IO buffering on input file.\n");
        }
    }

    if ( !cbInfo->stream )
        return MC_CANNOT_COMPLY;

    count = fwrite(A_dataBuffer, 1, A_dataSize, cbInfo->stream);
    if ( count != (size_t)A_dataSize )
    {
        printf("fwrite error");
        return MC_CANNOT_COMPLY;
    }

    retStatus = fflush(cbInfo->stream);
    if ( retStatus != 0 )
    {
        printf("\tfflush error\n");
        fclose(cbInfo->stream);
        cbInfo->stream = NULL;
        return MC_CANNOT_COMPLY;
    }
    if ( A_isLast )
    {
        /*
         * NULL ->fp so that the routine calling MC_Write file knows
         * not to close the stream.
         */
        retStatus = fclose(cbInfo->stream);
        if ( retStatus != 0 )
        {
            printf("\tfclose error\n");
            cbInfo->stream = NULL;
            return MC_CANNOT_COMPLY;
        }
        cbInfo->stream = NULL;
    }

    return MC_NORMAL_COMPLETION;

} /* FileObjToMedia() */


/****************************************************************************
**
**  Function    :   AddGroup2Elements
**
**  Parameters  :   A_options    - Input parameters
**                  AtransSyntax - structure for config options
**                  AfileID      - File to add meta information to
**
**  Returns     :   QR_STATUS
**
**  Description :   Sets group two information in a media file
**
*****************************************************************************/
static QR_STATUS AddGroup2Elements( AppConfig*    A_myConfig,
                                    TRANSFER_SYNTAX A_transSyntax,
                                    int             A_fileID )
{
    MC_STATUS mcStatus;
    char      uidBuffer[UI_LEN+2];
    char      syntaxUID[UI_LEN+2];

    /*
     * Get the correct UID for the new transfer syntax
     */
    mcStatus = MC_Get_Transfer_Syntax_From_Enum(A_transSyntax,
                                                syntaxUID,
                                                sizeof(syntaxUID));
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->ApplicationTitle, "MC_Get_Transfer_Syntax_From_Enum", mcStatus, NULL);
        return QR_FAILURE;
    }

    /*
     * Set the new transfer syntax for this message
     */
    mcStatus = MC_Set_Value_From_String(A_fileID,
                                        MC_ATT_TRANSFER_SYNTAX_UID,
                                        syntaxUID);
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->ApplicationTitle, "MC_Set_Value_From_String", mcStatus, NULL);
        return QR_FAILURE;
    }

    /*
     * Set other media group 2 elements
     */
    mcStatus = MC_Set_Value_From_Function( A_fileID,
                                           MC_ATT_FILE_META_INFORMATION_VERSION,
                                           NULL,
                                           FileMetaInfoVersion );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->ApplicationTitle, "MC_Set_Value_From_Function", mcStatus, NULL);
        return QR_FAILURE;
    }


    mcStatus = MC_Get_Value_To_String( A_fileID,
                                       MC_ATT_SOP_CLASS_UID,
                                       sizeof(uidBuffer),
                                       uidBuffer );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->ApplicationTitle, "MC_Get_Value_To_String", mcStatus,
                          "Unable to get SOP Class UID from image file");
        return QR_FAILURE;
    }

    mcStatus = MC_Set_Value_From_String( A_fileID,
                                         MC_ATT_MEDIA_STORAGE_SOP_CLASS_UID,
                                         uidBuffer);
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->ApplicationTitle, "MC_Set_Value_From_String", mcStatus,
                          "Unable to add media storage SOP Class UID");
        return QR_FAILURE;
    }

    mcStatus = MC_Get_Value_To_String(A_fileID,
                                      MC_ATT_SOP_INSTANCE_UID,
                                      sizeof(uidBuffer),
                                      uidBuffer);
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->ApplicationTitle, "MC_Get_Value_To_String", mcStatus,
                          "Unable to get SOP Instance UID from image file");
        return QR_FAILURE;
    }

    mcStatus = MC_Set_Value_From_String( A_fileID,
                                         MC_ATT_MEDIA_STORAGE_SOP_INSTANCE_UID,
                                         uidBuffer);
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->ApplicationTitle, "MC_Set_Value_From_String", mcStatus,
                          "Unable to add media storage SOP instance UID");
        return QR_FAILURE;
    }

    mcStatus = MC_Set_Value_From_String( A_fileID,
                                         MC_ATT_SOURCE_APPLICATION_ENTITY_TITLE,
                                         A_myConfig->ApplicationTitle);
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->ApplicationTitle, "MC_Set_Value_From_String", mcStatus,
                          "Unable to add source application entity title");
        return QR_FAILURE;
    }

    return QR_SUCCESS;

} /* AddGroup2Elements() */


/********************************************************************
**
**  Function    :   FileMetaInfoVersion
**
**  Parameters  :
**
**  Returns     :   MC_NORMAL_COMPLETION
**
**  Description :   Adds group 2 element for File Meta Information Version
**                  to the preamble of the DICOM file object
**
*********************************************************************/
static MC_STATUS NOEXP_FUNC FileMetaInfoVersion( int           A_msgID,
                                                 unsigned long A_tag,
                                                 int           A_isFirst,
                                                 void*         A_info,
                                                 int*          A_dataSize,
                                                 void**        A_dataBufferPtr,
                                                 int*          A_isLastPtr)
{
    static char version[] = {0x00,0x01};

    *A_dataSize = 2;
    *A_dataBufferPtr = version;
    *A_isLastPtr = 1;

    return MC_NORMAL_COMPLETION;

} /* FileMetaInfoVersion() */

/*************************************************************************************
**  Function:       ProcessCFINDRQ
**
**  Parameter:      int    A_associationID
**                  int    A_messageID
**                  AppConfig*   A_myConfig     Application config info
**                  char   *serviceName         Service name to determine how to send
**
**  Returns:        QR_STATUS
**
**  Description:    This function will use the service name and query level to determine
**                  which database search function to use. This call a function to send
**                  a message indicating completion.
****************************************************************************************/
static QR_STATUS ProcessCFINDRQ ( int    A_associationID,
                                  int    A_messageID,
                                  AppConfig*   A_myConfig,
                                  char   *serviceName)
{
    MC_STATUS             mcStatus;
    char                  queryLevel[LO_LEN];
    static char           S_prefix[] = "ProcessCFINDRQ";
    RESP_STATUS           retStatus = C_FIND_PENDING;

    QR_STATUS             qrStatus = QR_FAILURE;

    mcStatus = MC_Get_Value_To_String ( A_messageID,
                                      MC_ATT_QUERY_RETRIEVE_LEVEL,
                                      sizeof(queryLevel), queryLevel );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix,
                            "QUERY_RETRIEVE_LEVEL, MC_Get_Value_To_String", mcStatus, NULL );
        retStatus = C_FIND_FAILURE_INVALID_DATASET;
    }

    /*use the service name and level information to determine which search function to use*/
    if ( strcmp(serviceName, "PATIENT_STUDY_ONLY_QR_FIND") == 0
      && retStatus != C_FIND_FAILURE_INVALID_DATASET)
    {
        if ( strncmp ( queryLevel, PATIENT_LEVEL, sizeof(PATIENT_LEVEL) ) == 0 )
        {
            qrStatus = SearchDBPatientLevel(serviceName, A_associationID, A_messageID, A_myConfig, retStatus);
        } else if ( strncmp ( queryLevel, STUDY_LEVEL, sizeof(STUDY_LEVEL) ) == 0 )
        {
            qrStatus = SearchDBStudyLevel(serviceName, A_associationID, A_messageID, A_myConfig, retStatus);
        }
    }
    else if ( strcmp(serviceName, "PATIENT_ROOT_QR_FIND") == 0 )
    {
        if ( strncmp ( queryLevel, PATIENT_LEVEL, sizeof(PATIENT_LEVEL) ) == 0 )
        {
            qrStatus = SearchDBPatientLevel(serviceName, A_associationID, A_messageID, A_myConfig, retStatus);
        } else if ( strncmp ( queryLevel, STUDY_LEVEL, sizeof(STUDY_LEVEL) ) == 0 )
        {
            qrStatus = SearchDBStudyLevel(serviceName, A_associationID, A_messageID, A_myConfig, retStatus);
        } else if ( strncmp ( queryLevel, SERIES_LEVEL, sizeof(SERIES_LEVEL) ) == 0 )
        {
            qrStatus = SearchDBSeriesLevel(serviceName, A_associationID, A_messageID, A_myConfig, retStatus);
        } else if ( strncmp ( queryLevel, IMAGE_LEVEL, sizeof(IMAGE_LEVEL) ) == 0 )
        {
            qrStatus = SearchDBImageLevel(serviceName, A_associationID, A_messageID, A_myConfig, retStatus);
        }

    }
    else if ( strcmp(serviceName, "STUDY_ROOT_QR_FIND") == 0 )
    {
        if ( strncmp ( queryLevel, STUDY_LEVEL, sizeof(STUDY_LEVEL) ) == 0 )
        {
            qrStatus = SearchDBStudyRootStudyLevel(serviceName, A_associationID, A_messageID, A_myConfig, retStatus);
        } else if ( strncmp ( queryLevel, SERIES_LEVEL, sizeof(SERIES_LEVEL) ) == 0 )
        {
            qrStatus = SearchDBSeriesLevel(serviceName, A_associationID, A_messageID, A_myConfig, retStatus);
        } else if ( strncmp ( queryLevel, IMAGE_LEVEL, sizeof(IMAGE_LEVEL) ) == 0 )
        {
            qrStatus = SearchDBImageLevel(serviceName, A_associationID, A_messageID, A_myConfig, retStatus);
        }
    }

    if ( SendCFINDComplete ( A_associationID, A_myConfig, retStatus, serviceName) != QR_SUCCESS )
    {
        PrintErrorMessage ( S_prefix, "SendCFINDReply", -1, "Error occured in SendCFINDReply");
            return( qrStatus );
    }

    return qrStatus;
}


/*************************************************************
    Function:       SearchDBStudyRootStudyLevel

    Parameter:      char* serviceName
                    int A_associationID
                    int A_messageID
                    AppConfig* A_myConfig
                    RESP_STATUS retStatus

    Returns:        void

    Description:    This function searches the study level for
                    patient root and patient study only query models.
                    It attempts to find a match using patient name,
                    patient id, patient birth date, patient sex,
                    study instance id, study date, study time,
                    accession number, study id, study description,
                    and study physicians name.
*************************************************************/
static QR_STATUS SearchDBStudyRootStudyLevel(char* serviceName, int A_associationID, int A_messageID, AppConfig* A_myConfig, RESP_STATUS retStatus)
{
    char            pat_id[LO_LEN];
    char            pat_name[PN_LEN];
    char            pat_bday[(DA_LEN * 2) + 1];
    char            pat_sex[CS_LEN];
    char            stu_inst[UI_LEN];
    char            stu_date[(DA_LEN * 2) + 1];
    char            stu_time[TM_LEN];
    char            stu_anum[CS_LEN];
    char            stu_id[CS_LEN];
    char            stu_desc[LO_LEN];
    char            stu_physname[PN_LEN];
    int             studycount;
    MC_STATUS       mcStatus;
    int             i;
    StudyNode       study;
    int             ackSent = FALSE;

    mcStatus = MC_Get_Value_To_String ( A_messageID,
                                      MC_ATT_PATIENT_ID,
                                      sizeof(pat_id),
                                      pat_id );

    if ( mcStatus != MC_NORMAL_COMPLETION)
    {
        strcpy(stu_inst, "");
    }

     mcStatus = MC_Get_Value_To_String ( A_messageID,
                                      MC_ATT_PATIENTS_NAME,
                                      sizeof(pat_name),
                                      pat_name );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(pat_name, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID,
                                      MC_ATT_PATIENTS_BIRTH_DATE,
                                      sizeof(pat_bday),
                                      pat_bday );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(pat_bday, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID,
                                      MC_ATT_PATIENTS_SEX,
                                      sizeof(pat_sex), pat_sex );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(pat_sex, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID,
                                      MC_ATT_STUDY_INSTANCE_UID,
                                      sizeof(stu_inst), stu_inst );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(stu_inst, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID,
                                      MC_ATT_STUDY_DATE,
                                      sizeof(stu_date), stu_date );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(stu_date, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID,
                                      MC_ATT_STUDY_TIME,
                                      sizeof(stu_time), stu_time );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(stu_time, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID,
                                      MC_ATT_ACCESSION_NUMBER,
                                      sizeof(stu_anum), stu_anum );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(stu_anum, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID,
                                      MC_ATT_STUDY_ID,
                                      sizeof(stu_id), stu_id );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(stu_id, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID,
                                      MC_ATT_STUDY_DESCRIPTION,
                                      sizeof(stu_desc), stu_desc );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(stu_desc, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID,
                                      MC_ATT_REFERRING_PHYSICIANS_NAME,
                                      sizeof(stu_physname), stu_physname );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(stu_physname, "");
    }


    LLRewind( &StudyList);
    studycount = LLNodes(&StudyList);
    for ( i = 0; i < studycount; i++ )
    {
        LLPopNode( &StudyList, &study);

        if ( !WildCardMatch( pat_id, study.pat_id))
        {
            continue;
        }

        if ( !WildCardMatch( pat_name, study.pat_name))
        {
            continue;
        }

        if ( !DateAndTimeMatch(pat_bday, study.pat_bday))
        {
            continue;
        }

        if ( !WildCardMatch( pat_sex, study.pat_sex))
        {
            continue;
        }

        if ( !WildCardMatch( stu_inst, study.stu_inst))
        {
            continue;
        }

        if ( !DateAndTimeMatch(stu_date, study.stu_date))
        {
            continue;
        }

        if (!DateAndTimeMatch( stu_time, study.stu_time))
        {
            continue;
        }

        if ( !WildCardMatch( stu_anum, study.stu_anum))
        {
            continue;
        }

        if ( !WildCardMatch(  stu_id, study.stu_id))
        {
            continue;
        }

        if ( !WildCardMatch( stu_desc, study.stu_desc))
        {
            continue;
        }

        if ( !WildCardMatch( stu_physname, study.stu_physname))
        {
            continue;
        }

        SendCFINDReply(serviceName, A_associationID, A_myConfig, retStatus, A_messageID, &study, NULL, NULL, &ackSent);

        if ( ackSent == TRUE )
            return QR_FAILURE;
    }

    return QR_SUCCESS;
}

/*************************************************************
    Function:       SearchDBPatientLevel

    Parameter:      char* serviceName
                    int A_associationID
                    int A_messageID
                    AppConfig* A_myConfig
                    RESP_STATUS retStatus

    Returns:        QR_STATUS

    Description:    This function searches the database at the patient level
                    trying to match the patient name, id, birth date, and sex.
*************************************************************/
static QR_STATUS SearchDBPatientLevel(char* serviceName, int A_associationID, int A_messageID,
                                      AppConfig* A_myConfig, RESP_STATUS retStatus)
{
    char            pat_id[LO_LEN+1];
    char            pat_name[PN_LEN+1];
    char            pat_bday[(DA_LEN * 2) + 1];
    char            pat_sex[CS_LEN+1];
    int             patientcount, studycount;
    LIST            patientlist;
    MC_STATUS       mcStatus;
    int             i, j;
    StudyNode       study;
    int             ackSent = FALSE;


    /*get data from the message*/
    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_PATIENT_ID,
                                      sizeof(pat_id), pat_id );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(pat_id, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_PATIENTS_NAME,
                                      sizeof(pat_name), pat_name );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(pat_name, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_PATIENTS_BIRTH_DATE,
                                      sizeof(pat_bday), pat_bday );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(pat_bday, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_PATIENTS_SEX,
                                      sizeof(pat_sex), pat_sex );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(pat_sex, "");
    }

    LLCreate( &patientlist, LO_LEN+1 );
    patientcount = 0;

    /*traverse tree looking for matches*/
    LLRewind( &StudyList);
    studycount = LLNodes(&StudyList);
    for ( i = 0; i < studycount; i++ )
    {
        LLPopNode( &StudyList, &study);

        LLRewind( &patientlist );
        for ( j = 0; j < patientcount; j++ )
        {
            char list_pat_id[LO_LEN+1];
            LLPopNode( &patientlist, list_pat_id );
            if ( strcmp( list_pat_id, study.pat_id ) == 0 )
                break;
        }
        if (j < patientcount)
            /* this patient has already been dealt with - skip */
            continue;

        LLInsert( &patientlist, study.pat_id );
        patientcount++;

        if (!WildCardMatch(pat_id, study.pat_id))
        {
            continue;
        }

        if ( !WildCardMatch(pat_name, study.pat_name))
        {
            continue;
        }

        if ( !DateAndTimeMatch( pat_bday, study.pat_bday))
        {
            continue;
        }

        if (!WildCardMatch(pat_sex, study.pat_sex))
        {
            continue;
        }

        /*the node hasn't been disqualified, send it*/
        SendCFINDReply(serviceName, A_associationID, A_myConfig,
                       retStatus, A_messageID, &study, NULL, NULL, &ackSent);

        if ( ackSent == TRUE )
            return QR_FAILURE;
    }

    LLDestroy( &patientlist );

    return QR_SUCCESS;
}

/*************************************************************
    Function:       SearchDBStudyLevel

    Parameter:      char* serviceName
                    int A_associationID
                    int A_messageID
                    AppConfig* A_myConfig
                    RESP_STATUS retStatus

    Returns:        QR_STATUS

    Description:    This function searches the study level for
                    patient root and patient study only query models.
                    It attempts to find a match using patient name,
                    patient id, patient birth date, patient sex,
                    study instance id, study date, study time,
                    accession number, study id, study description,
                    and study physcians name.
*************************************************************/
static QR_STATUS SearchDBStudyLevel(char* serviceName, int A_associationID,
                                    int A_messageID, AppConfig* A_myConfig,
                                    RESP_STATUS retStatus)
{
    char            pat_id[LO_LEN];
    char            stu_inst[UI_LEN];
    char            stu_date[(DA_LEN * 2) + 1];
    char            stu_time[TM_LEN];
    char            stu_anum[CS_LEN];
    char            stu_id[CS_LEN];
    char            stu_desc[LO_LEN];
    char            stu_physname[PN_LEN];
    int             studycount;
    MC_STATUS       mcStatus;
    int             i;
    StudyNode       study;
    int             ackSent = FALSE;
    static char     S_prefix[]="SearchDBStudyLevel";

    mcStatus = MC_Get_Value_To_String ( A_messageID,
                                      MC_ATT_PATIENT_ID,
                                      sizeof(pat_id), pat_id );

    if ( mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage ( S_prefix, "Patient ID, MC_Get_Value_To_String", mcStatus, NULL );
        return QR_FAILURE;
    }


    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_STUDY_INSTANCE_UID,
                                      sizeof(stu_inst), stu_inst );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(stu_inst, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_STUDY_DATE,
                                      sizeof(stu_date), stu_date );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(stu_date, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_STUDY_TIME,
                                      sizeof(stu_time), stu_time );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(stu_time, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_ACCESSION_NUMBER,
                                      sizeof(stu_anum), stu_anum );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(stu_anum, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_STUDY_ID,
                                      sizeof(stu_id), stu_id );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(stu_id, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_STUDY_DESCRIPTION,
                                      sizeof(stu_desc), stu_desc );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(stu_desc, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_REFERRING_PHYSICIANS_NAME,
                                      sizeof(stu_physname), stu_physname );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(stu_physname, "");
    }


    LLRewind( &StudyList);
    studycount = LLNodes(&StudyList);
    for ( i = 0; i < studycount; i++ )
    {
        LLPopNode( &StudyList, &study);

        if (!WildCardMatch(pat_id, study.pat_id))
        {
            continue;
        }

        if ( !WildCardMatch( stu_inst, study.stu_inst))
        {
            continue;
        }

        if ( !DateAndTimeMatch(stu_date, study.stu_date))
        {
            continue;
        }

        if ( !DateAndTimeMatch( stu_time, study.stu_time))
        {
            continue;
        }

        if ( !WildCardMatch( stu_anum, study.stu_anum))
        {
            continue;
        }

        if ( !WildCardMatch(  stu_id, study.stu_id))
        {
            continue;
        }

        if ( !WildCardMatch( stu_desc, study.stu_desc))
        {
            continue;
        }

        if ( !WildCardMatch( stu_physname, study.stu_physname))
        {
            continue;
        }

        SendCFINDReply(serviceName, A_associationID, A_myConfig, retStatus,
                       A_messageID, &study, NULL, NULL, &ackSent);

        if ( ackSent == TRUE )
            return QR_FAILURE;
    }

    return QR_SUCCESS;
}


/*************************************************************
    Function:       SearchDBSeriesLevel

    Parameter:      char* serviceName
                    int A_associationID
                    int A_messageID
                    AppConfig* A_myConfig
                    RESP_STATUS retStatus

    Returns:        QR_STATUS

    Description:    This function searches the series level for
                    the patient root and patient study only query models.
                    It attempts to find a match using study instance id,
                    series instance id, series number, and modality.
*************************************************************/
static QR_STATUS SearchDBSeriesLevel(char* serviceName, int A_associationID, int A_messageID,
                                     AppConfig* A_myConfig, RESP_STATUS retStatus)
{
    char            stu_inst[UI_LEN];
    char            pat_id[LO_LEN];
    char            ser_uid[UI_LEN];
    char            ser_num[IS_LEN];
    char            ser_mode[CS_LEN];
    int             studycount;
    int             seriescount;
    MC_STATUS       mcStatus;
    int             i, j;
    StudyNode       study;
    SeriesNode      series;
    int             ackSent = FALSE;
    int             isStudyRoot = FALSE;
    static char     S_prefix[]="SearchDBSeriesLevel";

    if(strcmp(serviceName, Services.STUDY_ROOT_QR_FIND)==0)
    {
        isStudyRoot = TRUE;
    }

    LLRewind( &StudyList);

    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_PATIENT_ID,
                                      sizeof(pat_id), pat_id );
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        if(isStudyRoot == FALSE)
        {
            PrintErrorMessage ( S_prefix, "Patient ID, MC_Get_Value_To_String", mcStatus, NULL );
            return QR_FAILURE;
        }
        else
        {
            strcpy(pat_id, "");
        }
    }


    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_STUDY_INSTANCE_UID,
                                      sizeof(stu_inst), stu_inst );

    if ( mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage ( S_prefix, "Study Instance UID, MC_Get_Value_To_String", mcStatus, NULL );
        return QR_FAILURE;
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_SERIES_INSTANCE_UID,
                                      sizeof(ser_uid), ser_uid );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(ser_uid, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_SERIES_NUMBER,
                                      sizeof(ser_num), ser_num );

    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(ser_num, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_MODALITY,
                                      sizeof(ser_mode), ser_mode );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(ser_mode, "");
    }

    LLRewind( &StudyList);
    studycount = LLNodes(&StudyList);
    for ( i = 0; i < studycount; i++ )
    {
        LLPopNode( &StudyList, &study);

        if ( (strcmp(study.pat_id, pat_id)==0 || isStudyRoot == TRUE)
          && strcmp(study.stu_inst, stu_inst)==0 )
        {
            seriescount = LLNodes( &study.SeriesList);
            LLRewind( &study.SeriesList);
            for ( j = 0; j < seriescount; j++ )
            {
                LLPopNode(&study.SeriesList, &series);
                if ( !WildCardMatch( ser_uid, series.ser_uid))
                {
                    continue;
                }

                if ( !WildCardMatch( ser_mode, series.ser_mode))
                {
                    continue;
                }

                if ( !WildCardMatch( ser_num, series.ser_num ))
                {
                    continue;
                }

                SendCFINDReply(serviceName, A_associationID, A_myConfig, retStatus, A_messageID, &study, &series, NULL, &ackSent);

                if ( ackSent == TRUE )
                    return QR_FAILURE;

            }
        }
    }

    return QR_SUCCESS;
}


/*************************************************************
    Function:       SearchDBImageLevel

    Parameter:      char* serviceName
                    int A_associationID
                    int A_messageID
                    AppConfig* A_myConfig
                    RESP_STATUS retStatus

    Returns:        QR_STATUS

    Description:    This function searches the image level for
                    the patient root and  patient study only query
                    models. It uses SOP instance ID, SOP class ID,
                    and image number for comparison.
*************************************************************/
static QR_STATUS SearchDBImageLevel(char* serviceName, int A_associationID, int A_messageID,
                                    AppConfig* A_myConfig, RESP_STATUS retStatus)
{
    char            stu_inst[UI_LEN];
    char            pat_id[LO_LEN];
    char            ser_uid[UI_LEN];
    char            sop_uid[UI_LEN];
    char            sop_classuid[UI_LEN];
    char            img_num[IS_LEN];
    int             studycount;
    int             seriescount;
    MC_STATUS       mcStatus;
    int             i, j, k;
    StudyNode       study;
    SeriesNode      series;
    InstanceNode    instance;
    int             ackSent = FALSE;
    int             isStudyRoot = FALSE;
    static char     S_prefix[]="SearchDBSeriesLevel";

    if(strcmp(serviceName, Services.STUDY_ROOT_QR_FIND)==0)
    {
        isStudyRoot = TRUE;
    }

    LLRewind( &StudyList);

    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_PATIENT_ID,
                                      sizeof(pat_id), pat_id );
    if ( mcStatus != MC_NORMAL_COMPLETION)
    {
        if(isStudyRoot == FALSE)
        {
            PrintErrorMessage ( S_prefix, "Patient ID, MC_Get_Value_To_String", mcStatus, NULL );
            return QR_FAILURE;
        }
        else
        {
            strcpy(pat_id, "");
        }
    }


    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_STUDY_INSTANCE_UID,
                                      sizeof(stu_inst), stu_inst );
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage ( S_prefix, "Study Instance UID, MC_Get_Value_To_String", mcStatus, NULL );
        return QR_FAILURE;
    }


    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_SERIES_INSTANCE_UID,
                                      sizeof(ser_uid), ser_uid );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "Series Instance UID, MC_Get_Value_To_String", mcStatus, NULL );
        return QR_FAILURE;
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_SOP_INSTANCE_UID,
                                      sizeof(sop_uid), sop_uid );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(sop_uid, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_SOP_CLASS_UID,
                                      sizeof(sop_classuid), sop_classuid );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(sop_classuid, "");
    }

    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_IMAGE_NUMBER,
                                      sizeof(img_num), img_num );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        strcpy(img_num, "");
    }

    LLRewind( &StudyList);
    studycount = LLNodes(&StudyList);
    for ( i = 0; i < studycount; i++ )
    {
        LLPopNode( &StudyList, &study);

        if ( (strcmp(study.pat_id, pat_id)==0 || isStudyRoot == TRUE)
          && strcmp(study.stu_inst, stu_inst)==0 )
        {
            seriescount = LLNodes( &study.SeriesList);
            LLRewind( &study.SeriesList);
            for ( j = 0; j < seriescount; j++ )
            {
                LLPopNode(&study.SeriesList, &series);

                if ( strcmp(series.ser_uid, ser_uid) == 0 )
                {
                    LLRewind( &series.InstanceList);
                    for ( k = 0; k < seriescount; k++ )
                    {
                        LLPopNode( &series.InstanceList, &instance);
                        if ( !WildCardMatch( sop_uid, instance.sop_uid))
                        {
                            continue;
                        }
                        if ( !WildCardMatch( sop_classuid, instance.sop_classuid))
                        {
                            continue;
                        }
                        if ( !WildCardMatch( img_num, instance.img_num))
                        {
                            continue;
                        }

                        SendCFINDReply(serviceName, A_associationID, A_myConfig, retStatus, A_messageID, &study, &series, &instance, &ackSent);

                        if ( ackSent == TRUE )
                            return QR_FAILURE;

                    }
                }
            }
        }
    }

    return QR_SUCCESS;
}


/*************************************************************
**  Function:       WildCardMatch
**
**  Parameter:      char*    string1    String containing wildcards
**                  char*    string2    String containing data
**
**  Returns:        int
**
**  Description:    This function compares a string with wild card
**                  values to another string
*************************************************************/
static int WildCardMatch(char* string1, char* string2)
{
    int i;
    int j;
    int len1;
    int len2;

    if(strcmp(string1, "*")==0)
        return TRUE;

    if(strcmp(string1, "")==0)
        return TRUE;

    len1 = (int) strlen(string1);
    len2 = (int) strlen(string2);

    i = 0;
    j = 0;
    while(i < len1)
    {
        if(string1[i] == '*')
        {
            while(j < len2)
            {
                if(WildCardMatch(&string1[i + 1], &string2[j]) == TRUE)
                {
                    return TRUE;
                }

                j++;
            }
        }

        if(string1[i] == '?')
        {
            i++;
            j++;
            continue;
        }

        if(string1[i] != string2[j])
        {
            return FALSE;
        }
        i++;
        j++;
    }

    if(i == len1 && j == len2)
    {
        return TRUE;
    }

    return FALSE;
}


/*************************************************************
**  Function:       DateAndTimeMatch
**
**  Parameter:      char*    range    String containing date range
**                  char*    time     String containing date
**
**  Returns:        int
**
**  Description:    This function compares a string with wild card
**                  values to another string
*************************************************************/
static int DateAndTimeMatch( char* range, char* data)
{
    char* high = NULL;
    char* low = NULL;
    int result = FALSE;
    int isRange = FALSE;
    int pos = 0;

    if(range[0] == 0 || data[0] == 0) return TRUE;

    low = (char*) malloc( strlen(range) + 1 );
    strcpy(low, range);

    while(low[pos] != 0)
    {
        if(low[pos] == '-')
        {
            isRange = TRUE;
            low[pos] = 0;
            high = low + pos + 1;
            if(high[0] == 0) high = NULL;
            break;
        }
        pos++;
    }

    if(high == NULL)
    {
        pos = strcmp(data, low);

        if(pos == 0 ) result = TRUE;
        else if( isRange && pos > 0 ) result = TRUE;
    }
    else if(low[0] == 0)
    {
        if( strcmp(data, high) <=0 ) result = TRUE;
    }
    else
    {
        if(strcmp(data, low) >= 0 && strcmp(data, high) <= 0) result = TRUE;
    }

    free(low);
    return result;
}

/*****************************************************************************
**
** NAME
**    ProcessCGETRQ - Process a C-GET request.
**
** ARGUMENTS
**    A_applicationID     int            Application ID.
**    A_associationID     int            Association ID
**    A_messageID         int            Message ID.
**    A_myConfig          AppConfig *    Config struct for data file name
**    serviceName         char*          to determine what information to send
**
** DESCRIPTION
**    This function is used to process a C-GET request.  When this routine
**    executes, it acts as a C-STORE Service Class User. 
**    The SCP turns into a C-STORE SCU.
**    The C-STORE sub-operations occur on the same Association as the C-GET.
**    The SCP opens a store request message, streams the message in from a file 
**    and sends the message to the application that originated the C-GET request.
**
** RETURNS
**    C_GET_SUCCESS_NO_FAILURES_OR_WARNINGS
**    C_GET_FAILURE_INVALID_DATASET
**    C_GET_FAILURE_REFUSED_CANT_CALC_MATCHES
**    C_GET_FAILURE_UNABLE_TO_PROCESS
**    C_GET_FAILURE_REFUSED_CANT_PERFORM
** SEE ALSO
**    MC_Abort_Association
**    MC_Close_Association
**    MC_Free_Message
**    MC_Get_Value_To_String
**    MC_Get_Value_To_UInt
**    MC_Open_Association
**    MC_Open_Message
**    MC_Send_Request_Message
**    MC_Stream_To_Message
**    PrintErrorMessage
**    WriteToListFile
**
*****************************************************************************/
static RESP_STATUS ProcessCGETRQ ( int         A_applicationID,
                                   int         A_associationID,
                                   int         A_messageID,
                                   AppConfig*  A_myConfig,
                                   char*       serviceName)
{

    static char   S_prefix[]="ProcessCGETRQ";
    MC_STATUS     mcStatus;
    MC_COMMAND    command;
    CBinfo        callBackInfo;
    int           associationID;
    int           responseMessageID;
    int           i, j, k;
    unsigned int  response;

    char          serviceName2[SERVICENAME_LEN+1];
    char          level[LO_LEN+1];
    char          patientID[LO_LEN+1];
    char          studyUID[UI_LEN+1];
    char          seriesUID[UI_LEN+1];
    char          SOPUID[UI_LEN+1];
    char          SOPClassUID[UI_LEN+1];
    char          affectedSOPinstance[UI_LEN+1];
    int           nodecount;
    int           fileID;
    StudyNode     study;
    SeriesNode    series;
    InstanceNode  instance;
    char          filename[1024];

    /*
     * Determine what level we are at so that we can process the GET request
     * properly.
     */
    mcStatus = MC_Get_Value_To_String( A_messageID, MC_ATT_QUERY_RETRIEVE_LEVEL,
                                       sizeof ( level ), level );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "QUERY_RETRIEVE_LEVEL, MC_Get_Value_To_String",
                            mcStatus, NULL );
        return C_GET_FAILURE_INVALID_DATASET;
    }

    /*
     * Get the information appropriate to the level
     */

    /*don't need the patient ID if is a study or composite instance root GET*/
    if ( strcmp(serviceName, Services.STUDY_ROOT_QR_GET) != 0 &&
         strcmp(serviceName, Services.COMPOSITE_INST_RET_NO_BULK_GET) != 0 &&
         strcmp(serviceName, Services.COMPOSITE_INSTANCE_ROOT_RET_GET) != 0)
    {
        mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_PATIENT_ID,
                                          sizeof(patientID), patientID );
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            PrintErrorMessage ( S_prefix, "Patient ID, MC_Get_Value_To_String",
                                mcStatus, NULL );
            return C_GET_FAILURE_INVALID_DATASET;
        }

        printf ( "%s: --- Received a C_GET_RQ request for %s.\n",
                 S_prefix, patientID );

        trim( patientID );
    }

    if ( strncmp ( level, STUDY_LEVEL, sizeof(STUDY_LEVEL) ) == 0 )
    {
        mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_STUDY_INSTANCE_UID,
                                          sizeof(studyUID),
                                          studyUID );
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            PrintErrorMessage ( S_prefix, "Study Instance UID, MC_Get_Value_To_String",
                                mcStatus, NULL );
            return C_GET_FAILURE_INVALID_DATASET;
        }
    }
    if ( strncmp ( level, SERIES_LEVEL, sizeof(SERIES_LEVEL) ) == 0 )
    {
        mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_SERIES_INSTANCE_UID,
                                          sizeof(seriesUID), seriesUID );
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            PrintErrorMessage ( S_prefix, "Series Instance UID, MC_Get_Value_To_String",
                                mcStatus, NULL );
            return C_GET_FAILURE_INVALID_DATASET;
        }
    }
    if ( strncmp ( level, IMAGE_LEVEL, sizeof(IMAGE_LEVEL) ) == 0 ||
         strncmp ( level, FRAME_LEVEL, sizeof(FRAME_LEVEL) ) == 0 )
    {
        mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_SOP_INSTANCE_UID,
                                            sizeof(SOPUID), SOPUID );
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            PrintErrorMessage ( S_prefix, "Series Instance UID, MC_Get_Value_To_String",
                                mcStatus, NULL );
            return C_GET_FAILURE_INVALID_DATASET;
        }
    }

    printf("Remote AE Title for get: %s\n", A_myConfig->RemoteApplicationTitle);

    /*
     * Reuse the association
     */
    associationID = A_associationID;

    /*
     * Loop through all data items
     */

    LLRewind( &StudyList);
    nodecount = LLNodes( &StudyList);

    for ( i = 0; i < nodecount; i++ )
    {
        LLPopNode( &StudyList, &study);

        if ( strncmp ( level, PATIENT_LEVEL, sizeof(PATIENT_LEVEL) ) == 0 )
        {
            if ( strcmp ( patientID, study.pat_id ) != 0 )
                continue;
        }

        if ( strncmp ( level, STUDY_LEVEL, sizeof(STUDY_LEVEL) ) == 0 )
        {
            if ( strcmp ( studyUID, study.stu_inst ) != 0 )
                continue;
        }

        LLRewind(&study.SeriesList);
        for ( j = 0; j < LLNodes(&study.SeriesList); j++ )
        {
            LLPopNode( &study.SeriesList, &series);

            if ( strncmp ( level, SERIES_LEVEL, sizeof(SERIES_LEVEL) ) == 0 )
            {
                if ( strcmp ( seriesUID, series.ser_uid) != 0 )
                    continue;
            }

            LLRewind(&series.InstanceList);
            for ( k = 0; k < LLNodes(&series.InstanceList); k++ )
            {
                LLPopNode(&series.InstanceList, &instance);

                if ( strncmp ( level, IMAGE_LEVEL, sizeof(IMAGE_LEVEL) ) == 0 ||
                     strncmp ( level, FRAME_LEVEL, sizeof(FRAME_LEVEL) ) == 0 )
                {
                    if ( strcmp ( SOPUID, instance.sop_uid) != 0 )
                        continue;
                }

                strcpy(filename, A_myConfig->StorageFolder);
                strcat(filename, SLASH);
                strcat(filename, instance.sop_uid);
                strcat(filename, ".dcm");

                /*
                 * If this is a match, send it
                 */
                mcStatus = MC_Create_Empty_File(&fileID, filename);
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    return C_GET_FAILURE_UNABLE_TO_PROCESS;
                }

                mcStatus = MC_Open_File(A_applicationID, fileID, &callBackInfo, MediaToFileObj);
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    return C_GET_FAILURE_UNABLE_TO_PROCESS;
                }

                if(!strcmp(serviceName, Services.COMPOSITE_INST_RET_NO_BULK_GET))
                {
                    /*
                     * Remove Bulk attributes before sending the message
                     */
                    mcStatus = RemoveBulks(fileID);
                    if ( mcStatus != MC_NORMAL_COMPLETION )
                    {
                        PrintErrorMessage(S_prefix, "Failed to remove Bulk attributes",
                                          mcStatus,NULL);
                        MC_Free_Message(&fileID);
                        MC_Abort_Association ( &associationID );
                        return C_GET_FAILURE_UNABLE_TO_PROCESS;
                    }
                }
                else if(!strcmp(serviceName, Services.COMPOSITE_INSTANCE_ROOT_RET_GET))
                {
                    /*
                     * Process Composite Instance Root Retrieve Service
                     * COMPOSITE_INSTANCE_ROOT_RET_MOVE is similar and can use the same
                     * ProcessCompInstRootRetRQ() to construct the response
                     * The only difference is MOVE will use a separate association to send.
                     */
                    if ( strncmp ( level, FRAME_LEVEL, sizeof(FRAME_LEVEL) ) == 0 )
                    {
                        /* handle frame level retrieve */
                        mcStatus = ProcessCompInstRootRetRQ( fileID, A_messageID );
                        if ( mcStatus != MC_NORMAL_COMPLETION )
                        {
                            PrintErrorMessage(S_prefix, "Failed to process composite instance root retrieve service",
                                              mcStatus,NULL);
                            MC_Free_Message(&fileID);
                            MC_Abort_Association ( &associationID );
                            return C_GET_FAILURE_UNABLE_TO_PROCESS;
                        }
                    }
                }

                mcStatus = MC_File_To_Message(fileID);
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage(S_prefix, "MC_File_To_Message",
                                      mcStatus,NULL);
                    MC_Free_File(&fileID);
                    return C_GET_FAILURE_UNABLE_TO_PROCESS;
                }

                /*
                 * Get the SOP class UID and set the service
                 */
                mcStatus = MC_Get_Value_To_String( fileID,
                                                 MC_ATT_SOP_CLASS_UID,
                                                 sizeof(SOPClassUID),
                                                 SOPClassUID);
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage(S_prefix, "SOP,MC_Get_Value_To_String failed",
                                      mcStatus,NULL);
                    MC_Free_Message(&fileID);
                    MC_Abort_Association ( &associationID );
                    return C_GET_FAILURE_UNABLE_TO_PROCESS;
                }

                mcStatus = MC_Get_MergeCOM_Service(SOPClassUID, serviceName2, sizeof(serviceName2));
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage(S_prefix, "MC_Get_MergeCOM_Service",mcStatus,NULL);
                    MC_Free_Message(&fileID);
                    MC_Abort_Association ( &associationID );
                    return C_GET_FAILURE_UNABLE_TO_PROCESS;
                }

                mcStatus = MC_Set_Service_Command(fileID, serviceName2, C_STORE_RQ);
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage(S_prefix,"MC_Set_Service_Command",mcStatus,NULL);
                    MC_Free_Message(&fileID);
                    MC_Abort_Association ( &associationID );
                    return C_GET_FAILURE_UNABLE_TO_PROCESS;
                }

                /*
                 * Get affected SOP Instance UID
                 */
                mcStatus = MC_Get_Value_To_String(fileID,
                                                MC_ATT_SOP_INSTANCE_UID,
                                                sizeof(affectedSOPinstance),
                                                affectedSOPinstance);
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage ( S_prefix, "affected SOP,MC_Get_Value_To_String",
                                        mcStatus, "Affected SOP Instance UID" );
                    MC_Free_Message(&fileID);
                    MC_Abort_Association ( &associationID );
                    return C_GET_FAILURE_UNABLE_TO_PROCESS;
                }

                /*
                 * Set the affected SOP Instance UID
                 */
                mcStatus = MC_Set_Value_From_String(fileID,
                                                  MC_ATT_AFFECTED_SOP_INSTANCE_UID,
                                                  affectedSOPinstance);
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage( S_prefix, "MC_Set_Value_From_String",
                                       mcStatus, "Affected SOP Instance UID" );
                    MC_Free_Message(&fileID);
                    MC_Abort_Association ( &associationID );
                    return C_GET_FAILURE_UNABLE_TO_PROCESS;
                }

                /*
                 * Send it off
                 */
                printf ( "%s: --- Sending a C-STORE request.\n", S_prefix ); 
                mcStatus = MC_Send_Request_Message ( associationID,
                                                   fileID );
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage ( S_prefix, "MC_Send_Request_Message", mcStatus,
                                        NULL );
                    MC_Free_Message(&fileID);
                    MC_Abort_Association ( &associationID );
                    return C_GET_FAILURE_REFUSED_CANT_PERFORM;
                }

                /*
                 * Wait for a reply
                 */
                mcStatus = MC_Read_Message ( associationID,
                                           atoi ( A_myConfig->TimeOut ),
                                           &responseMessageID,
                                           &serviceName,
                                           &command );
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage ( S_prefix, "MC_Read_Message", mcStatus, NULL );
                    MC_Free_Message(&fileID);
                    MC_Abort_Association ( &associationID );
                    return C_GET_FAILURE_REFUSED_CANT_PERFORM;
                }

                mcStatus = MC_Get_Value_To_UInt ( responseMessageID,
                                                MC_ATT_STATUS,
                                                &response );
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage ( S_prefix, "MC_Get_Value_To_UInt for C-STORE mcStatus",
                                        mcStatus, NULL );
                    MC_Free_Message(&fileID);
                    MC_Free_Message ( &responseMessageID );
                    MC_Abort_Association ( &associationID );
                    return C_GET_FAILURE_REFUSED_CANT_PERFORM;
                }

                /*
                 * Check for a successful C-STORE
                 */
                if ( response != C_STORE_SUCCESS )
                {
                    PrintErrorMessage ( S_prefix, "Received message error",
                                        -1, "C_STORE_SUCCESS not obtained." );
                    MC_Free_Message(&fileID);
                    MC_Free_Message ( &responseMessageID );
                    MC_Abort_Association ( &associationID );
                    return C_GET_FAILURE_REFUSED_CANT_PERFORM;
                }

                printf ( "%s: --- Received a C-STORE response.\n", S_prefix ); 

                mcStatus = MC_Free_Message ( &fileID );
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage ( S_prefix, "MC_Free_Message for C-STORE-RQ",
                                        mcStatus, NULL );
                    MC_Free_Message ( &responseMessageID );
                    MC_Abort_Association ( &associationID );
                    return C_GET_FAILURE_REFUSED_CANT_PERFORM;
                }

                mcStatus = MC_Free_Message ( &responseMessageID );
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage ( S_prefix, "MC_Free_Message for C-STORE-RSP",
                                        mcStatus, NULL );
                    MC_Free_Message ( &responseMessageID );
                    MC_Abort_Association ( &associationID );
                    return C_GET_FAILURE_REFUSED_CANT_PERFORM;
                }
            }
        } /* for */
    }

    return C_GET_SUCCESS_NO_FAILURES_OR_WARNINGS;
} /* ProcessCGETRQ */



/****************************************************************************
 *
 *  Function    :   MediaToFileObj
 *
 *  Parameters  :   A_fileName   - Filename to open for reading
 *                  A_userInfo   - Pointer to an object used to preserve
 *                                 data between calls to this function.
 *                  A_dataSize   - Number of bytes read
 *                  A_dataBuffer - Pointer to buffer of data read
 *                  A_isFirst    - Set to non-zero value on first call
 *                  A_isLast     - Set to 1 when file has been completely
 *                                 read
 *
 *  Returns     :   MC_NORMAL_COMPLETION on success
 *                  any other MC_STATUS value on failure.
 *
 *  Description :   Callback function used by MC_Open_File to read a file
 *                  in the DICOM Part 10 (media) format.
 *
 ****************************************************************************/
static MC_STATUS NOEXP_FUNC MediaToFileObj( char*     A_filename,
                                            void*     A_userInfo,
                                            int*      A_dataSize,
                                            void**    A_dataBuffer,
                                            int       A_isFirst,
                                            int*      A_isLast)
{

    CBinfo*         callbackInfo = (CBinfo*)A_userInfo;
    size_t          bytes_read;

    if ( !A_userInfo )
        return MC_CANNOT_COMPLY;

    if ( A_isFirst )
    {
        callbackInfo->bytesRead = 0;
        callbackInfo->stream = fopen(A_filename, BINARY_READ);
    }

    if ( !callbackInfo->stream )
        return MC_CANNOT_COMPLY;

    bytes_read = fread(callbackInfo->buffer, 1, sizeof(callbackInfo->buffer),
                       callbackInfo->stream);
    if ( ferror(callbackInfo->stream) )
        return MC_CANNOT_COMPLY;

    if ( feof(callbackInfo->stream) )
    {
        *A_isLast = 1;
        fclose(callbackInfo->stream);
        callbackInfo->stream = NULL;
    } else
        *A_isLast = 0;

    *A_dataBuffer = callbackInfo->buffer;
    *A_dataSize = (int)bytes_read;
    callbackInfo->bytesRead += (int)bytes_read;
    return MC_NORMAL_COMPLETION;

} /* MediaToFileObj() */


/*************************************************************
    Function:         SendCFINDComplete

    Returns:          QR_STATUS

    Description:      This function sends an empty message indicating
                      the C-FIND is complete.
*************************************************************/
static QR_STATUS SendCFINDComplete ( int A_associationID, AppConfig *A_myConfig,
                                     RESP_STATUS A_retStatus, char* serviceName)
{
    MC_STATUS             mcStatus;
    static char           S_prefix[] = "SendCFINDComplete";
    int                   messageID;
    int                   ackSent = FALSE;

    /*
     * Open a message for the C-FIND-RSP
     */
    mcStatus = MC_Open_Message ( &messageID,
                               serviceName,
                               C_FIND_RSP );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "MC_Open_Message",
                            mcStatus, NULL );
        return( QR_FAILURE );
    }

    /*
     * Send back an empty response message signaling the query is finished
     */
    if ( A_retStatus == C_FIND_PENDING ||
         A_retStatus == C_FIND_PENDING_NO_OPTIONAL_KEY_SUPPORT )
    {
        A_retStatus = C_FIND_SUCCESS;
    }

    if ( ackSent != TRUE )
    {
        mcStatus = MC_Send_Response_Message ( A_associationID,
                                            A_retStatus,
                                            messageID );
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            MC_Free_Message ( &messageID );
            PrintErrorMessage ( S_prefix, "MC_Send_Response_Message",
                                mcStatus, NULL );
            return( QR_FAILURE );
        }
    }

    /*
     * Clean Up
     */
    mcStatus = MC_Free_Message ( &messageID );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "MC_Free_Message",
                            mcStatus, "Could not free message." );
        return( QR_FAILURE );
    }

    return( QR_SUCCESS );
}


/****************************************************************************
**
** NAME
**    CheckReturnTag -- Check if a tag should be sent in return message
**
** ARGUMENTS
**    A_filename   - Filename to write to
**    A_userInfo   - Information to store between calls to this
**                   function
**    A_dataSize   - Size of A_dataBuffer
**    A_dataBuffer - Buffer containing data to write
**    A_isFirst    - set to true on first call
**    A_isLast     - Is set to true on the final call
**
** RETURNS
**    QR_SUCCESS or QR_FAILURE
**
** DESCRIPTION
**    This routine checks if a tag is in a C-FIND-RQ message and sets it
**    in a C-FIND-RSP if applicable.
**
*****************************************************************************/
static QR_STATUS CheckReturnTag(int A_rqMsgID, int A_rspMsgID, unsigned long A_tag,
                                char* A_setValue)
{
    static char     S_prefix[] = "CheckReturnTag";
    MC_STATUS mcStatus;
    char value[1024];

    mcStatus = MC_Get_Value_To_String ( A_rqMsgID, A_tag, sizeof( value ), value);
    if ( mcStatus == MC_NULL_VALUE || mcStatus == MC_NORMAL_COMPLETION)
    {
        mcStatus = MC_Set_Value_From_String ( A_rspMsgID,
                                            A_tag, A_setValue );
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            PrintErrorMessage ( S_prefix, "MC_Set_Value_From_String", mcStatus, NULL );
            if ( (mcStatus != MC_INVALID_CHARS_IN_VALUE) && (mcStatus != MC_INVALID_VALUE_FOR_VR) )
            {
                return( QR_FAILURE );
            }
        }
    }
    return QR_SUCCESS;
}


/*************************************************************
    Function:       SendCFINDReply

    Parameter:      char* serviceName   To determine what data to send
                    int A_associationID
                    AppConfig *A_myConfig
                    RESP_STATUS A_retStatus
                    int A_messageID
                    StudyNode* study
                    SeriesNode* series
                    InstanceNode* instance

    Returns:        QR_STATUS

    Description:    This function sends the response to the CFIND request.
                    It uses the data in the structs, the service name, and query
                    level to construct the appropriate message.
*************************************************************/
static QR_STATUS SendCFINDReply ( char* serviceName, int A_associationID, AppConfig *A_myConfig,
                                  RESP_STATUS A_retStatus, int A_messageID,
                                  StudyNode* study, SeriesNode* series, InstanceNode* instance,
                                  int* ackSent)
{
    MC_STATUS       mcStatus;
    int             messageID;
    int             ackMsg;
    int             readMessageID;
    char            level[CS_LEN];
    MC_COMMAND      command = 0;
    static char     S_prefix[] = "SendCFINDReply";

    /*
     * Get the query level from request message
     */
    mcStatus = MC_Get_Value_To_String ( A_messageID, MC_ATT_QUERY_RETRIEVE_LEVEL, sizeof ( level ), level );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "QUERY_RETRIEVE_LEVEL, MC_Get_Value_To_String", mcStatus, NULL );
        return( QR_FAILURE );
    }

    /*
     * Open a message for the C-FIND-RSP
     */
    mcStatus = MC_Open_Message ( &messageID, serviceName, C_FIND_RSP );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "MC_Open_Message", mcStatus, NULL );
        return( QR_FAILURE );
    }

    /*
     * Build the contents of the message
     */
    if ( A_retStatus == C_FIND_PENDING || A_retStatus == C_FIND_PENDING_NO_OPTIONAL_KEY_SUPPORT )
    {
        printf ( "%s: Match Found: Patient Name = %s\n", S_prefix, study->pat_name );

        /*
         * Send back necessary DICOM fields
         */

        /*
         * Send back the Retrieve AE Title
         */
        mcStatus = MC_Set_Value_From_String ( messageID, MC_ATT_RETRIEVE_AE_TITLE, A_myConfig->ApplicationTitle );
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            PrintErrorMessage ( S_prefix, "RETRIEVE_AE_TITLE, MC_Set_Value_From_String", mcStatus, NULL );
            if ( (mcStatus != MC_INVALID_CHARS_IN_VALUE) && (mcStatus != MC_INVALID_VALUE_FOR_VR) )
            {
                return( QR_FAILURE );
            }
        }

        /*
         * Send back the query level
         */
        mcStatus = MC_Set_Value_From_String ( messageID, MC_ATT_QUERY_RETRIEVE_LEVEL, level );
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            PrintErrorMessage ( S_prefix, "QUERY_RETRIEVE_LEVEL, MC_Set_Value_From_String", mcStatus, NULL );
            if ( (mcStatus != MC_INVALID_CHARS_IN_VALUE) && (mcStatus != MC_INVALID_VALUE_FOR_VR) )
            {
                return( QR_FAILURE );
            }
        }

        /*
         * Send back the patient ID.
         */
        mcStatus = MC_Set_Value_From_String ( messageID, MC_ATT_PATIENT_ID, study->pat_id );
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            PrintErrorMessage ( S_prefix, "MC_Set_Value_From_String", mcStatus, NULL );
            if ( (mcStatus != MC_INVALID_CHARS_IN_VALUE) && (mcStatus != MC_INVALID_VALUE_FOR_VR) )
            {
                MC_Free_Message ( &messageID );
                return( QR_FAILURE );
            }
        }

        /*
         * Send back the patient name?
         */
        if (QR_SUCCESS != CheckReturnTag(A_messageID, messageID, MC_ATT_PATIENTS_NAME,
                                         study->pat_name))
        {
            MC_Free_Message ( &messageID );
            return( QR_FAILURE );
        }

        /*
         * Send back the patient birthday?
         */
        if (QR_SUCCESS != CheckReturnTag(A_messageID, messageID, MC_ATT_PATIENTS_BIRTH_DATE,
                                         study->pat_bday))
        {
            MC_Free_Message ( &messageID );
            return( QR_FAILURE );
        }

        /*
         * Send back the patient sex?
         */
        if (QR_SUCCESS != CheckReturnTag(A_messageID, messageID, MC_ATT_PATIENTS_SEX,
                                         study->pat_sex))
        {
            MC_Free_Message ( &messageID );
            return( QR_FAILURE );
        }

        /*
         * If study level query, check series attributes
         */
        if ( strncmp ( level, STUDY_LEVEL, sizeof(STUDY_LEVEL) ) == 0 )
        {
            /*
             * Send back the study instance?
             */
            if (QR_SUCCESS != CheckReturnTag(A_messageID, messageID, MC_ATT_STUDY_INSTANCE_UID,
                                             study->stu_inst))
            {
                MC_Free_Message ( &messageID );
                return( QR_FAILURE );
            }

            /*
             * Send back the study date?
             */
            if (QR_SUCCESS != CheckReturnTag(A_messageID, messageID, MC_ATT_STUDY_DATE,
                                             study->stu_date))
            {
                MC_Free_Message ( &messageID );
                return( QR_FAILURE );
            }

            /*
             * Send back the study time?
             */
            if (QR_SUCCESS != CheckReturnTag(A_messageID, messageID, MC_ATT_STUDY_TIME,
                                             study->stu_time))
            {
                MC_Free_Message ( &messageID );
                return( QR_FAILURE );
            }

            /*
             * Send back the study accession number
             */
            if (QR_SUCCESS != CheckReturnTag(A_messageID, messageID, MC_ATT_ACCESSION_NUMBER,
                                             study->stu_anum))
            {
                MC_Free_Message ( &messageID );
                return( QR_FAILURE );
            }

            /*
             * Send back the study id?
             */
            if (QR_SUCCESS != CheckReturnTag(A_messageID, messageID, MC_ATT_STUDY_ID,
                                             study->stu_id))
            {
                MC_Free_Message ( &messageID );
                return( QR_FAILURE );
            }

            /*
             * Send back the study description?
             */
            if (QR_SUCCESS != CheckReturnTag(A_messageID, messageID, MC_ATT_STUDY_DESCRIPTION,
                                             study->stu_desc))
            {
                MC_Free_Message ( &messageID );
                return( QR_FAILURE );
            }
        }

        /*
         * If series level query, check series attributes
         */
        if ( strncmp ( level, SERIES_LEVEL, sizeof(SERIES_LEVEL) ) == 0 )
        {
            if (QR_SUCCESS != CheckReturnTag(A_messageID, messageID, MC_ATT_SERIES_INSTANCE_UID,
                                             series->ser_uid))
            {
                MC_Free_Message ( &messageID );
                return( QR_FAILURE );
            }

            if (QR_SUCCESS != CheckReturnTag(A_messageID, messageID, MC_ATT_MODALITY,
                                             series->ser_mode))
            {
                MC_Free_Message ( &messageID );
                return( QR_FAILURE );
            }

            if (QR_SUCCESS != CheckReturnTag(A_messageID, messageID, MC_ATT_SERIES_NUMBER,
                                             series->ser_num))
            {
                MC_Free_Message ( &messageID );
                return( QR_FAILURE );
            }
        }

        /*
         * If image level query, check series attributes
         */
        if ( strncmp ( level, IMAGE_LEVEL, sizeof(IMAGE_LEVEL) ) == 0 )
        {
            if (QR_SUCCESS != CheckReturnTag(A_messageID, messageID, MC_ATT_SOP_INSTANCE_UID,
                                             instance->sop_uid))
            {
                MC_Free_Message ( &messageID );
                return( QR_FAILURE );
            }

            if (QR_SUCCESS != CheckReturnTag(A_messageID, messageID, MC_ATT_IMAGE_NUMBER,
                                             instance->img_num))
            {
                MC_Free_Message ( &messageID );
                return( QR_FAILURE );
            }

            if (QR_SUCCESS != CheckReturnTag(A_messageID, messageID, MC_ATT_SOP_CLASS_UID,
                                             instance->sop_classuid))
            {
                MC_Free_Message ( &messageID );
                return( QR_FAILURE );
            }
        }

        /*
         * Send the responce back to the user
         */
        mcStatus = MC_Send_Response_Message ( A_associationID,
                                            A_retStatus,
                                            messageID );
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            MC_Free_Message ( &messageID );
            PrintErrorMessage ( S_prefix, "MC_Send_Response_Message",
                                mcStatus, NULL );
            return( QR_FAILURE );
        }

        /*
         * Clear out the message for reuse
         */
        mcStatus = MC_Empty_Message ( messageID );
        if ( mcStatus != MC_NORMAL_COMPLETION )
        {
            MC_Free_Message ( &messageID );
            PrintErrorMessage ( S_prefix, "MC_Empty_Message", mcStatus,
                                NULL );
            return( QR_FAILURE );
        }

        /*
        ** After sending the response message to the SCU, we poll
        ** the toolkit to see if the SCU has attempted to send us a
        ** CANCEL message.
        */
        mcStatus = MC_Read_Message( A_associationID, 0, &readMessageID,
                                  &serviceName, &command );
        if ( ( mcStatus != MC_NORMAL_COMPLETION ) &&
             ( mcStatus != MC_TIMEOUT ) )
        {
            MC_Free_Message( &messageID );
            LogError( ERROR_LVL_1, "SendCFINDReply", __LINE__, mcStatus,
                      "Failed to check for a cancel message from the "
                      "SCU.\n" );
            return( QR_FAILURE );
        }

        if( mcStatus == MC_NORMAL_COMPLETION )
        {
            if( command == C_CANCEL_RQ )
        {
                printf( "--- Received a C_CANCEL_REQUEST\n" );
                mcStatus = MC_Open_Message( &ackMsg,"PATIENT_STUDY_ONLY_QR_FIND", C_FIND_RSP );
                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    MC_Free_Message ( &messageID );
                    MC_Free_Message ( &readMessageID );
                    LogError( ERROR_LVL_1, "SendCFINDReply", __LINE__, mcStatus,"Could not open the reply message.\n" );
                    return( QR_FAILURE );
                }

                /*
                ** And then, send the message to the SCU...
                */
                printf( "--- Sending acknowledgement of ""C_CANCEL_REQUEST message...\n" );
                mcStatus = MC_Send_Response_Message ( A_associationID,C_FIND_CANCEL_REQUEST_RECEIVED,
                                                    ackMsg );

                MC_Free_Message ( &ackMsg );

                if ( mcStatus != MC_NORMAL_COMPLETION )
                {
                    MC_Free_Message ( &readMessageID );
                    MC_Free_Message ( &messageID );
                    LogError( ERROR_LVL_1, "SendCFINDReply", __LINE__, mcStatus,"Failed to send the response message "
                              "to the SCU.\n" );
                    return( QR_FAILURE );
                }

                /*
                ** Once we are successful at sending the
                ** acknowledgement, we use this flag to make sure
                ** that we don't send a C_FIND with a SUCCESS later on.
                ** The above message should be the last sent when a
                ** CANCEL happens.
                */
                *ackSent = TRUE;
            }
            else
            {
                /* received an unexpected message, ignore it */
                printf( "--- Received an unexpected message while doing a query\n" );
            }

            MC_Free_Message ( &readMessageID );
        }
    }

    /*
     * Clean Up
     */
    mcStatus = MC_Free_Message ( &messageID );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "MC_Free_Message",
                            mcStatus, "Could not free message." );
        return( QR_FAILURE );
    }

    return( QR_SUCCESS );

} /* SendCFINDReply */


/*****************************************************************************
**
** NAME
**    GetOptions - Parse the command line arguements and set the config parms
**
** ARGUMENTS
**    A_argc        int            Number of parameters to the program
**    A_argv        char **        The list of arguements given to the program
**    A_myConfig    AppConfig *    Structure of Configuration Parameters
**
** DESCRIPTION
**    This routine goes throught the command line options given on startup
**    and takes the correct options and used them to configure the way the
**    program will operate.
**
** RETURNS
**    Returns any valid options given on the command line, but no status.
**
** SEE ALSO
**
*****************************************************************************/
static void GetOptions ( int A_argc, char **A_argv, AppConfig *A_myConfig )
{
    int          ai, ci;
    int          error = FALSE;

    for ( ai = 1; ai < A_argc && strcmp ( A_argv[ai], "--" ) != 0; ai ++ )
    {
        if ( A_argv[ai][0] == '-' )
        {
            for ( ci = 1; ci < (int)strlen ( A_argv[ai] ); ci++ )
            {
                switch ( A_argv[ai][ci] )
                {
                    case 'a':        /* Application Title */
                        if ( A_argv[ai][ci+1] != '\0' )
                        {
                            error = TRUE;
                        } else if ( (ai + 1) == A_argc )
                        {
                            error = TRUE;
                        } else
                        {
                            strcpy ( A_myConfig->ApplicationTitle, &(A_argv[ai+1][0]) );
                            ai++;
                            ci = (int)strlen ( A_argv[ai] );
                        }
                        break;
                    case 'f':
                        if ( A_argv[ai][ci+1] != '\0' )
                        {
                            error = TRUE;
                        } else if ( (ai + 1) == A_argc )
                        {
                            error = TRUE;
                        } else
                        {
                            strcpy ( A_myConfig->StorageFolder, &(A_argv[ai+1][0]) );
                            ai++;
                            ci = (int)strlen ( A_argv[ai] );
                        }
                        break;
                    case 'h':        /* Help */
                        printf ( "\n" );
                        printf ( "Query/Retrieve Service Class Provider\n" );
                        printf ( "\n" );
                        printf ( "Usage: %s [options]\n", A_argv[0] );
                        printf ( "\n" );
                        printf ( "Options:\n" );
                        printf ( "   -a atitle        Application Title\n" );
                        printf ( "   -h               Print this help page\n" );
                        printf ( "   -o timeout       Time out value\n" );
                        printf ( "   -s slist         Service List for this application\n" );
                        printf ( "   -p port          Listen Port Number (optional)\n" );
                        printf ( "   -f folder        Storage Folder for storing incoming files\n" );
                        printf ( "\n" );
                        exit ( EXIT_SUCCESS );
                        break;

                    case 'o':        /* time out */
                        if ( A_argv[ai][ci+1] != '\0' )
                        {
                            error = TRUE;
                        } else if ( (ai + 1) == A_argc )
                        {
                            error = TRUE;
                        } else
                        {
                            strcpy ( A_myConfig->TimeOut, &(A_argv[ai+1][0]) );
                            ai++;
                            ci = (int)strlen ( A_argv[ai] );
                        }
                        break;

                    case 's':        /* Service List */
                        if ( A_argv[ai][ci+1] != '\0' )
                        {
                            error = TRUE;
                        } else if ( (ai + 1) == A_argc )
                        {
                            error = TRUE;
                        } else
                        {
                            strcpy ( A_myConfig->ServiceList, &(A_argv[ai+1][0]) );
                            ai++;
                            ci = (int)strlen ( A_argv[ai] );
                        }
                        break;
                    case 'p':        /* Listen Port */
                        if ( A_argv[ai][ci+1] != '\0' )
                        {
                            error = TRUE;
                        } else if ( (ai + 1) == A_argc )
                        {
                            error = TRUE;
                        } else
                        {
                            A_myConfig->ListenPort = atoi( &(A_argv[ai+1][0]) );
                            ai++;
                            ci = (int)strlen ( A_argv[ai] );
                        }
                        break;
                    default:
                        break;

                } /* switch argv */

                if ( error == TRUE )
                {
                    printf ( "Usage: %s [options]\n", A_argv[0] );
                    printf ( "       %s -h\n", A_argv[0] );
                    return;
                }

            } /* for ci */

        } /* if argv */

    } /* for ai */

} /* GetOptions */


/*****************************************************************************
**
** NAME
**    SetProgramDefaults - Sets global application default parameters
**
** ARGUEMENTS
**    A_myConfig    AppConfig *   Structure of configuration parameters
**
** DESCRIPTION
**    This routine gives values to the configuration parameters to be
**    used by the for other setup requirements.
**
** RETURNS
**    Returns with the parameters set, but no other status.
**
** SEE ALSO
**
*****************************************************************************/
static void SetProgramDefaults ( AppConfig *A_myConfig )
{

    strcpy ( A_myConfig->TimeOut, "3000" );
    strcpy ( A_myConfig->ApplicationTitle, "MERGE_QR_GET_SCP" );
    strcpy ( A_myConfig->RemoteApplicationTitle, "" );
    strcpy ( A_myConfig->ServiceList, "GET_SCP_Service_List" );
    A_myConfig->SaveSyntax = EXPLICIT_LITTLE_ENDIAN;
    strcpy ( A_myConfig->StorageFolder, "./default" );
    A_myConfig->ListenPort = 0;
    return;

} /* SetProgramDefaults */


static void trim (char *Astring)
{
    char  *p;
    int  len;

    len = (int)strlen(Astring);
    if ( len == 0 )
        return;

    p = Astring + len - 1;
    while ( p >= Astring && *p == ' ' )
        *p-- = '\0';
}

/*****************************************************************************
 *
 * NAME
 *    RemoveBulks - Removes Bulk attributes from the message
 *
 * ARGUMENTS
 *    A_messageid    int              Id of message the bulks are removed from
 *
 * DESCRIPTION
 *    This function removes the bulk attributes from the message. 
 *      The attributes are removed using MC_Delete_Attribute(). 
 *
 * RETURNS
 *    MC_NORMAL_COMPLETION on success, any other MC_STATUS
 *    value on failure.
 *
 * SEE ALSO
 *    MC_Delete_Attribute() 
 *
 ****************************************************************************/
static MC_STATUS RemoveBulks(int A_messageID)
{
    static char   S_prefix[]="RemoveBulks";
    unsigned long tag;
    int i;
    int count;
    MC_STATUS       mcStatus;

    for (i = 0; i < 3; i++)
    {
        tag = BulkTags[i];

        mcStatus = MC_Get_Value_Count(A_messageID,tag,&count);
        if(mcStatus == MC_NORMAL_COMPLETION && count > 0)
        {
            mcStatus = MC_Delete_Attribute(A_messageID, tag);
            if ( mcStatus != MC_NORMAL_COMPLETION )
            {
                PrintErrorMessage(S_prefix, "MC_Delete_Attribute failed",mcStatus,NULL);
                printf("***          Tag: %lX\n", tag);
                return mcStatus;
            }
        }
    }
    return MC_NORMAL_COMPLETION;
}

typedef struct
{
    char filename[128];
    FILE *stream;
    int byteProcessed;
    char buffer[32768];
    int *frameList;
    int numFrames;
    int curFileNum;
} FrameUserInfo;

/****************************************************************************
 *
 *  Function    :   GetFrameToFunction
 *
 *  Parameters  :   CBmsgID   - message id
 *                  ATag      - the tag
 *                  CBuserInfo  - the user info pointer
 *                  CBdataLen   - length of data
 *                  CBdataBuffer - data buffer
 *                  CBfirstCall  - Set to 1 when call first time
 *                  CBisLast     - Set to 1 when call last time
 *
 *  Returns     :   MC_NORMAL_COMPLETION on success
 *                  any other MC_STATUS value on failure.
 *
 *  Description :   Callback function used by MC_Get_Frame_To_Function to read a
 *                  frame from the message id.
 *
 ****************************************************************************/
static MC_STATUS NOEXP_FUNC GetFrameToFunction(
                        int            CBmsgID,
                        unsigned long  ATag,
                        void*          CBuserInfo,
                        int            CBdataLen,
                        void*          CBdataBuffer,
                        int            CBfirstCall,
                        int            CBisLast)
{
    FrameUserInfo *cbInfo = (FrameUserInfo *)CBuserInfo;
    size_t count;
    int retStatus;

    if ( CBfirstCall )
    {
        cbInfo->stream = fopen(cbInfo->filename, BINARY_WRITE);
        if(cbInfo->stream==NULL){
            printf("\nERROR: Can not open %s file. (errno=%d) \n",cbInfo->filename,errno);
            return MC_CANNOT_COMPLY;
        }
    }

    if ( !cbInfo->stream )
        return MC_CANNOT_COMPLY;

    count = fwrite(CBdataBuffer, 1, CBdataLen, cbInfo->stream);
    if ( count != (size_t)CBdataLen )
    {
        printf("fwrite error");
        return MC_CANNOT_COMPLY;
    }

    cbInfo->byteProcessed += (int)count;

    retStatus = fflush(cbInfo->stream);
    if ( retStatus != 0 )
    {
        printf("\tfflush error\n");
        fclose(cbInfo->stream);
        cbInfo->stream = NULL;
        return MC_CANNOT_COMPLY;
    }
    if ( CBisLast )
    {
        retStatus = fclose(cbInfo->stream);
        if ( retStatus != 0 )
        {
            printf("\tfclose error\n");
            cbInfo->stream = NULL;
            return MC_CANNOT_COMPLY;
        }
        cbInfo->stream = NULL;
    }

    return MC_NORMAL_COMPLETION;
}

/****************************************************************************
 *
 *  Function    :   SetCompFrameFromFunction
 *
 *  Parameters  :   CBmsgID   - message id
 *                  ATag      - the tag
 *                  CBfirstCall  - Set to 1 when call first time
 *                  CBuserInfo  - the user info pointer
 *                  CBdataLen   - length of data supplied by this callback
 *                  CBdataBuffer - data buffer supplied by this callback
 *                  CBisLast     - Set to 1 by this callback when finish
 *
 *  Returns     :   MC_NORMAL_COMPLETION on success
 *                  any other MC_STATUS value on failure.
 *
 *  Description :   Callback function used by MC_Set_Encapsulated_Value_From_Function to set a
 *                  frame to the message id.
 *
 ****************************************************************************/
static MC_STATUS NOEXP_FUNC SetCompFrameFromFunction( int  CBmsgID,
                                unsigned long   ATag,
                                int             CBfirstCall,
                                void*           CBuserInfo,
                                int*            CBdataLen,
                                void**          CBdataBuffer,
                                int*            CBisLast)
{
    FrameUserInfo*  cbInfo = (FrameUserInfo *)CBuserInfo;
    size_t          bytes_read;

    if ( !CBuserInfo )
        return MC_CANNOT_COMPLY;

    if ( CBfirstCall )
    {
        cbInfo->byteProcessed = 0;
        cbInfo->stream = fopen(cbInfo->filename, BINARY_READ);
    }

    if ( !cbInfo->stream )
        return MC_CANNOT_COMPLY;

    bytes_read = fread(cbInfo->buffer, 1, sizeof(cbInfo->buffer),
                       cbInfo->stream);
    if ( ferror(cbInfo->stream) )
        return MC_CANNOT_COMPLY;

    if ( feof(cbInfo->stream) )
    {
        *CBisLast = 1;
        fclose(cbInfo->stream);
        cbInfo->stream = NULL;
    } else
        *CBisLast = 0;

    *CBdataBuffer = cbInfo->buffer;
    *CBdataLen = (int)bytes_read;
    cbInfo->byteProcessed += (int)bytes_read;

    return MC_NORMAL_COMPLETION;
}

/****************************************************************************
 *
 *  Function    :   SetUncompFrameFromFunction
 *
 *  Parameters  :   CBmsgID   - message id
 *                  ATag      - the tag
 *                  CBfirstCall  - Set to 1 when call first time
 *                  CBuserInfo  - the user info pointer
 *                  CBdataLen   - length of data supplied by this callback
 *                  CBdataBuffer - data buffer supplied by this callback
 *                  CBisLast     - Set to 1 by this callback when finish
 *
 *  Returns     :   MC_NORMAL_COMPLETION on success
 *                  any other MC_STATUS value on failure.
 *
 *  Description :   Callback function used by MC_Set_Value_From_Function to set a
 *                  frame(s) to the message id.
 *
 ****************************************************************************/
static MC_STATUS NOEXP_FUNC SetUncompFrameFromFunction( int  CBmsgID,
                                unsigned long   ATag,
                                int             CBfirstCall,
                                void*           CBuserInfo,
                                int*            CBdataLen,
                                void**          CBdataBuffer,
                                int*            CBisLast)
{
    FrameUserInfo*  cbInfo = (FrameUserInfo *)CBuserInfo;
    size_t          bytes_read;
    char            curFileName[128];

    if ( !CBuserInfo )
        return MC_CANNOT_COMPLY;

    if ( CBfirstCall )
    {
        cbInfo->byteProcessed = 0;
        cbInfo->curFileNum = 0;
        if (cbInfo->frameList == NULL || cbInfo->numFrames < 1) return MC_CANNOT_COMPLY;
        sprintf(curFileName, "%s%d", cbInfo->filename, cbInfo->frameList[cbInfo->curFileNum]);
        cbInfo->stream = fopen(curFileName, BINARY_READ);
    }

    if ( !cbInfo->stream )
        return MC_CANNOT_COMPLY;

    bytes_read = fread(cbInfo->buffer, 1, sizeof(cbInfo->buffer),
                       cbInfo->stream);
    if ( ferror(cbInfo->stream) )
        return MC_CANNOT_COMPLY;

    if ( feof(cbInfo->stream) )
    {
        fclose(cbInfo->stream);
        cbInfo->stream = NULL;
        cbInfo->curFileNum++;
        if (cbInfo->curFileNum == cbInfo->numFrames)
        {
            *CBisLast = 1;
        }
        else
        {
            sprintf(curFileName, "%s%d", cbInfo->filename, cbInfo->frameList[cbInfo->curFileNum]);
            cbInfo->stream = fopen(curFileName, BINARY_READ);
            if ( !cbInfo->stream )
                return MC_CANNOT_COMPLY;
        }
    } else
        *CBisLast = 0;

    *CBdataBuffer = cbInfo->buffer;
    *CBdataLen = (int)bytes_read;
    cbInfo->byteProcessed += (int)bytes_read;

    return MC_NORMAL_COMPLETION;
}

/*****************************************************************************
 *
 * NAME
 *    ProcessCompInstRootRetRQ - Process Composite Instance Root Retreive Service message
 *
 * ARGUMENTS
 *    A_outMsgID    int              Id of message that will contain the response message
 *    A_reqMsgID    int              Id of message that contains the request message
 *
 * DESCRIPTION
 *    This function processes the incoming request and constructs a message with
 *      the requested frame(s)
 *
 * RETURNS
 *    MC_NORMAL_COMPLETION on success, any other MC_STATUS
 *    value on failure.
 *
 * SEE ALSO
 *    DICOM PS 3.4-2011 Part 4 Annex Y.3.3 for the description of FRAME level object
 *    creation rule.
 *
 ****************************************************************************/
static MC_STATUS ProcessCompInstRootRetRQ(int A_outMsgID, int A_reqMsgID)
{
#define MAX_FRAMES 10       /* this example only supports max 10 frames */
    static char     S_prefix[]="ProcessCompInstRootRetRQ";
    char            buffer[80];
    char            origSOPInstanceUID[65];
    int             frameReqList[MAX_FRAMES];
    int             i;
    int             frameReqCount, numOrigFrames = 0;
    MC_STATUS       mcStatus;
    int             frameExtractSQ_ID, contribEquipSQ_ID, purposeOfRefCodeSQ_ID;
    TRANSFER_SYNTAX messageSyntax;

    /* For this example, only the simple frame list is used. */
    /* TODO: User can modify code to support MC_ATT_CALCULATED_FRAME_LIST or MC_ATT_TIME_RANGE */

    /* get the number of frames in output message */
    mcStatus = MC_Get_Value_To_Int(A_outMsgID, MC_ATT_NUMBER_OF_FRAMES, &numOrigFrames);
    if (mcStatus != MC_NORMAL_COMPLETION && mcStatus != MC_NULL_VALUE)
    {
        PrintErrorMessage(S_prefix, "Fail to get total number of frames for multi-frame image",mcStatus,NULL);
        printf("***          Tag: %X\n", MC_ATT_NUMBER_OF_FRAMES);
        return mcStatus;
    }
    if (numOrigFrames == 0) numOrigFrames = 1;

    /* check to see if this is a multi-frame image */
    if (numOrigFrames < 2)
    {
        PrintErrorMessage(S_prefix, "Not a multi-frame image",MC_CANNOT_COMPLY,NULL);
        return MC_CANNOT_COMPLY;
    }

    /* Get the frame list from the request */
    mcStatus = MC_Get_Value_Count(A_reqMsgID, MC_ATT_SIMPLE_FRAME_LIST, &frameReqCount);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage(S_prefix, "Fail to get total count in frame list",mcStatus,NULL);
        printf("***          Tag: %X\n", MC_ATT_SIMPLE_FRAME_LIST);
        return mcStatus;
    }
    else if (frameReqCount < 1)
    {
        PrintErrorMessage(S_prefix, "Total count of frame request is zero",mcStatus,NULL);
        printf("***          Tag: %X\n", MC_ATT_SIMPLE_FRAME_LIST);
        return MC_CANNOT_COMPLY;
    }
    else if (numOrigFrames == frameReqCount)
    {
        /* The entire multi-frame image is requested, just return the output without further processing */
        return MC_NORMAL_COMPLETION;
    }

    /* process frame list, this example only supports 10 frames max */
    for (i=0; i<frameReqCount; i++)
    {
        if (i==0)
        {
            mcStatus = MC_Get_Value_To_Int(A_reqMsgID, MC_ATT_SIMPLE_FRAME_LIST, &frameReqList[i]);
        }
        else
        {
            mcStatus = MC_Get_Next_Value_To_Int(A_reqMsgID, MC_ATT_SIMPLE_FRAME_LIST, &frameReqList[i]);
        }
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            PrintErrorMessage(S_prefix, "Fail to get frame list",mcStatus,NULL);
            printf("***          Tag: %X\n", MC_ATT_SIMPLE_FRAME_LIST);
            return mcStatus;
        }
    }

    /* retrieve frame from image */
    for (i=0; i<frameReqCount; i++)
    {
        FrameUserInfo userInfo;
        userInfo.stream = NULL;
        userInfo.byteProcessed = 0;
        sprintf(userInfo.filename, "tempFrame.%d", frameReqList[i]);

        mcStatus = MC_Get_Frame_To_Function(A_outMsgID, frameReqList[i], &userInfo, GetFrameToFunction);
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            PrintErrorMessage(S_prefix, "Fail to retrieve frame from image",mcStatus,NULL);
            return mcStatus;
        }
    }

    /* remember the message transfer syntax before removing the pixel data */
    mcStatus = MC_Get_Message_Transfer_Syntax( A_outMsgID, &messageSyntax );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(S_prefix, "MC_Get_Message_Transfer_Syntax", mcStatus, NULL);
        return C_GET_FAILURE_UNABLE_TO_PROCESS;
    }

    /* delete existing pixel data */
    mcStatus = MC_Delete_Attribute(A_outMsgID, MC_ATT_PIXEL_DATA);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage(S_prefix, "Fail to delete current pixel data",mcStatus,NULL);
        return mcStatus;
    }

    /* replace the number of frames attribute with the count of requested frame list */
    mcStatus = MC_Set_Value_From_Int(A_outMsgID, MC_ATT_NUMBER_OF_FRAMES, frameReqCount);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage(S_prefix, "Fail to set new frame number",mcStatus,NULL);
        printf("***          Tag: %X\n", MC_ATT_NUMBER_OF_FRAMES);
        return mcStatus;
    }

    if (messageSyntax == EXPLICIT_LITTLE_ENDIAN || messageSyntax == EXPLICIT_BIG_ENDIAN ||
        messageSyntax == IMPLICIT_LITTLE_ENDIAN)
    {
        /* uncompressed syntaxes */
        FrameUserInfo userInfo;

        userInfo.frameList = frameReqList;
        userInfo.numFrames = frameReqCount;
        strcpy(userInfo.filename, "tempFrame.");

        mcStatus = MC_Set_Value_From_Function(A_outMsgID, MC_ATT_PIXEL_DATA, &userInfo, SetUncompFrameFromFunction);
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            PrintErrorMessage(S_prefix, "Fail to set new pixel data",mcStatus,NULL);
            return mcStatus;
        }
    }
    else
    {
        /* compressed syntaxes, add the encapsulated data */
        /* add new pixel data based on the new frames */
        for (i=0; i<frameReqCount; i++)
        {
            FrameUserInfo userInfo;
            userInfo.stream = NULL;
            userInfo.byteProcessed = 0;
            sprintf(userInfo.filename, "tempFrame.%d", frameReqList[i]);
            if (i==0)
            {
                mcStatus = MC_Set_Encapsulated_Value_From_Function(A_outMsgID, MC_ATT_PIXEL_DATA, &userInfo, SetCompFrameFromFunction);
            }
            else
            {
                mcStatus = MC_Set_Next_Encapsulated_Value_From_Function(A_outMsgID, MC_ATT_PIXEL_DATA, &userInfo, SetCompFrameFromFunction);
            }
            if (mcStatus != MC_NORMAL_COMPLETION)
            {
                PrintErrorMessage(S_prefix, "Fail to set new pixel data",mcStatus,NULL);
                return mcStatus;
            }
        }
        mcStatus = MC_Close_Encapsulated_Value(A_outMsgID, MC_ATT_PIXEL_DATA);
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            PrintErrorMessage(S_prefix, "Fail to close pixel data",mcStatus,NULL);
            return mcStatus;
        }
    }

    /* always generate a new SOP instanace UID for a constructed image */
    /* this example will append a digit to the existing SOP instance UID, user can implement different algo */
    mcStatus = MC_Get_Value_To_String(A_outMsgID, MC_ATT_SOP_INSTANCE_UID, sizeof(origSOPInstanceUID), origSOPInstanceUID);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage(S_prefix, "Fail to get SOP instance UID",mcStatus,NULL);
        printf("***          Tag: %X\n", MC_ATT_SOP_INSTANCE_UID);
        return mcStatus;
    }

    strcpy(buffer, origSOPInstanceUID);
    strcat(buffer, ".1");
    mcStatus = MC_Set_Value_From_String(A_outMsgID, MC_ATT_SOP_INSTANCE_UID, buffer);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage(S_prefix, "Fail to set SOP instance UID",mcStatus,NULL);
        printf("***          Tag: %X\n", MC_ATT_SOP_INSTANCE_UID);
        return mcStatus;
    }

    /* Construct output image according to DICOM rule */
    /* TODO: if Per-frame Functional Group Sequence (5200,9230) exist, */
    /* users should modify those SQ to only contains the requested frames */

    /* add an item into Frame Extraction sequence */
    mcStatus = MC_Open_Item(&frameExtractSQ_ID, Items.FRAME_EXTRACTION);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage(S_prefix, "Fail to create frame extraction item ID",mcStatus,NULL);
        return mcStatus;
    }
    mcStatus = MC_Set_Value_From_String(frameExtractSQ_ID, MC_ATT_MULTI_FRAME_SOURCE_SOP_INSTANCE_UID, origSOPInstanceUID);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage(S_prefix, "Fail to set multi frame source sop instance uid",mcStatus,NULL);
        return mcStatus;
    }
    for (i=0; i<frameReqCount; i++)
    {
        if (i==0)
        {
            mcStatus = MC_Set_Value_From_Int(frameExtractSQ_ID, MC_ATT_SIMPLE_FRAME_LIST, frameReqList[i]);
        }
        else
        {
            mcStatus = MC_Set_Next_Value_From_Int(frameExtractSQ_ID, MC_ATT_SIMPLE_FRAME_LIST, frameReqList[i]);
        }
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            PrintErrorMessage(S_prefix, "Fail to set simple frame list",mcStatus,NULL);
            return mcStatus;
        }
    }
    /* TODO: If outMsgID has MC_ATT_FRAME_EXTRACTION_SEQUENCE, You should append this item instead of replace. */
    mcStatus = MC_Set_Value_From_Int(A_outMsgID, MC_ATT_FRAME_EXTRACTION_SEQUENCE, frameExtractSQ_ID);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage(S_prefix, "Fail to add frame extract sequence",mcStatus,NULL);
        printf("***          Tag: %X\n", MC_ATT_FRAME_EXTRACTION_SEQUENCE);
        return mcStatus;
    }

    /* add an item into Contributing Equipment Sequence (0018,A001) */
    mcStatus = MC_Open_Item(&contribEquipSQ_ID, Items.CONTRIBUTING_EQUIPMENT);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage(S_prefix, "Fail to create contributing equipment item ID",mcStatus,NULL);
        return mcStatus;
    }

    mcStatus = MC_Open_Item(&purposeOfRefCodeSQ_ID, Items.CODE_SEQUENCE_MACRO);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage(S_prefix, "Fail to create purpose of reference code item ID",mcStatus,NULL);
        return mcStatus;
    }
    mcStatus = MC_Set_Value_From_String(purposeOfRefCodeSQ_ID, MC_ATT_CODING_SCHEME_DESIGNATOR, "DCM");
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage(S_prefix, "Fail to set coding scheme designator",mcStatus,NULL);
        printf("***          Tag: %X\n", MC_ATT_CODING_SCHEME_DESIGNATOR);
        return mcStatus;
    }
    mcStatus = MC_Set_Value_From_String(purposeOfRefCodeSQ_ID, MC_ATT_CODE_VALUE, "109105");
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage(S_prefix, "Fail to set code value",mcStatus,NULL);
        printf("***          Tag: %X\n", MC_ATT_CODE_VALUE);
        return mcStatus;
    }
    mcStatus = MC_Set_Value_From_String(purposeOfRefCodeSQ_ID, MC_ATT_CODE_MEANING, "Frame Extracting Equipment");
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage(S_prefix, "Fail to set code meaning",mcStatus,NULL);
        printf("***          Tag: %X\n", MC_ATT_CODE_MEANING);
        return mcStatus;
    }

    mcStatus = MC_Set_Value_From_Int(contribEquipSQ_ID, MC_ATT_PURPOSE_OF_REFERENCE_CODE_SEQUENCE, purposeOfRefCodeSQ_ID);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage(S_prefix, "Fail to add purpose of reference code item to contributing equipment",mcStatus,NULL);
        printf("***          Tag: %X\n", MC_ATT_PURPOSE_OF_REFERENCE_CODE_SEQUENCE);
        return mcStatus;
    }
    mcStatus = MC_Set_Value_From_String(contribEquipSQ_ID, MC_ATT_MANUFACTURER, "YourManufacturer"); /* change YourManufacturer */
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage(S_prefix, "Fail to set manufacturer",mcStatus,NULL);
        printf("***          Tag: %X\n", MC_ATT_MANUFACTURER);
        return mcStatus;
    }
    /* TODO: If outMsgID has MC_ATT_CONTRIBUTING_EQUIPMENT_SEQUENCE, You should append this item instead of replace. */
    mcStatus = MC_Set_Value_From_Int(A_outMsgID, MC_ATT_CONTRIBUTING_EQUIPMENT_SEQUENCE, contribEquipSQ_ID);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage(S_prefix, "Fail to add contributing equipment item to response message",mcStatus,NULL);
        printf("***          Tag: %X\n", MC_ATT_CONTRIBUTING_EQUIPMENT_SEQUENCE);
        return mcStatus;
    }

    /* Get rid of Pixel Data URL (0028,7FE0) if exist */
    MC_Delete_Attribute(A_outMsgID, MC_ATT_PIXEL_DATA_PROVIDER_URL);

    /* TODO: DICOM recommends not to copy the private attributes unless it is fully intended. User can choose */
    /* to delete private attributes in this case. This example will leave the private attributes in place. */

    /* TODO: check all Concatenation attributes and delete from outMsgID if exist */
    MC_Delete_Attribute(A_outMsgID, MC_ATT_CONCATENATION_UID);
    MC_Delete_Attribute(A_outMsgID, MC_ATT_IN_CONCATENATION_NUMBER);
    MC_Delete_Attribute(A_outMsgID, MC_ATT_IN_CONCATENATION_TOTAL_NUMBER);

    return MC_NORMAL_COMPLETION;
}

#ifdef UNIX
/****************************************************************************
 *
 *  Function    :   sigint_routine (UNIX)
 *
 *  Parameters  :   Asigno  -
 *                  Acode   -
 *                  Ascp    -
 *
 *  Returns     :   none
 *
 *  Description :   This is our SIGINT routine (The user wants to shut down)
 *
 ****************************************************************************/
#if defined(SUN_SOLNAT) || defined(SUN_SOL8) || defined(SOL_X86) || defined(SOL_X86_64) \
 || defined(ANDROID) || defined(MACOSX_INTEL) || defined(IOS)
static void sigint_routine( int Asigno )
#else
static void sigint_routine  (int Asigno, long Acode, struct sigcontext *Ascp)
#endif
{
    signal_quit = 1;
    /* Do not reset signal [i.e. signal(SIGINT, SIG_DFL)]; oddly, this crashes in some Linux implementations */
}
#endif /* UNIX */
