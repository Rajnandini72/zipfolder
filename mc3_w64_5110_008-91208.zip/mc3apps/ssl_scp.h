
/*******************************************************************************
 *                                                                             *
 *   Copyright (C) IBM Corporation 2016, 2020.                                 *
 *   Copyright (C) Merge Healthcare 2005, 2016.                                *
 *                                                                             *
 *   All rights reserved.                                                      *
 *                                                                             *
 *  This software is furnished under license and may be used and copied only   *
 *  in accordance with the terms of such license and with the inclusion of the *
 *  above copyright notice.                                                    *
 *                                                                             *
 *  This software or any other copies thereof may not be provided or otherwise *
 *  made available to any other person. No title to and ownership of the       *
 *  software is hereby transferred.                                            *
 *                                                                             *
 *******************************************************************************/

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <conio.h>
#include <time.h>
#include <signal.h>
#include <process.h>
#include <sys/timeb.h>

#ifdef _WIN32
#include <fcntl.h>
#endif

#include "mc3media.h"
#include "mergecom.h"
#include "diction.h"

#include "general_util.h"

/* DICOM VR Lengths */
#define AE_LENGTH 16
#define UI_LENGTH 64

#define MAX_THREAD_SERVERS 5
#define THREAD_STACK_SIZE  16384
#define TIME_OUT (30)

#if defined(_WIN32)
#define BINARY_READ "rb"
#define BINARY_WRITE "wb"
#define BINARY_APPEND "rb+"
#define BINARY_READ_APPEND "a+b"
#define BINARY_CREATE "w+b"
#define TEXT_READ "r"
#define TEXT_WRITE "w"
#else
#define BINARY_READ "r"
#define BINARY_WRITE "w"
#define BINARY_APPEND "r+"
#define BINARY_READ_APPEND "a+"
#define BINARY_CREATE "w+"
#define TEXT_READ "r"
#define TEXT_WRITE "w"
#endif

extern SecureSocketFunctions sampleSSfunctions;

/* Application context used for Secure Socket Layer implementation */
typedef struct SSLcontext_struct 
{
    char*   certificateFile;
    char*   privateKeyFile;
    char*   passwrd;
    void*   ctx;
} SSLcontext;

/* Information passed to the child process thread */
typedef struct ChildContext_struct 
{
    SSLcontext    securityContext;
    int           associationID;
} ChildContext;

/* Used to identify the format of an object */
typedef enum
{
    UNKNOWN_FORMAT = 0,
    MEDIA_FORMAT = 1,
    IMPLICIT_LITTLE_ENDIAN_FORMAT,
    IMPLICIT_BIG_ENDIAN_FORMAT,
    EXPLICIT_LITTLE_ENDIAN_FORMAT,
    EXPLICIT_BIG_ENDIAN_FORMAT
} FORMAT_ENUM;
