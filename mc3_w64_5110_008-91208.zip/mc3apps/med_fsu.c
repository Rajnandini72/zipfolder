
/*******************************************************************************
 *                                                                             *
 *       System: Merge DICOM Toolkit Media Extensions Sample Application       *
 *                                                                             *
 *  Description: This is a sample media application using a DICOMDIR.          *
 *               It behaves as a storage service class SCP, and places         *
 *               information about received images into a DICOMDIR.            *
 *                                                                             *
 *******************************************************************************
 *                                                                             *
 *   Copyright (C) IBM Corporation 2016, 2020.                                 *
 *   Copyright (C) Merge Healthcare 2005, 2016.                                *
 *                                                                             *
 *   All rights reserved.                                                      *
 *                                                                             *
 *  This software is furnished under license and may be used and copied only   *
 *  in accordance with the terms of such license and with the inclusion of the *
 *  above copyright notice.                                                    *
 *                                                                             *
 *  This software or any other copies thereof may not be provided or otherwise *
 *  made available to any other person. No title to and ownership of the       *
 *  software is hereby transferred.                                            *
 *                                                                             *
 *******************************************************************************/

/* Standard 'C' includes */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* Platform specific includes */
#if defined(_WIN32)
#include <conio.h>
#include <fcntl.h>
#include <io.h>
#else
#ifdef STRINGS
#include <strings.h>
#endif
#include <sys/time.h>
#include <sys/wait.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#endif

/* Merge DICOM Toolkit includes */
#include "mergecom.h"
#include "diction.h"
#include "mc3media.h"
#include "mc3msg.h"

#define FSUAETITLE "MERGE_MEDIA"     /* AE title when writting to DICOM media */
#define SCPAETITLE "MERGE_MEDIA_FSU" /* AE title when associating for storage */

/* Local definitions */
#define FSU_FAIL 0
#define FSU_SUCCESS 1

/* Structure used to search for directory records */
typedef struct RecordFindInfo_Struct
{
    int             foundRecord; /* The identifier of the record found */
    unsigned long   matchTag;    /* The tag of the attribute to match */
    char            matchValue[256]; /* The value to match */
    char            crtValue[256];   /* Buffer to read the actual value into */
} RecordFindInfo;

/* Tag lists by record type, used to display and populate record content */
static unsigned long PATIENT_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_PATIENTS_NAME, MC_ATT_PATIENT_ID, 
        MC_ATT_PATIENTS_BIRTH_DATE, MC_ATT_PATIENTS_SEX, MC_ATT_PATIENT_COMMENTS, 0 };

static unsigned long STUDY_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_STUDY_DATE, MC_ATT_STUDY_TIME, 
        MC_ATT_STUDY_DESCRIPTION, MC_ATT_STUDY_INSTANCE_UID, MC_ATT_STUDY_ID, 
        MC_ATT_ACCESSION_NUMBER, 0 };

static unsigned long SERIES_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_MODALITY, MC_ATT_SERIES_INSTANCE_UID, 
        MC_ATT_SERIES_NUMBER, MC_ATT_SERIES_DATE, MC_ATT_SERIES_TIME, 
        MC_ATT_SERIES_DESCRIPTION, 0 };

static unsigned long IMAGE_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_INSTANCE_NUMBER, MC_ATT_IMAGE_DATE,
        MC_ATT_IMAGE_TIME, MC_ATT_ICON_IMAGE_SEQUENCE, MC_ATT_IMAGE_TYPE, 
        MC_ATT_ROWS, MC_ATT_COLUMNS, 0 };

static unsigned long PRESENTATION_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_INSTANCE_NUMBER, MC_ATT_PRESENTATION_CREATION_DATE,
        MC_ATT_PRESENTATION_CREATION_TIME, MC_ATT_REFERENCED_SERIES_SEQUENCE, MC_ATT_BLENDING_SEQUENCE,
        MC_ATT_CONTENT_LABEL, MC_ATT_CONTENT_DESCRIPTION, MC_ATT_ALTERNATE_CONTENT_DESCRIPTION_SEQUENCE, 
        MC_ATT_CONTENT_CREATORS_NAME, MC_ATT_CONTENT_CREATORS_IDENTIFICATION_SEQUENCE, 0 };

static unsigned long RT_DOSE_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_INSTANCE_NUMBER, MC_ATT_ICON_IMAGE_SEQUENCE,
        MC_ATT_DOSE_SUMMATION_TYPE, MC_ATT_DOSE_COMMENT, 0 };

static unsigned long RT_STRUCTURE_SET_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_INSTANCE_NUMBER, MC_ATT_STRUCTURE_SET_DATE,
        MC_ATT_STRUCTURE_SET_TIME, MC_ATT_STRUCTURE_SET_LABEL, 0 };

static unsigned long RT_PLAN_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_INSTANCE_NUMBER, MC_ATT_RT_PLAN_DATE,
        MC_ATT_RT_PLAN_TIME, MC_ATT_RT_PLAN_LABEL, 0 };

static unsigned long RT_TREATMENT_RECORD_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_INSTANCE_NUMBER, MC_ATT_TREATMENT_DATE,
        MC_ATT_TREATMENT_TIME, 0 };

static unsigned long SR_DOCUMENT_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_INSTANCE_NUMBER, MC_ATT_COMPLETION_FLAG,
        MC_ATT_VERIFICATION_FLAG, MC_ATT_CONTENT_DATE, MC_ATT_CONTENT_TIME, 
        MC_ATT_VERIFICATION_DATE_TIME, MC_ATT_CONCEPT_NAME_CODE_SEQUENCE, MC_ATT_CONTENT_SEQUENCE, 0 };

static unsigned long KEY_OBJECT_DOCUMENT_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_INSTANCE_NUMBER, MC_ATT_CONTENT_DATE, 
        MC_ATT_CONTENT_TIME, MC_ATT_CONCEPT_NAME_CODE_SEQUENCE, MC_ATT_CONTENT_SEQUENCE, 0 };

static unsigned long SPECTROSCOPY_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_IMAGE_TYPE, MC_ATT_INSTANCE_NUMBER, 
        MC_ATT_CONTENT_DATE, MC_ATT_CONTENT_TIME, MC_ATT_REFERENCED_IMAGE_EVIDENCE_SEQUENCE,
        MC_ATT_NUMBER_OF_FRAMES, MC_ATT_ROWS, MC_ATT_COLUMNS, 
        MC_ATT_DATA_POINT_ROWS, MC_ATT_DATA_POINT_COLUMNS, MC_ATT_ICON_IMAGE_SEQUENCE, 0 };

static unsigned long RAW_DATA_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_INSTANCE_NUMBER, MC_ATT_CONTENT_DATE, 
        MC_ATT_CONTENT_TIME, MC_ATT_ICON_IMAGE_SEQUENCE, 0 };

static unsigned long REGISTRATION_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_INSTANCE_NUMBER, MC_ATT_CONTENT_LABEL, 
        MC_ATT_CONTENT_DESCRIPTION, MC_ATT_ALTERNATE_CONTENT_DESCRIPTION_SEQUENCE, 
        MC_ATT_CONTENT_CREATORS_NAME, MC_ATT_CONTENT_CREATORS_IDENTIFICATION_SEQUENCE, 0 };

static unsigned long HANGING_PROTOCOL_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_HANGING_PROTOCOL_NAME, MC_ATT_HANGING_PROTOCOL_DESCRIPTION,
        MC_ATT_HANGING_PROTOCOL_LEVEL, MC_ATT_HANGING_PROTOCOL_CREATOR, MC_ATT_HANGING_PROTOCOL_CREATION_DATETIME,
        MC_ATT_HANGING_PROTOCOL_DEFINITION_SEQUENCE, MC_ATT_NUMBER_OF_PRIORS_REFERENCED, 
        MC_ATT_HANGING_PROTOCOL_USER_IDENTIFICATION_CODE_SEQUENCE, 0 };

static unsigned long ENCAPSULATED_DOCUMENT_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_INSTANCE_NUMBER, MC_ATT_CONTENT_DATE, 
        MC_ATT_CONTENT_TIME, MC_ATT_DOCUMENT_TITLE, MC_ATT_HL7_INSTANCE_IDENTIFIER,
        MC_ATT_CONCEPT_NAME_CODE_SEQUENCE, MC_ATT_MIME_TYPE_OF_ENCAPSULATED_DOCUMENT, 0 };

static unsigned long HL7_STRUCTURED_DOCUMENT_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_HL7_INSTANCE_IDENTIFIER, MC_ATT_HL7_DOCUMENT_EFFECTIVE_TIME,
        MC_ATT_HL7_DOCUMENT_TYPE_CODE_SEQUENCE, MC_ATT_DOCUMENT_TITLE, 0 };

static unsigned long VALUE_MAP_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_CONTENT_DATE, MC_ATT_CONTENT_TIME,
        MC_ATT_INSTANCE_NUMBER, MC_ATT_CONTENT_LABEL, MC_ATT_CONTENT_DESCRIPTION, 
        MC_ATT_ALTERNATE_CONTENT_DESCRIPTION_SEQUENCE, MC_ATT_CONTENT_CREATORS_NAME, 
        MC_ATT_CONTENT_CREATORS_IDENTIFICATION_SEQUENCE, 0 };

static unsigned long GENERIC_TAGS[] = {
        MC_ATT_SPECIFIC_CHARACTER_SET, MC_ATT_INSTANCE_NUMBER, MC_ATT_CONTENT_DATE,
        MC_ATT_CONTENT_TIME, 0 };


/* Module variables */
static int      S_dirID;
static int      S_fileNameCnt = 0;
static char*    S_fileSetPath = NULL;
static int      S_lastNewRecord = 0;

/* Local functions */
static void             PrintCmdLine( void );
static int              FileExists( char* path );
static unsigned long*   GetRecordTags( MC_DIR_RECORD_TYPE recType );
static void             DisplayRecord( int record, char* indent );
static void             ReceiveInstances( void );
static MC_STATUS        AddGroupTwoElements( int fileID, TRANSFER_SYNTAX transSyntax );
static int              WriteInstanceToFile( int messageID, char* fileName );
static int              CreateNewRecord( int instanceID, int parentID, const char* recTypeName, char* fileID );
static int              GetMatchingRecord( int messageID, int parentID, RecordFindInfo* findInfo, const char* recTypeName );
static int              AddInstanceToDir( int messageID, char* fileID );
static void             ProcessAssociation( int assoc );

static MC_TRAVERSAL_STATUS RecordCounter( int currentRecID, void* cbkData );
static MC_TRAVERSAL_STATUS RecordLister( int currentRecID, void* cbkData );
static MC_TRAVERSAL_STATUS RecordFinder( int currentRecID, void* cbkData );

static MC_STATUS FileToMedia( char* fileName, void* userInfo, int dataSize, void* dataBuffer, int isFirst, int isLast );

/****************************************************************************
*
*  Function    :   main
*
*  Description :   Loops processing user input
*
****************************************************************************/
int main( int argc, char** argv );

int main( int argc, char** argv )
{
    MC_STATUS     status;
    int           dirID;
    int           record;
    int           currentRec;
    char*         dirPath = NULL;
    char          userInput[128];
    int           recCounts[4];
    int           i;
    int           done = 0;

    printf( "%s:  Media Sample FSU Application\n\n", argv[0] );

    /* Parse program arguments */
    for( i = 1; i < argc; i++ )
    {
        if( !strcmp(argv[i], "-h") || !strcmp(argv[i], "/h") ||
            !strcmp(argv[i], "-H") || !strcmp(argv[i], "/H") ||
            !strcmp(argv[i], "-?") || !strcmp(argv[i], "/?") )
        {
            PrintCmdLine();
            return EXIT_SUCCESS;
        }
        else if( !strcmp( argv[i], "-d" ) || !strcmp( argv[i], "-D" ) )
        {
            i++;
            if( argc <= i )
            {
                printf( "Path not specified\n" );
                PrintCmdLine();
                return EXIT_FAILURE;
            }

            S_fileSetPath = argv[i];
        }
    }

    /* Initialize the toolkit */
    status = MC_Library_Initialization ( NULL, NULL, NULL );
    if( status != MC_NORMAL_COMPLETION )
    {
        printf( "\tUnable to initialize library. %s\n", MC_Error_Message( status ) );
        return EXIT_FAILURE;
    }

    /* Setup the DICOMDIR's path */
    if( S_fileSetPath == NULL ) S_fileSetPath = "";
    dirPath = malloc( strlen( S_fileSetPath ) + 20 );
    strcpy( dirPath, S_fileSetPath );
    strcat( dirPath, "/DICOMDIR" );

    /* Open the DICOMDIR if it exists, otherwise create a new one */
    if( FileExists( dirPath ) )
    {
        printf( "Reading DICOM Directory from %s. \n", dirPath );
        status = MC_DDH_Open( dirPath, &dirID );
    }
    else
    {
        printf( "Creating DICOM Directory at %s. \n", dirPath );
        status = MC_DDH_Create( dirPath, NULL, 0, &dirID ); 
    }

    free( dirPath );

    if( status != MC_NORMAL_COMPLETION )
    {
        printf("\tUnable to open the DICOMDIR file. %s\n", MC_Error_Message( status ) );
        return EXIT_FAILURE;
    }

    S_dirID = dirID;

    /* Get the first record of the root entity */
    status = MC_DDH_Get_First_Lower_Record( dirID, &currentRec );
    if( status != MC_NORMAL_COMPLETION )
    {
        printf("\tUnable to get first record. %s\n", MC_Error_Message( status ) );
        return EXIT_FAILURE;
    }

    /* Loop for handling menu selections */
    while( !done )
    {
        /* Display the menu */
        printf( "\n" );
        printf( "-------------------------------| Main |-----------------------------------\n" );
        printf( "\n" );
        printf( "[1] List record hierarchy      [2] List record with MC_List_Item() \n" );
        printf( "[3] Go to first root record    [4] Go to first lower level recrod  \n" );
        printf( "[5] Go to parent record        [6] Go to next record               \n" );
        printf( "[D] Delete current record      [U] Update DICOMDIR file            \n" );
        printf( "[R] Receve instances           [C] Count from the current record   \n" );
        printf( "[A] Count all records\n" );
        printf( "[X] Exit\n" );
        printf( "\n\n" );

        /* Display current record */
        DisplayRecord( currentRec, "     " );
        record = currentRec;
        printf( "\n==> " );

        /* Read user input */
        userInput[0] = 0;

        fflush( stdout );
        fgets( userInput, sizeof( userInput ), stdin );
        fflush( stdout );

        switch ( userInput[0] )
        {
        case '1':
            /* List record hierarchy */
            MC_DDH_Traverse_Records( S_dirID, NULL, RecordLister );
            break;

        case '2':
            /* List current record with MC_List_Item */
            if( currentRec != 0 ) MC_List_Item( currentRec, NULL );
            break;

        case '3':
            /* Go to first root record */
            MC_DDH_Get_First_Lower_Record( dirID, &currentRec );
            break;

        case '4':
            /* Go to first lowe level record */
            if( currentRec == 0 ) break;

            MC_DDH_Get_First_Lower_Record( currentRec, &record );
            
            if( record == 0 ) printf( "The current record has no lower level records\n" );
            else currentRec = record;
            
            break;

        case '5':
            /* Go to parent record */
            if( currentRec == 0 ) break;
            
            MC_DDH_Get_Parent_Record( currentRec, &record );

            if( record == 0 ) printf( "The current record is a root level record\n" );
            else currentRec = record;

            break;

        case '6':
            /* Go to next record */
            if( currentRec == 0 ) break;
            
            MC_DDH_Get_Next_Record( currentRec, &record );

            if( record == 0 ) printf( "There are no more records in this entity\n" );
            else currentRec = record;

            break;

        case 'd':
        case 'D':
            /* Delete current record */
            if( currentRec == 0 )
            {
                printf( "No current record!\n" );
                break;
            }

            MC_DDH_Get_Parent_Record( currentRec, &record );

            status = MC_DDH_Delete_Record( currentRec );
            if( status != MC_NORMAL_COMPLETION ) 
            {
                printf( "Failed to delete the current record! %s\n", MC_Error_Message( status ) );
                break;
            }

            printf( "Record deleted, select Update to apply the changes to the DICOMDIR file\n" );

            /* Make the first root record the current */
            if( record == 0 ) MC_DDH_Get_First_Lower_Record( dirID, &currentRec );
            else currentRec = record;
            break;

        case 'u':
        case 'U':
            /* Update the DICOMDIR file */
            status = MC_DDH_Update( dirID );

            if( status != MC_NORMAL_COMPLETION )
            {
                printf( "Failed to update the DICOMDIR file. %s\n", MC_Error_Message( status ) );
                break;
            }

            printf( "DICOMDIR file updated successfully\n" );
            break;

        case 'r':
        case 'R':
            /* Receive instances */
            ReceiveInstances();
            if( S_lastNewRecord != 0 )
            {
                currentRec = S_lastNewRecord;
                S_lastNewRecord = 0;
            }
            break;

        case 'a':
        case 'A':
            /* Count all records */
            record = S_dirID;

        case 'c':
        case 'C':
            /* Count records */
            memset( recCounts, 0, sizeof( int ) * 4 );
            MC_DDH_Traverse_Records( record, recCounts, RecordCounter );

            if( recCounts[0] > 0 ) printf( "   %d PATIENT records\n", recCounts[0] );
            if( recCounts[1] > 0 ) printf( "   %d STUDY records\n", recCounts[1] );
            if( recCounts[2] > 0 ) printf( "   %d SERIES records\n", recCounts[2] );
            if( recCounts[3] > 0 ) printf( "   %d instance records\n", recCounts[3] );
            break;

        case 'x':
        case 'X':
            /* Exit */
            done = 1;
            break;
        } 
    }

    /* Clean up  */
    MC_Library_Release();

    return EXIT_SUCCESS;
}

/*************************************************************************
*
*  Function    :   PrintCmdLine
*
*  Description :   Prints program usage
*
*************************************************************************/
static void PrintCmdLine()
{
    printf( "\nUsage: med_fsu [-d <pathname>]\n\n" );
    printf( "    -d <pathname> = Optional, specifies the directory of DICOMDIR.\n" );
    printf( "Example: med_fsu -d /DEV/MERGECOM\n\n" );
}

/**************************************************************************
*
*  Function    :   FileExists
*
*  Parameters  :   The file's path.
*
*  Returns     :   1 if the file exists, 0 otherwise
*
*  Description: Checks the existence of a file.
*
**************************************************************************/
static int FileExists( char* path )
{
    FILE* file;

    file = fopen( path, "r" );
    if( file == NULL ) return 0;

    fclose( file );
    return 1;
}

/****************************************************************************
*
*  Function    :   GetRecordTags
*
*  Parameters  :   The directory record type.
*
*  Returns     :   The list of tags for the specified record type.
*
****************************************************************************/
static unsigned long* GetRecordTags( MC_DIR_RECORD_TYPE recType )
{
    switch( recType )
    {
    case MC_REC_TYPE_PATIENT: return PATIENT_TAGS;
    case MC_REC_TYPE_STUDY: return STUDY_TAGS;
    case MC_REC_TYPE_SERIES: return SERIES_TAGS;
    case MC_REC_TYPE_IMAGE: return IMAGE_TAGS;
    case MC_REC_TYPE_RT_DOSE: return RT_DOSE_TAGS;
    case MC_REC_TYPE_RT_STRUCTURE_SET: return RT_STRUCTURE_SET_TAGS;
    case MC_REC_TYPE_RT_PLAN: return RT_PLAN_TAGS;
    case MC_REC_TYPE_RT_TREAT_RECORD: return RT_TREATMENT_RECORD_TAGS;
    case MC_REC_TYPE_PRESENTATION: return PRESENTATION_TAGS;
    case MC_REC_TYPE_SR_DOCUMENT: return SR_DOCUMENT_TAGS;
    case MC_REC_TYPE_KEY_OBJECT_DOC: return KEY_OBJECT_DOCUMENT_TAGS;
    case MC_REC_TYPE_SPECTROSCOPY: return SPECTROSCOPY_TAGS;
    case MC_REC_TYPE_RAW_DATA: return RAW_DATA_TAGS;
    case MC_REC_TYPE_REGISTRATION: 
    case MC_REC_TYPE_FIDUCIAL: return REGISTRATION_TAGS;
    case MC_REC_TYPE_HANGING_PROTOCOL: return HANGING_PROTOCOL_TAGS;
    case MC_REC_TYPE_ENCAP_DOC: return ENCAPSULATED_DOCUMENT_TAGS;
    case MC_REC_TYPE_HL7_STRUC_DOC: return HL7_STRUCTURED_DOCUMENT_TAGS;
    case MC_REC_TYPE_VALUE_MAP: return VALUE_MAP_TAGS;
    default: break;
    }

    return GENERIC_TAGS;
}

/****************************************************************************
*
*  Function    :   DisplayRecord
*
*  Parameters  :   The ID of the directory record to display and the required
*                   indentation.
*
*  Description :   Display the specified directory record. If the indentation
*                  argument is NULL this function will automatically indent 
*                  based on the record's type.
*
****************************************************************************/
static void DisplayRecord( int record, char* indent )
{
    MC_STATUS       status;
    char            name[100];
    char            val[256];
    int             len = (int) sizeof( val );
    MC_VR           vr = UNKNOWN_VR;
    unsigned short  vmLow = 0;
    unsigned short  vmHigh = 0;
    unsigned long*  tags = NULL;
    MC_DIR_RECORD_TYPE recType = MC_REC_TYPE_UNKNOWN;
    int             first = 1;
    int             nameLen = 0;
    int             i = 0;

    if( record == 0 )
    {
        printf( "No record to display\n" );
        return;
    }

    /* Determine the record's type */
    status = MC_DDH_Get_Record_Type( record, &recType );
    if( status == MC_NORMAL_COMPLETION )
    {
        status = MC_Get_Value_To_String( record, MC_ATT_DIRECTORY_RECORD_TYPE, len, val );
    }

    if( status != MC_NORMAL_COMPLETION )
    {
        printf( "Failed to get record type. %s\n", MC_Error_Message( status ) );
        return;
    }

    if( indent == NULL )
    {
        if( recType == MC_REC_TYPE_PATIENT ) indent = "";
        else if( recType == MC_REC_TYPE_STUDY ) indent = "  ";
        else if( recType == MC_REC_TYPE_SERIES ) indent = "    ";
        else indent = "      ";
    }

    printf( "%s%s REC ID: %d ==============\n", indent, val, record );

    /* Get the list of tags and display the record's value for each tag */
    tags = GetRecordTags( recType );

    while( *tags != 0 )
    {
        status = MC_Get_Tags_Dict_Info( *tags, name, sizeof( name ), &vr, &vmLow, &vmHigh );

        if( status != MC_NORMAL_COMPLETION )
        {
            printf( "Failed to retrieve dictionary info for 0x%lX, %s\n", *tags, MC_Error_Message( status ) );
            return;
        }
        
        /* Do not display binary types */
        if( vr == UNKNOWN_VR || vr == OB || vr == OW || vr == OL || vr == OD || vr == OF || vr == SQ ) 
        {
            tags++;
            continue;
        }

        nameLen = (int) strlen( name );
        first = 1;
        val[0] = '\0';
        status = MC_Get_Value_To_String( record, *tags, sizeof( val ), val );

        while( status == MC_NORMAL_COMPLETION )
        {
            if( first )
            {
                printf("%s %s:", indent, name );
                for( i=0; i<(20-nameLen); i++ ) printf( " " );

                first = 0;
            }

            printf( "%s", val );

            status = MC_Get_Next_Value_To_String( record, *tags, sizeof( val ), val );
            if( status == MC_NORMAL_COMPLETION ) printf( "\\" );
            else printf( "\n" );
        }

        tags++;
    }

    /* Display Referenced File ID and Referenced SOP Instance UID values if present */
    status = MC_Get_Value_To_String( record, MC_ATT_REFERENCED_FILE_ID, sizeof( val ), val );
    if( status == MC_NORMAL_COMPLETION ) printf( "%s File ID:             %s\n", indent, val );

    status = MC_Get_Value_To_String( record, MC_ATT_REFERENCED_SOP_INSTANCE_UID_IN_FILE, sizeof( val ), val );
    if( status == MC_NORMAL_COMPLETION ) printf( "%s Ref SOP Inst UID:    %s\n", indent, val );

}

/****************************************************************************
*
*  Function    :   ReceiveInstances
*
*  Description :   Listens for an association from a storage SCU and adds any
*                  instance received to the DICOMDIR creating new records.
*                  This function also saves received instances in DICOM Part10
*                  files.
*
****************************************************************************/
static void ReceiveInstances()
{
    MC_STATUS status;
    int storeSCPApp = 0;
    int calledApp = 0;
    int assoc = 0;
    int portNo = 0;
    
    /* Register the DICOM application for the storage SCP */
    status = MC_Register_Application( &storeSCPApp, SCPAETITLE );
    if( status != MC_NORMAL_COMPLETION )
    {
        printf( "Failed to register SCP application. %s\n", MC_Error_Message( status ) );
        return;
    }

    MC_Get_Int_Config_Value( TCPIP_LISTEN_PORT, &portNo );
    printf( "Waiting for association on port %d\n", portNo );

    /* Wait for an association for two minutes */
    status = MC_Wait_For_Association( "Storage_SCP_Service_List", 120, &calledApp, &assoc );

    if( status != MC_NORMAL_COMPLETION )
    {
        MC_Release_Application( &storeSCPApp );

        if( status == MC_TIMEOUT )
        {
            printf( "Timed out waiting for association\n" );
        }
        else
        {
            printf( "Failed to wait for association. %s\n", MC_Error_Message( status ) );
        }
        return;
    }

    MC_Close_Listen_Port( portNo );

    /* Accept the assocaition */
    status = MC_Accept_Association( assoc );

    if( status == MC_NORMAL_COMPLETION )
    {
        ProcessAssociation( assoc );
    }
    else
    {
        printf( "Failed to accept association. %s\n", MC_Error_Message( status ) );
        MC_Abort_Association( &assoc );
    }

    
    MC_Release_Application( &storeSCPApp );
}

/****************************************************************************
 *
 *  Function    :   FileToMedia
 *
 *  Description :   Callback function used to write DICOM file object to media.
 *
 ****************************************************************************/
static MC_STATUS FileToMedia(char*      fileName,
                            void*       userInfo,
                            int         dataSize,
                            void*       dataBuffer,
                            int         isFirst,
                            int         isLast )
{
    static FILE* stream = NULL;

    if( isFirst ) stream = fopen( fileName, "wb" );
    if( !stream ) return MC_CANNOT_COMPLY;

    if( fwrite( dataBuffer, 1, dataSize, stream ) != (size_t) dataSize ) 
    {
        printf( "fwrite error\n" );
        fclose( stream );
        return MC_CANNOT_COMPLY;
    }

    if( fflush( stream ) != 0 )
    {
        printf( "fflush error\n" );
        fclose( stream );
        return MC_CANNOT_COMPLY;
    }

    if( isLast ) fclose( stream );
    return MC_NORMAL_COMPLETION;
}


/****************************************************************************
 *
 *  Function    :   AddGroupTwoElements
 *
 *  Parameters  :   The file object identifier and the transfer syntax.
 *
 *  Returns     :   MC_NORMAL_COMPLETION if successful.
 *
 *  Description :   Adds the required group two elements to a file object.
 *
 ****************************************************************************/
static MC_STATUS AddGroupTwoElements( int fileID, TRANSFER_SYNTAX transSyntax )
{
    MC_STATUS status;
    char      uidBuffer[66];

    /* Set the transfer syntax for the file */
    status = MC_Get_Transfer_Syntax_From_Enum( transSyntax, uidBuffer, sizeof( uidBuffer ) );
    if( status != MC_NORMAL_COMPLETION ) return status;

    status = MC_Set_Value_From_String( fileID, MC_ATT_TRANSFER_SYNTAX_UID, uidBuffer );
    if( status != MC_NORMAL_COMPLETION ) return status;

    /* Set other media group 2 elements */
    status = MC_Get_Value_To_String( fileID, MC_ATT_SOP_CLASS_UID, sizeof(uidBuffer), uidBuffer );
    if( status != MC_NORMAL_COMPLETION ) return status;

    status = MC_Set_Value_From_String( fileID, MC_ATT_MEDIA_STORAGE_SOP_CLASS_UID, uidBuffer );
    if( status != MC_NORMAL_COMPLETION ) return status;

    status = MC_Get_Value_To_String( fileID, MC_ATT_SOP_INSTANCE_UID, sizeof(uidBuffer), uidBuffer );
    if( status != MC_NORMAL_COMPLETION ) return status;

    status = MC_Set_Value_From_String( fileID, MC_ATT_MEDIA_STORAGE_SOP_INSTANCE_UID, uidBuffer );
    if( status != MC_NORMAL_COMPLETION ) return status;

    status = MC_Set_Value_From_String( fileID, MC_ATT_SOURCE_APPLICATION_ENTITY_TITLE, FSUAETITLE );
    if( status != MC_NORMAL_COMPLETION ) return status;

    return MC_NORMAL_COMPLETION;
}

/****************************************************************************
 *
 *  Function    :   WriteInstanceToFile
 *
 *  Parameters  :   The message object identifier and the file name.
 *
 *  Returns     :   FSU_SUCCESS if successful.
 *
 *  Description :   Writes the content of a message object to a DICOM Part10 
 *                  file.
 *
 ****************************************************************************/
static int  WriteInstanceToFile( int messageID, char* fileName )
{
    MC_STATUS status;
    TRANSFER_SYNTAX ts;

    /* Keep the transfer syntax of the recieved message */
    status = MC_Get_Message_Transfer_Syntax( messageID, &ts );
    if( status != MC_NORMAL_COMPLETION )
    {
        printf( "Warning: error on MC_Get_Message_Transfer_Syntax. %s\n", MC_Error_Message( status ) );
        ts = EXPLICIT_LITTLE_ENDIAN;
    }

    /* Convert the message to a file */
    status = MC_Message_To_File( messageID, fileName );
    if( status != MC_NORMAL_COMPLETION )
    {
        printf( "Error on MC_Message_To_File. %s\n", MC_Error_Message( status ) );
        return FSU_FAIL;
    }

    /* Setup some file elements */
    status = AddGroupTwoElements( messageID, ts );
    if (status != MC_NORMAL_COMPLETION)
    {
        printf( "Error on AddGroupTwoElements. %s\n", MC_Error_Message( status ) );
        return FSU_FAIL;
    }

    printf( "Writing image to file \"%s\".\n", fileName );

    status = MC_Write_File( messageID, 0, NULL, FileToMedia );
    
    if( status != MC_NORMAL_COMPLETION )
    {
        printf( "Error on MC_Write_File. %s\n", MC_Error_Message( status ) );
        return FSU_FAIL;
    }

    return FSU_SUCCESS;
}

/****************************************************************************
 *
 *  Function    :   RecordCounter
 *
 *  Description :   Record traversal callback for counting records.
 *
 ****************************************************************************/
static MC_TRAVERSAL_STATUS RecordCounter( int currentRecID, void* cbkData )
{
    MC_DIR_RECORD_TYPE recType = MC_REC_TYPE_UNKNOWN;
    int* counts = (int*) cbkData;

    MC_DDH_Get_Record_Type( currentRecID, &recType );

    if( recType == MC_REC_TYPE_PATIENT ) counts[0] += 1;
    else if( recType == MC_REC_TYPE_STUDY ) counts[1] += 1;
    else if( recType == MC_REC_TYPE_SERIES ) counts[2] += 1;
    else counts[3] += 1;

    return MC_TS_CONTINUE;
}

/****************************************************************************
 *
 *  Function    :   RecordLister
 *
 *  Description :   Record traversal callback for displaying records.
 *
 ****************************************************************************/
static MC_TRAVERSAL_STATUS RecordLister( int currentRecID, void* cbkData )
{
    DisplayRecord( currentRecID, NULL );
    printf( "\n" );
    return MC_TS_CONTINUE;
}

/****************************************************************************
 *
 *  Function    :   RecordFinder
 *
 *  Description :   Record traversal callback for finding records.
 *
 ****************************************************************************/
static MC_TRAVERSAL_STATUS RecordFinder( int currentRecID, void* cbkData )
{
    MC_STATUS status;
    RecordFindInfo* findInfo = (RecordFindInfo*) cbkData;

    status = MC_Get_Value_To_String( currentRecID, findInfo->matchTag, sizeof( findInfo->crtValue ), findInfo->crtValue );
    if( status != MC_NORMAL_COMPLETION ) 
    {
        printf( "Failed to get key value from record. %s\n", MC_Error_Message( status ) );
        return MC_TS_STOP_LOWER; /* Continue with the next record */
    }

    if( strcmp( findInfo->matchValue, findInfo->crtValue ) == 0 )
    {
        /* Record found, stop the traversal */
        findInfo->foundRecord = currentRecID;
        return MC_TS_STOP;
    }

    /* Skip lower level records, continue with the next record */
    return MC_TS_STOP_LOWER;
}

/****************************************************************************
 *
 *  Function    :   CreateNewRecord
 *
 *  Parameters  :   instanceID - the message object containing attribute values
 *                      for the new record
 *                  parentID - the toolkit ID of the parent record or directory 
 *                      to which the new record should be added
 *                  recTypeName - the directory record type string, if NULL the
 *                      new record type will be determind based on the SOP Class
 *                      UID of the instance
 *                  fileID - The referenced file ID or NULL if the new record
 *                      will not reference an instance.
 *
 *  Returns     :   The new record's ID if successful, otherwise zero.
 *
 *  Description :   Creates a new directory record and populates it with attribute
 *                  values from a message object.
 *
 ****************************************************************************/
static int CreateNewRecord( int instanceID, int parentID, const char* recTypeName, char* fileID )
{
    MC_STATUS       status;
    int             recID;
    unsigned long*  tags;
    MC_DIR_RECORD_TYPE recType = MC_REC_TYPE_UNKNOWN;
    char            uidBuffer[66];

    /* If the record type is not specified use the SOP Class UID of the instance, 
       the toolkit will assign the proper type */
    if( recTypeName == NULL && fileID != NULL )
    {
        status = MC_Get_Value_To_String( instanceID, MC_ATT_SOP_CLASS_UID, sizeof( uidBuffer ), uidBuffer );
        if( status != MC_NORMAL_COMPLETION )
        {
            printf( "Failed to get the SOP class UID of instance. %s\n", MC_Error_Message( status ) );
            return 0;
        }

        recTypeName = uidBuffer;
    }

    /* Create the new record */
    status = MC_DDH_Add_Record( parentID, recTypeName, &recID );
    if( status != MC_NORMAL_COMPLETION )
    {
        printf( "Failed to create new record. %s\n", MC_Error_Message( status ) );
        return 0;
    }

    /* Copy record type specific attribute values */
    MC_DDH_Get_Record_Type( recID, &recType );
    
    tags = GetRecordTags( recType );

    status = MC_DDH_Copy_Values( instanceID, recID, tags );
    if( status != MC_NORMAL_COMPLETION )
    {
        MC_DDH_Delete_Record( recID );
        printf( "Failed to copy new record values. %s\n", MC_Error_Message( status ) );
        return 0;
    }

    /* Add referenced instance attributes if needed */
    if( fileID != NULL )
    {
        /* In this sample the referenced file is in the same directory as the DICOMDIR file
           so we have only one value for the Referenced file ID attribute */
        status = MC_Set_Value_From_String( recID, MC_ATT_REFERENCED_FILE_ID, fileID );

        /* Set the SOP Class and Instance UIDs for the directory record */
        if( status == MC_NORMAL_COMPLETION )
        {
            status = MC_Set_Value_From_String( recID, MC_ATT_REFERENCED_SOP_CLASS_UID_IN_FILE, uidBuffer );
        }

        if( status == MC_NORMAL_COMPLETION )
        {
            status = MC_Get_Value_To_String( instanceID, MC_ATT_SOP_INSTANCE_UID, sizeof( uidBuffer ), uidBuffer );
            
            if( status == MC_NORMAL_COMPLETION )
            {
                status = MC_Set_Value_From_String( recID, MC_ATT_REFERENCED_SOP_INSTANCE_UID_IN_FILE, uidBuffer );
            }
        }

        if( status != MC_NORMAL_COMPLETION )
        {
            MC_DDH_Delete_Record( recID );
            printf( "Failed to copy new record values. %s\n", MC_Error_Message( status ) );
            return 0;
        }
    }

    return recID;
}

/****************************************************************************
 *
 *  Function    :   GetMatchingRecord
 *
 *  Parameters  :   messageID - the message object containing matching values
 *                      for the record to find
 *                  parentID - the toolkit ID of the parent record or directory 
 *                      where the search should start
 *                  findInfo - record find information
 *                  recTypeName - The record type name.
 *
 *  Returns     :   The record's ID if successful, otherwise zero.
 *
 *  Description :   Searches for a record that has a matching value for the
 *                  attribute specified by findInfo->matchTag. If a matching
 *                  record is not found this function creates it.
 *
 ****************************************************************************/
static int GetMatchingRecord( int messageID, int parentID, RecordFindInfo* findInfo, const char* recTypeName )
{
    MC_STATUS       status;

    /* Get the value to match against */
    status = MC_Get_Value_To_String( messageID, findInfo->matchTag, sizeof(findInfo->matchValue), findInfo->matchValue );
    if( status != MC_NORMAL_COMPLETION )
    {
        printf( "Unable to get matching key value from message. %s\n", MC_Error_Message( status ) );
        return 0;
    }

    /* Search for a matching record */
    findInfo->foundRecord = 0;
    status = MC_DDH_Traverse_Records( parentID, findInfo, RecordFinder );
    if( status != MC_NORMAL_COMPLETION )
    {
        printf( "Record search failed. %s\n", MC_Error_Message( status ) );
        return 0;
    }

    if( findInfo->foundRecord == 0 )
    {
        /* No matching record, create a new one */
        findInfo->foundRecord = CreateNewRecord( messageID, parentID, recTypeName, NULL );
    }

    return findInfo->foundRecord;
}

/****************************************************************************
 *
 *  Function    :   AddInstanceToDir
 *
 *  Parameters  :   messageID - the message object containing the new instance
 *                  fileID - the referenced file ID
 *
 *  Returns     :   FSU_SUCCESS if successful, otherwise FSU_FAIL.
 *
 *  Description :   Adds the required records to reference the specified instance
 *                  in the directory object.
 *
 ****************************************************************************/
static int AddInstanceToDir( int messageID, char* fileID )
{
    MC_STATUS       status;
    RecordFindInfo  findInfo;
    int             recID = 0;

    /* Find/add the matching patient record */
    findInfo.matchTag = MC_ATT_PATIENT_ID;
    recID = GetMatchingRecord( messageID, S_dirID, &findInfo, "PATIENT" );
    if( recID == 0 ) return FSU_FAIL;

    /* Find/add the matching study record */
    findInfo.matchTag = MC_ATT_STUDY_INSTANCE_UID;
    recID = GetMatchingRecord( messageID, recID, &findInfo, "STUDY" );
    if( recID == 0 ) return FSU_FAIL;

    /* Find/add the matching series record */
    findInfo.matchTag = MC_ATT_SERIES_INSTANCE_UID;
    recID = GetMatchingRecord( messageID, recID, &findInfo, "SERIES" );
    if( recID == 0 ) return FSU_FAIL;

    /* Check if an instance record with the same UID already exists */
    findInfo.matchTag = MC_ATT_REFERENCED_SOP_INSTANCE_UID_IN_FILE;
    findInfo.foundRecord = 0;

    status = MC_Get_Value_To_String( messageID, MC_ATT_SOP_INSTANCE_UID, sizeof(findInfo.matchValue), findInfo.matchValue );
    if( status != MC_NORMAL_COMPLETION )
    {
        printf( "Unable to get SOP Instance UID value from message. %s\n", MC_Error_Message( status ) );
        return FSU_FAIL;
    }

    status = MC_DDH_Traverse_Records( recID, &findInfo, RecordFinder );
    if( status != MC_NORMAL_COMPLETION )
    {
        printf( "Record search failed. %s\n", MC_Error_Message( status ) );
        return FSU_FAIL;
    }

    if( findInfo.foundRecord != 0 )
    {
        /* Delete the record referencing the same Instance UID */
        status = MC_DDH_Delete_Record( findInfo.foundRecord );
        if( status != MC_NORMAL_COMPLETION )
        {
            printf( "Failed to delete old instance record. %s\n", MC_Error_Message( status ) );
            return FSU_FAIL;
        }
    }

    /* Add the new instance record */
    recID = CreateNewRecord( messageID, recID, NULL, fileID );
    if( recID == 0 ) return FSU_FAIL;

    S_lastNewRecord = recID;
    return FSU_SUCCESS;
}

/****************************************************************************
 *
 *  Function    :   ProcessAssociation
 *
 *  Parameters  :   The association to preocess.
 *
 *  Description :   Processes C-STORE messages received on the specified 
 *                  instance.
 *
 ****************************************************************************/
static void ProcessAssociation( int assoc )
{
    MC_STATUS   status;
    MC_COMMAND  command;
    char*       serviceName;
    int         messageID = 0;
    char*       fileName = NULL;
    char        fileID[9];
    RESP_STATUS response;

    fileName = (char*) malloc( strlen( S_fileSetPath ) + 10 );

    printf( "Processing incoming association\n" );
    for( ;; )
    {
        /* Read a message */
        status = MC_Read_Message( assoc, 30, &messageID, &serviceName, &command );

        /* Check for status */
        if( status == MC_ASSOCIATION_CLOSED ) break;

        if( status == MC_NETWORK_SHUT_DOWN
            ||  status == MC_ASSOCIATION_ABORTED
            ||  status == MC_INVALID_MESSAGE_RECEIVED
            ||  status == MC_CONFIG_INFO_ERROR)
        {
            printf( "Failed to read message. %s\n",MC_Error_Message( status ) );
            return;
        }

        if( status == MC_TIMEOUT )
        {
            printf( "Timeout in MC_Read_Message. Aborting the association.\n" );
            MC_Abort_Association( &assoc );
            return;
        }

        if( status != MC_NORMAL_COMPLETION )
        {
            printf( "Error on MC_Read_Message. %s\n", MC_Error_Message( status ) );
            MC_Abort_Association( &assoc );
            return;
        }

        /* Make a file name for the received instance */
        for( ;; )
        {
            S_fileNameCnt++;

            sprintf( fileName, "%s/F%07d", S_fileSetPath, S_fileNameCnt );
            if( !FileExists( fileName ) ) break;
        }

        sprintf( fileID, "F%07d", S_fileNameCnt );

        response = C_STORE_FAILURE_PROCESSING_FAILURE;

        /* Write the instance to the P10 file */
        if( WriteInstanceToFile( messageID, fileName ) == FSU_SUCCESS )
        {
            /* Add an instance reference to the dircetory */
            if( AddInstanceToDir( messageID, fileID ) == FSU_SUCCESS )
            {
                response = C_STORE_SUCCESS;
            }
        }
                
        MC_Free_Message( &messageID );

        /* Create a response message object */
        status = MC_Open_Message( &messageID, serviceName, C_STORE_RSP );
        if( status != MC_NORMAL_COMPLETION )
        {
            printf( "Failed to create response message. %s\n", MC_Error_Message( status ) );
            MC_Abort_Association( &assoc );
            return;
        }

        /* Send the response */
        status = MC_Send_Response_Message( assoc, response, messageID );
        
        if (status != MC_NORMAL_COMPLETION)
        {
            MC_Abort_Association( &assoc );
            MC_Free_Message( &messageID );

            printf( "Failed to send response message. %s\n", MC_Error_Message( status ) );
            return;
        }

        MC_Free_Message( &messageID );
    }

    printf( "Association relesed\n" );

    /* Write the changes to the DICOMDIR file */
    status = MC_DDH_Update( S_dirID );
    if( status != MC_NORMAL_COMPLETION ) 
    {
        printf( "Failed to write new records to the DICOMDIR file. %s\n", MC_Error_Message( status ) );
    }
    else
    {
        printf( "DICOMDIR file successfully updated\n" );
    }
}

