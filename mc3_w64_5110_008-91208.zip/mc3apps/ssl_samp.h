
/*******************************************************************************
 *                                                                             *
 *   Copyright (C) IBM Corporation 2016, 2020.                                 *
 *   Copyright (C) Merge Healthcare 2005, 2016.                                *
 *                                                                             *
 *   All rights reserved.                                                      *
 *                                                                             *
 *  This software is furnished under license and may be used and copied only   *
 *  in accordance with the terms of such license and with the inclusion of the *
 *  above copyright notice.                                                    *
 *                                                                             *
 *  This software or any other copies thereof may not be provided or otherwise *
 *  made available to any other person. No title to and ownership of the       *
 *  software is hereby transferred.                                            *
 *                                                                             *
 *******************************************************************************/


#ifndef UI
#define UI UI_ST

#include <openssl/rsa.h>       /* SSLeay stuff */
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/applink.c>

#undef UI
#endif

#include "mergecom.h"

typedef struct SSLcontext_struct
{
    char*       certificateFile;
    char*       privateKeyFile;
    char*       passwrd;
    SSL_CTX*    ctx;
} SSLcontext;

static BIO *bio_err=NULL;

/*
 * Local Function Prototypes
 */
static SS_STATUS NOEXP_FUNC Sample_Session_Start_Callback(MC_SOCKET SocketToUse, CONN_TYPE ConnectionType, void* ApplicationContext, void** SecurityContext );

static SS_STATUS NOEXP_FUNC Sample_Read_Callback(   void*         SScontext,
                                                    void*         ApplicationContext,
                                                    char*         Buffer,
                                                    unsigned int  BytesToRead,
                                                    unsigned int* BytesRead,
                                                    int           Timeout );

static SS_STATUS NOEXP_FUNC Sample_Write_Callback(  void*         SScontext,
                                                    void*         ApplicationContext,
                                                    char*         Buffer,
                                                    unsigned int  BytesToWrite,
                                                    unsigned int* BytesWritten,
                                                    int           Timeout  );

static void NOEXP_FUNC Sample_Session_Shutdown_Callback( void* SScontext, void* ApplicationContext);

/* Applications provide this structure when calling MC_Open_Secure_Association or MC_Wait_For_Secure_Association */
SecureSocketFunctions sampleSSfunctions = 
{
    Sample_Session_Start_Callback,
    Sample_Read_Callback,
    Sample_Write_Callback,
    Sample_Session_Shutdown_Callback
};
