
/*******************************************************************************
 *                                                                             *
 *       System: Merge DICOM Tool Kit                                          *
 *                                                                             *
 *       Author: Merge Healthcare                                              *
 *                                                                             *
 *  Description:                                                               *
 *               Q/R C-GET Sample Service Class User Application.              *
 *                                                                             *
 *******************************************************************************
 *                                                                             *
 *   Copyright (C) IBM Corporation 2016, 2020.                                 *
 *   Copyright (C) Merge Healthcare 2005, 2016.                                *
 *                                                                             *
 *   All rights reserved.                                                      *
 *                                                                             *
 *  This software is furnished under license and may be used and copied only   *
 *  in accordance with the terms of such license and with the inclusion of the *
 *  above copyright notice.                                                    *
 *                                                                             *
 *  This software or any other copies thereof may not be provided or otherwise *
 *  made available to any other person. No title to and ownership of the       *
 *  software is hereby transferred.                                            *
 *                                                                             *
 *******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <time.h>

#include <fcntl.h>

#include "mergecom.h" 
#include "mc3msg.h"
#include "mcstatus.h"
#include "mc3media.h"
#include "diction.h"
#include "mc3services.h"
#include "qr.h"

#include "general_util.h"

/*
 * Callback structure used to stream in and out messages
 */
typedef struct CALLBACKINFO
{
    FILE*   stream;
    int     messageID;
    char    prefix[30];
} CBinfo;


/* 
 * Command line and configuration options 
 */
typedef struct app_config
{
    int     timeOut;
    char    applicationTitle[AE_LEN];      /* my application title */
    int     applicationID;
    int     associationID;
    int     maxQueryResponses;
    char    remoteApplicationTitle[AE_LEN];/* title we are querying with */
    char    serviceList[SERVICELIST_LEN];
    char    imageType[FILENAME_LEN];
    int     listenPort;                    /* for moveDestination */
} AppConfig;


/* 
 * Information returned structure 
 */
typedef struct ret_data
{
    char     model[SERVICENAME_LEN+1];
    char     level[CS_LEN+1];
    int      numData;
    PRPL     *patient_level;
    PRSTL    *study_level;
    PRSL     *series_level;
    PRIL     *image_level;
    CRFL     *frame_level;
} RetData;

FILE *fd_input=NULL;

static FILE *timing_report_file = NULL;
static char *application_name = NULL;

double total_time = 0;

/* 
 * Local Function prototypes 
 */
static void PrintUsage               ( void );
static QR_STATUS EditQuery           ( RetData*      A_root_level_info,
                                       RetData*      A_list,
                                       AppConfig*    A_myConfig );
static QR_STATUS CGETOption          ( AppConfig*    A_myConfig,
                                       RetData*      A_root_level_info );
static QR_STATUS CFINDOption         ( AppConfig*    A_myConfig,
                                       RetData*      A_root_level_info,
                                       RetData*      A_list );
static char      MainMenu            ( RetData*      A_data );
static char      NextMenu            ( RetData*      A_data,
                                       int           A_final );
static void      SetOptions          ( AppConfig*    A_myConfig );
static void      ShowOptions         ( AppConfig*    A_myConfig );
static void      ChooseModel         ( AppConfig*    A_myConfig,
                                       RetData*      A_data);
static int       ChangeAheadLevel    ( RetData*      A_data );
static void      ResetQueryData      ( RetData*      A_data,
                                       RetData*      A_list );
static int       GetLevelData        ( char*         A_level,
                                       RetData*      A_data );
static QR_STATUS SelectRecord        ( RetData*      A_data,
                                       RetData*      A_list );
static QR_STATUS SendCFINDMessage    ( RetData*      A_data,
                                       AppConfig*    A_myConfig,
                                       RetData*      A_list );
static QR_STATUS AddToList           ( char*         A_level,
                                       RetData*      A_list,
                                       RetData*      A_data );
static QR_STATUS EmptyList           ( RetData*      A_list );
static QR_STATUS SendCGETMessage     ( RetData*      A_root_data,
                                       AppConfig*    A_myConfig );
static QR_STATUS ProcessCSTORERequest( char*         A_level,
                                       AppConfig*     A_myConfig,
                                       int             A_storeMessageID,
                                       char*         A_serviceName );
static QR_STATUS CancelCGETRQ        ( int*          A_associationID,
                                       char*         A_model );
static QR_STATUS CancelCFINDRQ       ( int*          A_associationID,
                                       char*         A_model );
static MC_STATUS NOEXP_FUNC MessageToFile ( int      A_msgID,
                                       void*         A_CBinformation,
                                       int           A_dataSize,
                                       void*         A_dataBuffer,
                                       int           A_isFirst,
                                       int           A_isLast );
static QR_STATUS GetOptions          ( int           argc,
                                       char**        argv,
                                       AppConfig*    A_myConfig );
static QR_STATUS SetProgramDefaults  ( AppConfig*    A_myConfig,
                                       RetData*      A_root_level_info );
static QR_STATUS BuildCFINDMessage   ( RetData*      A_data, 
                                       int           A_messageid );
static QR_STATUS BuildCGETMessage    ( RetData*      A_data,
                                       int           A_messageid,
                                       AppConfig*    A_myConfig,
                                       char*         A_moveLevel );
static QR_STATUS ReadCFINDMessage    ( RetData*      A_data,
                                       RetData*      A_root_level_info,
                                       int           A_messageid,
                                       AppConfig*    A_myConfig );
static QR_STATUS SetValue            ( int           A_messageid, 
                                       unsigned long A_tag,
                                       char*         A_value,
                                       char*         A_default,
                                       int           A_required );
static QR_STATUS SetNextValue        ( int           A_messageid, 
                                       unsigned long A_tag,
                                       char*         A_value);
static QR_STATUS GetValue            ( int           A_messageid,
                                       unsigned long A_tag,
                                       char*         A_value,
                                       int           A_size, 
                                       char*         A_default );
static void      PrintCFINDResults   ( RetData*      A_list );
static short     OktoMove            ( RetData*      A_data );
static QR_STATUS  WriteToMedia       (
                                       AppConfig*    A_myConfig,
                                       char*         A_filename,
                                       int*          A_msgID,
                                       char*         A_messageType );
static MC_STATUS  NOEXP_FUNC  FileObjToMedia(
                                       char*         A_filename,
                                       void*         A_userInfo,
                                       int           A_dataSize,
                                       void*         A_dataBuffer,
                                       int           A_isFirst,
                                       int           A_isLast );
static QR_STATUS AddGroup2Elements(
                                       AppConfig*    A_myConfig,
                                       TRANSFER_SYNTAX A_transSyntax,
                                       int           A_fileID );
static MC_STATUS NOEXP_FUNC FileMetaInfoVersion(
                                       int           A_msgID,
                                       unsigned long A_tag,
                                       int           A_isFirst,
                                       void*         A_info,
                                       int*          A_dataSize,
                                       void**        A_dataBufferPtr,
                                       int*          A_isLastPtr);


/****************************************************************************
 *
 * NAME
 *    main - Query/Retrieve C-GET user main program
 *
 * SYNOPSIS
 *    qr_get_scu REMOTE_APPLICATION_TITLE [options]
 *
 ****************************************************************************/
int main(int argc, char** argv);
int main(int argc, char** argv)
{
    int           quit = FALSE;
    RetData       root_level_info;
    AppConfig     myConfig;
    RetData       list;
    MC_STATUS     status;
    QR_STATUS     qrStatus;
    PRPL          patient_level;
    PRSTL         study_level;
    PRSL          series_level;
    PRIL          image_level;
    CRFL          frame_level;
    time_t        start_time, current_time;
    int           res = EXIT_SUCCESS;

    application_name = argv[0];

    root_level_info.patient_level = &patient_level;
    root_level_info.study_level = &study_level;
    root_level_info.series_level = &series_level;
    root_level_info.image_level = &image_level;
    root_level_info.frame_level = &frame_level;
    list.numData = 0;
    list.patient_level = NULL;

    printf ( "\n" );
    printf ( "QR_SCU - Query/Retrieve C-GET Service Class User\n" );
    printf ( "(c) 2020 Merge Healthcare\n");
    printf ( "All rights reserved\n\n");


    /*
     * Set the defaults configuration values for the application and
     * parse the command line options 
     */
    memset((void*)&myConfig, 0, sizeof(myConfig));

    qrStatus = SetProgramDefaults ( &myConfig, &root_level_info );
    if ( qrStatus == QR_FAILURE )
        return ( EXIT_FAILURE );

    qrStatus = GetOptions ( argc, argv, &myConfig );
    if ( qrStatus == QR_FAILURE )
        return ( EXIT_FAILURE );

    /*
     * This is for the menu system, other menus depend on where you came from 
     */
    start_time = time( NULL );
    while ( quit != TRUE )
    {
        res = EXIT_SUCCESS;
        switch ( MainMenu( &root_level_info ) )
        {
            case '1':
                if (EditQuery(&root_level_info, &list, &myConfig) == QR_FAILURE)
                    printf("ERROR: editing query\n");
                break;

            case '2':
                ChooseModel( &myConfig, &root_level_info );
                break;

            case '3':
                ShowOptions ( &myConfig );
                break;

            case '4':
                printf("\nSelect an option from this menu\n");
                break;

            case 'q':
            case 'Q':
            case 'x':
            case 'X':
            case '5':
                quit = TRUE;
                break;

            default:
                continue;

        } /* End of switch */

        current_time = time( NULL );
        if ( (current_time - start_time) >= TIME_OUT)
        {
            printf("Test failed: timed out.\n");
            res = EXIT_FAILURE;
            break;
        }
    } /* End of while */


    /* 
     * We're done.  Close everything gracefully and clean up 
     */
    status = MC_Release_Application ( &myConfig.applicationID );
    if ( status != MC_NORMAL_COMPLETION )
        PrintErrorMessage ( "main", "MC_Release_Application", status, NULL );
    
    status = MC_Library_Release ( );
    if ( status != MC_NORMAL_COMPLETION )
        PrintErrorMessage ( "main", "MC_Library_Release", status, NULL );
  
    if(fd_input!=NULL)
        fclose(fd_input);

    (void)EmptyList ( &list ); 
    return ( res );

} /* main() */

/*****************************************************************************
 *
 * NAME
 *    PrintUsage - Prints out the command line options.
 *
 * ARGUMENTS
 *    none.
 *
 * DESCRIPTION
 *    Prints out the options for this program.
 *
 * RETURNS
 *    none.
 *
 * SEE ALSO
 *    none.
 *
 ***************************************************************************/
static void PrintUsage(void)
{
    printf("\n" );
    printf("   <remote_ae_title> The remote application entity to connect\n");
    printf("\n" );
    printf("Options:\n" );
    printf("   -h                Print this help page\n" );
    printf("   -a <ae_title>     Local application entity\n" );
    printf("   -o <timeout>      Time out value\n" );
    printf("   -t <type>         Image Type\n" );
    printf("   -1 <slist>        Storage Service List 1\n" );
    printf("   -2 <slist>        Q/R Service List 2\n" );
    printf("\n" );

} /* PrintUsage() */

/*****************************************************************************
 *
 * NAME
 *    GetOptions - Get the command line options.
 *
 * ARGUMENTS
 *    Aargc         int            Number of command line arguments
 *    Aargv         char **        The command line.
 *    A_myConfig    AppConfig *    Config parameters for AE
 *
 * DESCRIPTION
 *    GetOptions is the routine that parses the command line and sets the
 *    variables associated with each parameter that are contained in the
 *    A_myConfig structure.
 *
 * RETURNS
 *    QR_SUCCESS if the routine finishes properly.
 *    QR_FAILURE if the routine detects an error.
 *
 * SEE ALSO
 *    PrintErrorMessage
 *
 ****************************************************************************/
static QR_STATUS GetOptions ( int Aargc, char **Aargv, AppConfig *A_myConfig )
{
    int          i;
    MC_STATUS    status;
    char         input_file[50];

    if ( Aargc < 2 )
    {
        printf("ERROR: Wrong number of arguments specified\n");
        printf( "Usage: %s <remote_ae_title> [options]\n", Aargv[0] );
        PrintUsage();
        return QR_FAILURE;
    }

    for (i=1; i<Aargc; i++)
    {
        if (strcmp(Aargv[i], "-timing") == 0 && (i+1) < Aargc)
        {
            timing_report_file = fopen(Aargv[++i], "a");
            if (timing_report_file == NULL)
            {
                perror("Unable to open timing report file");
                return(QR_FAILURE);
            }
        }
        else if (Aargv[i][0] == '-' && (i+1) < Aargc)
        {
            switch(Aargv[i][1])
            {
                case 'a':
                    i++;
                    strcpy(A_myConfig->applicationTitle, &(Aargv[i][0]));
                break;
 
                case 'o':
                    A_myConfig->timeOut = atoi(&(Aargv[++i][0]));
                break;
 
                case 't':
                    strcpy(A_myConfig->imageType, &(Aargv[++i][0]));
                break;
 
                case '1':
                    strcpy(A_myConfig->serviceList, &(Aargv[++i][0]));
                break;
                
                case '0':
                    strcpy(input_file, &(Aargv[++i][0]));
                    fd_input=fopen(input_file,"r");
                    break;

                default:
                    printf("ERROR: Invalid argument specified\n");
                    printf("Usage: %s <remote_ae_title> [options]\n", Aargv[0]);
                    PrintUsage();
                    return QR_FAILURE;

            }
        }
        else if (Aargv[i][0] != '-')
            strcpy(A_myConfig->remoteApplicationTitle, &(Aargv[i][0]));
        else
        {
            printf("ERROR: Wrong number of arguments specified\n");
            printf("Usage: %s <remote_ae_title> [options]\n", Aargv[0]);
            PrintUsage();
            return QR_FAILURE;
        }
    }

    if (A_myConfig->remoteApplicationTitle[0] == '\0')
    {
        printf("ERROR: Remote AE not specified\n");
        printf("Usage: %s <remote_ae_title> [options]\n", Aargv[0]);
        PrintUsage();
        return QR_FAILURE;
    }
 
    /*
     * This call MUST be the first call made to the library!!! 
     */
    status = MC_Library_Initialization ( NULL, NULL, NULL );
    if (status != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage (A_myConfig->applicationTitle, "Unable to initialize library", status,NULL);
        return QR_FAILURE;
    }

    /*
     * Register this DICOM application 
     */
    status = MC_Register_Application ( &(A_myConfig->applicationID), A_myConfig->applicationTitle );
    if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( A_myConfig->applicationTitle, "MC_Register_Application", status, NULL );
        return QR_FAILURE;
    }
    /*
     * Set the listen port number for retrievals
     */
    status = MC_Set_Int_Config_Value(TCPIP_LISTEN_PORT, A_myConfig->listenPort);
    if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( A_myConfig->applicationTitle, "MC_Set_Int_Config_Value", status, NULL );
        return QR_FAILURE;
    }
    return QR_SUCCESS;
} /* GetOptions() */

/*****************************************************************************
 *
 * NAME
 *    SetProgramDefaults - Initializes the global variables.
 *
 * ARGUMENTS
 *    A_myConfig           AppConfig *    Config struct for defaults    
 *    A_root_level_info    RetData *      Query level information
 *
 * DESCRIPTION
 *    This routine initializes the global variables to their default values.
 *    These variables are contained in the A_myConfig structure.
 *
 * RETURNS
 *    QR_SUCCESS if the routine finishes properly.
 *    QR_FAILURE if the routine detects an error.
 *
 * SEE ALSO
 *    none.
 *
 ****************************************************************************/
static QR_STATUS SetProgramDefaults ( AppConfig *A_myConfig, RetData *A_root_level_info )
{
    A_myConfig->timeOut = 3000;
    strcpy( A_myConfig->applicationTitle, "MERGE_QR_GET_SCU" );
    strcpy( A_myConfig->serviceList, "GET_SCU_Service_List" );
    strcpy( A_myConfig->imageType, "CT" );
    A_myConfig->maxQueryResponses = 100;

    A_myConfig->remoteApplicationTitle[0] = '\0'; /* required parameter */
    A_myConfig->listenPort = 1115;

    memset((void*)(A_root_level_info->patient_level), 0, sizeof(PRPL));
    memset((void*)(A_root_level_info->study_level), 0, sizeof(PRSTL));
    memset((void*)(A_root_level_info->series_level), 0, sizeof(PRSL));
    memset((void*)(A_root_level_info->image_level), 0, sizeof(PRIL));
    memset((void*)(A_root_level_info->frame_level), 0, sizeof(CRFL));

    strcpy(A_root_level_info->model, PATIENT_STUDY_ONLY_MODEL);
    strcpy(A_root_level_info->level, PATIENT_LEVEL);

    return ( QR_SUCCESS ); 
} /* SetProgramDefaults() */

/*****************************************************************************
 *
 * NAME
 *    MainMenu - Shows the Main Menu options
 *
 * ARGUMENTS
 *    A_data    RetData *         A pointer to data
 *
 * DESCRIPTION
 *    Displays the main menu and waits for the user to select an option
 * 
 * RETURNS
 *    The option selected by the user.
 *
 * SEE ALSO
 *
 ****************************************************************************/
static char MainMenu ( RetData *A_data )
{
    char    user_input[USER_INPUT_LEN];
 
    printf ( "\n" );
    printf ( "-------------------------------| MAIN |---------------------------------\n" );
    printf ( "\n" );

    printf ( "[1] Begin [%s] Query\n", A_data->model );
    printf ( "[2] Choose Model [%s]\n", A_data->model );
    printf ( "[3] Show Options\n" );
    printf ( "[4] Instructions\n");
    printf ( "[5] Exit\n" );

    printf ( "\n" );
    printf ( "==> " );
    fflush ( stdout );
    fgets ( user_input, sizeof(user_input), ((fd_input == NULL) ? stdin : fd_input) );
    fflush ( stdout);

    return ( user_input[0] );
} /* MainMenu() */

/*****************************************************************************
 *
 * NAME
 *    SetOptions - UI to set command line options.
 *
 * ARGUMENTS
 *    A_myConfig    AppConfig *    Program configuration parameters
 *
 * DESCRIPTION
 *    This routine is used by the user to set any command line options
 *    which they may have forgotten to set or change command line options.
 *
 * RETURNS
 *    none.
 *
 * SEE ALSO
 *    none.
 *
 ****************************************************************************/
static void SetOptions ( AppConfig *A_myConfig )
{
    int           done = FALSE;
    char          user_input[USER_INPUT_LEN] = {0}, argument[USER_INPUT_LEN] = {0};
    int           i;
    MC_STATUS     status;

    while ( done != TRUE )
    {
        printf("\n" );
        printf("------------------------------| Set Options |---------------------------\n" );
        printf("\n" );

        printf("[1] Local Application Title:  = [%s]\n", A_myConfig->applicationTitle );
        printf("[2] Service List:             = [%s]\n", A_myConfig->serviceList );
        printf("[3] Image Type:               = [%s]\n", A_myConfig->imageType );
        printf("[4] Time Out:                 = [%d]\n", A_myConfig->timeOut );
        printf("[5] Remote Application Title: = [%s]\n", A_myConfig->remoteApplicationTitle );
        printf("[6] Maximum Query Responses:  = [%d]\n", A_myConfig->maxQueryResponses );
        printf("[7] Local Listen Port:        = [%d]\n", A_myConfig->listenPort );
        printf("\n" );
        printf("[R] Return to main\n" );
        printf("\n" );
        printf("Enter one of the above numbers followed by the required\n" );
        printf("input for that field.  For example, if you would like to\n" );
        printf("set the timeout, enter the following:\n" );
        printf("\n" );
        printf("   \"1 3000\".\n" );
        printf("\n\n" );
        printf("EDIT> " );
        fflush (stdout);
        fgets ( user_input, sizeof(user_input), fd_input==NULL ? stdin : fd_input );
        fflush (stdout);

        /*
         * Clear the newline characters from the end of the input data so
         * the checks below work properly.
         */
        for (i = (int)strlen(user_input)-1; ((i >= 0) && (user_input[i]==' '||user_input[i]=='\r'||user_input[i]=='\n')); i--)
            user_input[i] = '\0';

        if ( user_input[2] != '\0' )
            strcpy ( argument, &user_input[2] );

        switch ( user_input[0] )
        {
            case '1':
                status = MC_Release_Application( &(A_myConfig)->applicationID );
                if ( status != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage ( "main", "MC_Release_Application", status, NULL );
                    return;
                }

                /*
                 * This is the new application title
                 */
                strcpy( A_myConfig->applicationTitle, argument );

                /*
                 * Register this DICOM application
                 */
                status = MC_Register_Application ( &(A_myConfig->applicationID), A_myConfig->applicationTitle );
                if ( status != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage ( A_myConfig->applicationTitle, "MC_Register_Application", status, NULL );
                    return;
                }
                break;

            case '2':
                strcpy ( A_myConfig->serviceList, argument );
                break;

            case '3':
                strcpy ( A_myConfig->imageType, argument );
                break;

            case '4':
                A_myConfig->timeOut = atoi ( argument );
                break;

            case '5':
                strcpy ( A_myConfig->remoteApplicationTitle, argument );
                break;

            case '6':
                A_myConfig->maxQueryResponses = atoi (argument);
                break;

            case '7':
                A_myConfig->listenPort = atoi (argument);
                status = MC_Set_Int_Config_Value(TCPIP_LISTEN_PORT, A_myConfig->listenPort);
                if ( status != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage ( A_myConfig->applicationTitle, "MC_Set_Int_Config_Value", status, NULL );
                    return;
                }
                break;

            case 'r':
            case 'R':
                done = TRUE;
                break;

            default:
                continue;

        } /* end of switch */
    } /* end of while */

    return;
} /* SetOptions() */


/*****************************************************************************
 *
 * NAME                 
 *    ShowOptions - Displays the command line options.
 *
 * ARGUMENTS
 *    A_myConfig    AppConfig *    Configuration parameters for program
 *
 * DESCRIPTION
 *    This routine displays the command line options for the user.
 *
 * RETURNS
 *    none.
 *
 * SEE ALSO
 *    none.
 *
 ****************************************************************************/
static void ShowOptions ( AppConfig *A_myConfig )
{
    char         user_input[USER_INPUT_LEN];

    printf("\n" );
    printf("-----------------------------| Show Options |---------------------------\n" );
    printf("\n" );
    printf("Options:\n" );
    printf("   Local Application Title:  %s\n", A_myConfig->applicationTitle );
    printf("   Service List:             %s\n", A_myConfig->serviceList );
    printf("   Image Type:               %s\n", A_myConfig->imageType );
    printf("   Time Out:                 %d\n", A_myConfig->timeOut );
    printf("   Remote Application Title: %s\n", A_myConfig->remoteApplicationTitle );
    printf("   Maximum Query Responses:  %d\n", A_myConfig->maxQueryResponses );
    printf("   Local Listen Port:        %d\n", A_myConfig->listenPort );

    printf("\n\nDo you wish to change any options?\n\n");
    printf("==> ");
    fflush (stdout);
    fgets ( user_input, sizeof(user_input), fd_input==NULL ? stdin : fd_input );
    fflush (stdout);

    if (user_input[0] == 'Y' || user_input[0] == 'y')
        SetOptions( A_myConfig );

    return;
} /* ShowOptions() */

/*****************************************************************************
 *
 * NAME
 *    ChooseModel - Allows user to choose model 
 *
 * ARGUMENTS
 *    A_myConfig    AppConfig *    Configuration params for the program
 *    A_data        RetData *      Pointer to model information
 *
 * DESCRIPTION
 *    This function allows the user to choose the query retrieve model to 
 *    be used.
 *
 * RETURNS
 *    none.
 *
 * SEE ALSO
 *    none.
 *
 ****************************************************************************/
static void  ChooseModel( AppConfig *A_myConfig, RetData *A_data)
{
    static char    S_prefix[] = "ChooseModel";
    MC_STATUS      status;
    char           user_input[USER_INPUT_LEN];
    int            patientStudyOnly = FALSE;
    int            patientRoot = FALSE;
    int            studyRoot = FALSE;
    int            compositeInstanceNoBulk = FALSE;
    int            compositeInstanceRoot = FALSE;
    ServiceInfo    serviceInfo;
        
    printf("Opening association to determine which services %s supports...\n", A_myConfig->remoteApplicationTitle);

    status = MC_Open_Association ( A_myConfig->applicationID, &(A_myConfig->associationID), A_myConfig->remoteApplicationTitle, NULL, NULL, NULL);
    if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "MC_Open_Association", status, NULL );
        return; 
    }

    status = MC_Get_First_Acceptable_Service(A_myConfig->associationID, 
        &serviceInfo); 
    if (status == MC_NORMAL_COMPLETION)
    {
        while (status == MC_NORMAL_COMPLETION)
        {
            if (!strcmp(serviceInfo.ServiceName, Services.PATIENT_STUDY_ONLY_QR_FIND))
                patientStudyOnly = TRUE;
            else if (!strcmp(serviceInfo.ServiceName, Services.PATIENT_ROOT_QR_FIND))
                patientRoot = TRUE;
            else if (!strcmp(serviceInfo.ServiceName, Services.STUDY_ROOT_QR_FIND))
                studyRoot = TRUE;
            else if (!strcmp(serviceInfo.ServiceName, Services.COMPOSITE_INSTANCE_ROOT_RET_GET))
                compositeInstanceRoot = TRUE;
            else if (!strcmp(serviceInfo.ServiceName, Services.COMPOSITE_INST_RET_NO_BULK_GET))
                compositeInstanceNoBulk = TRUE;

            status = MC_Get_Next_Acceptable_Service(A_myConfig->associationID, &serviceInfo);
        }
    }
    else if( status == MC_END_OF_LIST )
    {
        PrintErrorMessage(S_prefix,"MC_Get_First_Acceptable_Service unnexpectedly returned", status, NULL);
        MC_Abort_Association(&(A_myConfig->associationID));
        return;
    }
    else
    {
        PrintErrorMessage(S_prefix,"MC_Get_First_Acceptable_Service failed", status, NULL);
        MC_Abort_Association(&(A_myConfig->associationID));
        return;
    } 

    status = MC_Close_Association ( &(A_myConfig->associationID) );
    if (status != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage ( S_prefix, "MC_Close_Association", status, NULL );
        return;
    }

    printf ( "\n" );
    printf ( "-----------| Models supported by %s |------------\n", 
             A_myConfig->remoteApplicationTitle);
    printf ( "\n" );
    if (patientRoot)
        printf ( "[P] Patient Root\n");
    if (studyRoot)
        printf ( "[S] Study Root\n");
    if (patientStudyOnly)
        printf ( "[O] Patient/Study Only\n");
    if (compositeInstanceRoot)
        printf ( "[C] Composite Instance Root Retrieve\n");
    if (compositeInstanceNoBulk)
        printf ( "[W] Composite Instance Without Bulk Data\n");
    

    printf ( "\n" );

    printf ( "==> " );
    fflush (stdout);
    fgets ( user_input, sizeof(user_input), fd_input==NULL ? stdin : fd_input );
    fflush (stdout);

    switch (user_input[0])
    {
        case 'P':
        case 'p':
            if (patientRoot)
            {
                strcpy(A_data->model, PATIENT_MODEL);
                strcpy(A_data->level, PATIENT_LEVEL);
            }
            break;
        case 'S':
        case 's':
            if (studyRoot)
            {
                strcpy(A_data->model, STUDY_MODEL);
                strcpy(A_data->level, STUDY_LEVEL);
            }
            break;
        case 'O':
        case 'o':
            if (patientStudyOnly)
            {
                strcpy(A_data->model, PATIENT_STUDY_ONLY_MODEL);
                strcpy(A_data->level, PATIENT_LEVEL);
            }
            break;
        case 'C':
        case 'c':
            if (compositeInstanceRoot)
            {
                strcpy(A_data->model, COMPOSITE_MODEL);
                strcpy(A_data->level, PATIENT_LEVEL);
            }
            break;
        case 'W':
        case 'w':
            if (compositeInstanceNoBulk)
            {
                strcpy(A_data->model, COMPOSITE_NO_BULK_MODEL);
                strcpy(A_data->level, PATIENT_LEVEL);
            }
            break;
        default:
            printf("Invalid option: %c",user_input[0]);
            break;
    }

    return;
} /* ChooseModel() */

/*****************************************************************************
 *
 * NAME
 *    EditQuery - Allows the user to filter throught the matching responses
 *                returned from a C-FIND-RQ query.
 *
 * ARGUMENTS
 *    A_root_level_info    RetData *      Current Query information
 *    A_list               RetData *      List of data returned from the Query
 *    A_myConfig           AppConfig *    Program Config values
 *
 * DESCRIPTION
 *    This is the main control routine used for conducting a query.  It is
 *    used when conducting queries for each of the models.  It will traverse
 *    through the various levels for a query and allow the user to do a get
 *    request at each of the levels.  It is meant to be organized in such a 
 *    way that a GUI interface can be used in place of this function with
 *    the remainder of the functionality still working.
 *
 * RETURNS
 *    QR_STATUS according to appropriate errors
 *
 * SEE ALSO
 *    GetLevelData
 *    ResetQueryData
 *    CFINDOption
 *    NextMenu
 *    PrintCFINDResults
 *    SelectRecord
 *    ChangeAheadLevel    
 *
 ****************************************************************************/
static QR_STATUS EditQuery (RetData* A_root_level_info, RetData* A_list, AppConfig* A_myConfig )
{
    QR_STATUS qrStatus;
    int       done = FALSE;
    void     *stime = NULL;
    double    duration;
    int       value;

    /*
     * Get input from the user to modify the initial query
     */
    if (GetLevelData (A_root_level_info->level,A_root_level_info))
    {
        ResetQueryData ( A_root_level_info, A_list );
        return ( QR_SUCCESS );
    }
    stime = GetIntervalStart();

    /*
     * Send the C-FIND Message to see if there are any matches to
     * the initial input.
     */
    qrStatus = CFINDOption( A_myConfig, A_root_level_info, A_list);
    if (qrStatus == QR_FAILURE )
        return ( qrStatus );

    duration = GetIntervalElapsed(stime);
    if(fd_input==NULL)
        printf("\nElapsed time of Find Operation: %.3f seconds\n", duration);

    if (timing_report_file != NULL)
    {
        fprintf(timing_report_file, "%s\tC-FIND:root\t%.3f\n", application_name, duration);
    }
    while ( done != TRUE )
    {
        /*
         * NextMenu displays the appropriate menu based on
         * our level and find status.
         */
        value = NextMenu (A_root_level_info, FALSE);
        if ( value == '1' )
        {
            /*
             * Select a record you want to continue to query on 
             */
            if ( A_list->numData == 0 )
            {
                printf("There are no records available to select.\n");
            }
            else
            {
                if (!strncmp (A_root_level_info->level, A_list->level, 
                    sizeof(A_list->level)))
                {
                    PrintCFINDResults ( A_list );

                    qrStatus =  SelectRecord ( A_root_level_info,  A_list );
                    
                    /*
                     * If we selected a record we will give a menu which will ask if we want to move the record 
                     */
                    if (qrStatus == QR_SUCCESS )
                    {
                        value = NextMenu(A_root_level_info, TRUE);
                        if ( value == '1' )
                        {
                            /*
                             * For the Composite Instance Models the C-GET query is only allowed on the IMAGE level 
                             */
                            if(strncmp(A_root_level_info->level, IMAGE_LEVEL, sizeof(IMAGE_LEVEL)-1) &&
                            (!strncmp (A_root_level_info->model, COMPOSITE_MODEL, sizeof( COMPOSITE_MODEL ) - 1 ) ||
                            !strncmp (A_root_level_info->model, COMPOSITE_NO_BULK_MODEL, sizeof( COMPOSITE_NO_BULK_MODEL ) - 1 )))
                            {
                                /*
                                 * We choose to go to the next level so we check to
                                 *  see if there is a next level to go to
                                 */
                                if ( ChangeAheadLevel ( A_root_level_info ))
                                {
                                    double duration;
                                    stime = GetIntervalStart();

                                    /*
                                     * Send the C-FIND Message
                                     */
                                    qrStatus = CFINDOption( A_myConfig, A_root_level_info,  A_list);
                                    if (qrStatus == QR_FAILURE )
                                        return ( qrStatus );

                                    duration = GetIntervalElapsed(stime);
                                    if(fd_input==NULL)
                                        printf("\nElapsed time of Find Operation: %.3f seconds\n", duration);

                                    if (timing_report_file != NULL)
                                    {
                                        fprintf(timing_report_file, "%s\tC-FIND:1\t%.3f\n", application_name, duration);
                                    }
                                    continue;
                                }
                            }

                            /*
                             * We chose to do a Get request
                             */
                            qrStatus = CGETOption( A_myConfig, A_root_level_info );
                            if (qrStatus != QR_SUCCESS )
                            {
                                ResetQueryData (A_root_level_info, A_list);
                                return ( qrStatus );
                            }
                        }
                        else if ( value != 'q' && value != 'Q' )
                        {
                            /*
                             * Composite Instance Root Retrieve Get needs to specify frame list
                             */
                            if ( value == '2' &&
                                !strncmp(A_root_level_info->level, IMAGE_LEVEL, sizeof(IMAGE_LEVEL)-1) &&
                                !strncmp (A_root_level_info->model, COMPOSITE_MODEL, sizeof( COMPOSITE_MODEL ) - 1 ))
                            {
                                /* edit frame list */
                                strncpy(A_root_level_info->level, FRAME_LEVEL, sizeof(FRAME_LEVEL) - 1);
                                if (!GetLevelData (A_root_level_info->level, A_root_level_info))
                                {
                                    /*
                                     * Perfrom Get request
                                     */
                                    qrStatus = CGETOption( A_myConfig, A_root_level_info );
                                    if (qrStatus != QR_SUCCESS )
                                    {
                                        ResetQueryData (A_root_level_info, A_list);
                                        return ( qrStatus );
                                    }
                                }
                            }
                            else
                            {
                                /*
                                 * We choose to go to the next level so we check to
                                 *  see if there is a next level to go to
                                 */
                                if ( ChangeAheadLevel ( A_root_level_info ))
                                {
                                    double duration;
                                    stime = GetIntervalStart();

                                    /*
                                     * Send the C-FIND Message
                                     */
                                    qrStatus = CFINDOption( A_myConfig, A_root_level_info,  A_list);
                                    if (qrStatus == QR_FAILURE )
                                        return ( qrStatus );

                                    duration = GetIntervalElapsed(stime);
                                    if(fd_input==NULL)
                                        printf("\nElapsed time of Find Operation: %.3f seconds\n", duration);

                                    if (timing_report_file != NULL)
                                    {
                                        fprintf(timing_report_file, "%s\tC-FIND:q\t%.3f\n", application_name, duration);
                                    }
                                    continue;
                                }
                            }
                        }

                        /*
                         * There was no level to go to, so we are going to start
                         *  over again, from the beginning
                         */
                        ResetQueryData (A_root_level_info, A_list);
                        done = TRUE;
                    }
                }
                else
                    printf("There are none available.\n");
            }
        }
        /* 
         * This was a choice to quit, so we do
         */
        else if ( value == 'q' || value == 'Q' )
        {
            ResetQueryData ( A_root_level_info, A_list );
            done = TRUE;
        }
    } /* while */

    return ( QR_SUCCESS );
} /* EditQuery() */

/*****************************************************************************
 *
 * NAME
 *    NextMenu - Shows the Next Menu options
 *
 * ARGUMENTS
 *    A_data     RetData *   A pointer to data
 *    A_final    int         A TRUE or FALSE value indicating whether the 
 *                            final menu or not
 *
 * DESCRIPTION
 *    Gives user main menu.
 *
 * RETURNS
 *    Option selected via user input
 *
 * SEE ALSO
 *
 ****************************************************************************/
static char NextMenu ( RetData *A_data, int A_final )
{
    char    user_input[USER_INPUT_LEN];

    printf ( "\n" );
    printf("------------------------------------------------------------------------\n");
    printf ( "                           Model:  %s\n",  A_data->model );
    printf ( "                           Level:  %s\n", A_data->level );
    printf("------------------------------------------------------------------------\n");

    if ( !strncmp(A_data->level, PATIENT_LEVEL, sizeof(PATIENT_LEVEL)-1) )
    {
        if (A_data->patient_level->retrieveAETitle[0] == '\0')
        {
            printf("%60.80s\n", "OFFLINE"); 
            printf("%50.59s%20.20s\n", "File ID:",  A_data->patient_level->med_file_id);
            printf("%50.59s%20.20s\n", "File UID:", A_data->patient_level->med_file_uid);
        }
        else
            printf("%60.80s\n", "ONLINE"); 
    }
    else if ( !strncmp(A_data->level, STUDY_LEVEL, sizeof(STUDY_LEVEL)-1))
    {
        if (A_data->study_level->retrieveAETitle[0] == '\0')
        {
            printf("%60.80s\n", "OFFLINE"); 
            printf("%50.59s%20.20s\n", "File ID:",  A_data->study_level->med_file_id);
            printf("%50.59s%20.20s\n", "File UID:", A_data->study_level->med_file_uid);
        }
        else
            printf("%60.80s\n", "ONLINE"); 
    }
    else if ( !strncmp(A_data->level, SERIES_LEVEL, sizeof(SERIES_LEVEL)-1))
    {
        if (A_data->series_level->retrieveAETitle[0] == '\0')
        {
            printf("%60.80s\n", "OFFLINE"); 
            printf("%50.59s%20.20s\n", "File ID:",  A_data->series_level->med_file_id);
            printf("%50.59s%20.20s\n", "File UID:", A_data->series_level->med_file_uid);
        }
        else
            printf("%60.80s\n", "ONLINE"); 
    }
    else if ( !strncmp(A_data->level, IMAGE_LEVEL, sizeof(IMAGE_LEVEL)-1) )
    {
        if (A_data->image_level->retrieveAETitle[0] == '\0')
        {
            printf("%60.80s\n", "OFFLINE"); 
            printf("%50.59s%20.20s\n", "File ID:",  A_data->image_level->med_file_id);
            printf("%50.59s%20.20s\n", "File UID:", A_data->image_level->med_file_uid);
        }
        else
            printf("%60.80s\n", "ONLINE"); 
    }

    if ( !strncmp ( A_data->model, STUDY_MODEL, sizeof( STUDY_MODEL ) - 1 ) )
    {
        printf("Patient's Name      = [%s]\n", A_data->study_level->patient_name);
        printf("Patient ID          = [%s]\n", A_data->study_level->patient_id);
    }
    else 
    {
        printf("Patient's Name      = [%s]\n", A_data->patient_level->patient_name);
        printf("Patient ID          = [%s]\n", A_data->patient_level->patient_id);
    }

    printf("Study Instance UID  = [%s]\n", A_data->study_level->study_inst_uid);
    printf("Series Instance UID = [%s]\n", A_data->series_level->series_inst_uid);
    printf("SOP Instance UID    = [%s]\n", A_data->image_level->sop_inst_uid);
    printf ( "\n" );

    if ( !A_final )
    {
        printf ( "[1] SELECT a [%s] from the query result.\n", strtok ( A_data->level, "_" ) );
    }
    /*
     * For the Composite Instance Models the C-GET query is only allowed on the IMAGE level 
     */
    else if(strncmp(A_data->level, IMAGE_LEVEL, sizeof(IMAGE_LEVEL)-1) &&
            (!strncmp ( A_data->model, COMPOSITE_MODEL, sizeof( COMPOSITE_MODEL ) - 1 ) ||
            !strncmp ( A_data->model, COMPOSITE_NO_BULK_MODEL, sizeof( COMPOSITE_NO_BULK_MODEL ) - 1 ))
           )
    {
        printf ( "[1] Continue with the query.\n");
    }
    else
    {
       printf ( "[1] GET the [%s].\n", strtok ( A_data->level, "_") );
       if(!strncmp(A_data->level, IMAGE_LEVEL, sizeof(IMAGE_LEVEL)-1) && !strncmp ( A_data->model, COMPOSITE_MODEL, sizeof( COMPOSITE_MODEL ) - 1 ))
            printf ( "[2] retrieve FRAME(s).\n");
       else
            printf ( "[2] Continue with the query.\n");
    }

    printf ( "[Q] Quit this Query.\n" );
    printf ( "\n" );
    printf ( "QUERY> " );
    fflush (stdout);
    fgets ( user_input, sizeof(user_input), fd_input==NULL ? stdin : fd_input );
    fflush (stdout);

    return ( user_input[0] );
} /* NextMenu() */

/*****************************************************************************
 *
 * NAME
 *    ChangeAheadLevel - Changes to next level in Query 
 *
 * ARGUMENTS
 *    A_data    RetData *    Data need to determine the next level to go to 
 *
 * DESCRIPTION
 *    Changes the LEVEL in the root_level_info structure to some safe value
 *    based on the model for the current query.
 *
 * RETURNS
 *   TRUE or FALSE as to whether or not there is another level
 *
 * SEE ALSO
 *    none.
 *
 ****************************************************************************/
static int ChangeAheadLevel(RetData *A_data)
{
    /*
     * For the Composite Instance models start with the C-FIND query at the 
     * Patient level first and then query down the hierarhy.
     */
    if(!strncmp(A_data->model, PATIENT_MODEL, sizeof(PATIENT_MODEL) - 1) ||
       !strncmp(A_data->model, COMPOSITE_MODEL, sizeof(COMPOSITE_MODEL) - 1) ||
       !strncmp(A_data->model, COMPOSITE_NO_BULK_MODEL, sizeof(COMPOSITE_NO_BULK_MODEL) - 1))       
    {
        if(!strncmp(A_data->level, PATIENT_LEVEL, sizeof(PATIENT_LEVEL) - 1))
            strncpy(A_data->level, STUDY_LEVEL, sizeof(STUDY_LEVEL));
        else if(!strncmp(A_data->level, STUDY_LEVEL, sizeof(STUDY_LEVEL) - 1)) 
            strncpy(A_data->level, SERIES_LEVEL, sizeof(SERIES_LEVEL));
        else if(!strncmp(A_data->level, SERIES_LEVEL, sizeof(SERIES_LEVEL) - 1))
            strncpy(A_data->level, IMAGE_LEVEL, sizeof(IMAGE_LEVEL));
        else
            return ( FALSE );
    }
    else if(!strncmp(A_data->model, STUDY_MODEL, sizeof(STUDY_MODEL) - 1))
    {
        if(!strncmp(A_data->level, STUDY_LEVEL, sizeof(STUDY_LEVEL) - 1))
            strncpy(A_data->level, SERIES_LEVEL, sizeof(SERIES_LEVEL));
        else if(!strncmp(A_data->level, SERIES_LEVEL, sizeof(SERIES_LEVEL) - 1))
            strncpy(A_data->level, IMAGE_LEVEL, sizeof(IMAGE_LEVEL));
        else
            return ( FALSE );
    }
    else /* patient/study only */
    {
        if(!strncmp(A_data->level, PATIENT_LEVEL, sizeof(PATIENT_LEVEL) - 1))
            strncpy(A_data->level, STUDY_LEVEL, sizeof(STUDY_LEVEL)); 
        else
           return ( FALSE );
    }
    return ( TRUE );
} /* ChangeAheadLevel() */

/*****************************************************************************
 *
 * NAME
 *    ResetQueryData - Changes to next level in Query
 *
 * ARGUMENTS
 *    A_data    RetData *      Current Query information
 *    A_list    RetData *      Data returned from the Query
 *
 * DESCRIPTION
 *    Takes you back to the beginning clearing out the list of query 
 *    results and zeroing out the root_level_structure   
 *
 * RETURNS
 *    nothing.
 *
 * SEE ALSO
 *    none.
 *
 ****************************************************************************/
static void ResetQueryData( RetData *A_data, RetData *A_list )
{
    if (EmptyList ( A_list ) != QR_SUCCESS)
        printf("ERROR: freeing query list\n");

    memset((void*)(A_data->patient_level), 0, sizeof(PRPL));
    memset((void*)(A_data->study_level), 0, sizeof(PRSTL));
    memset((void*)(A_data->series_level), 0, sizeof(PRSL));
    memset((void*)(A_data->image_level), 0, sizeof(PRIL));

    if(!strncmp(A_data->model, PATIENT_MODEL, sizeof(PATIENT_MODEL) - 1))
    {
        strncpy(A_data->level, PATIENT_LEVEL, sizeof(PATIENT_LEVEL));
    }
    else if(!strncmp(A_data->model, STUDY_MODEL, sizeof(STUDY_MODEL) - 1))
    {
        strncpy(A_data->level, STUDY_LEVEL, sizeof(STUDY_LEVEL));
    }
    else if(!strncmp(A_data->model, PATIENT_STUDY_ONLY_MODEL, sizeof(PATIENT_STUDY_ONLY_MODEL)-1)) 
    {
        strncpy(A_data->level, PATIENT_LEVEL, sizeof(PATIENT_LEVEL));
    }
    else if(!strncmp(A_data->model, COMPOSITE_MODEL, sizeof(COMPOSITE_MODEL)-1) ||
            !strncmp(A_data->model, COMPOSITE_NO_BULK_MODEL, sizeof(COMPOSITE_NO_BULK_MODEL)-1)) 
    {
        strncpy(A_data->level, PATIENT_LEVEL, sizeof(PATIENT_LEVEL));
    }
} /* ResetQueryData() */

/*****************************************************************************
 *
 * NAME
 *    GetLevelData - Allows user to enter level data 
 *
 * ARGUMENTS
 *    A_level    char *       String containing the level 
 *    A_list     RetData *    Data returned from the Query
 *
 * DESCRIPTION
 *    This function allows the user to enter data for a level
 *
 * RETURNS
 *    none
 *
 * SEE ALSO
 *    none.
 *
 ****************************************************************************/
static int GetLevelData(char *A_level, RetData *A_data)
{
    char user_input[USER_INPUT_LEN];
    int choice = 0;
    int i;

    do
    {
        printf ( "\n" );

        if(!strncmp(A_level, PATIENT_LEVEL, sizeof(PATIENT_LEVEL) - 1))
        {
            printf (
                "****************| Patient Level Editing |****************\n");
            printf ( "\n" );

            printf ( "[1] Patient ID          = [%s]\n", A_data->patient_level->patient_id);
            printf ( "[2] Patient Name        = [%s]\n", A_data->patient_level->patient_name);
            choice = 0;
        }
        else if(!strncmp(A_level, SERIES_LEVEL, sizeof(SERIES_LEVEL) - 1))
        {
            printf (
                "****************| Series Level Editing |*****************\n");
            printf ( "\n" );

            printf ( "[1] Modality            = [%s]\n", A_data->series_level->modality);
            printf ( "[2] Series Number       = [%s]\n", A_data->series_level->series_num);
            printf ( "[3] Series Instance UID = [%s]\n", A_data->series_level->series_inst_uid);
            printf ( "[4] Study Instance UID  = [%s]\n", A_data->study_level->study_inst_uid);
            if (strncmp(A_data->model, STUDY_MODEL, sizeof(STUDY_MODEL)))
                printf ( "[5] Patient ID          = [%s]\n", A_data->patient_level->patient_id);
            choice = 1;
        }
        else if(!strncmp(A_level, IMAGE_LEVEL, sizeof(IMAGE_LEVEL) - 1))
        {
            printf ("****************| Image Level Editing |******************\n");
            printf ( "\n" );

            printf ( "[1] Image Number        = [%s]\n", A_data->image_level->image_num);
            printf ( "[2] SOP Instance UID    = [%s]\n", A_data->image_level->sop_inst_uid);
            printf ( "[3] Study Instance UID  = [%s]\n", A_data->study_level->study_inst_uid);
            printf ( "[4] Series Instance UID = [%s]\n", A_data->series_level->series_inst_uid);
            if (strncmp(A_data->model, STUDY_MODEL, sizeof(STUDY_MODEL)))
                printf ( "[5] Patient ID          = [%s]\n", A_data->patient_level->patient_id);
            choice = 2;
        }
        else if(!strncmp(A_level, STUDY_LEVEL, sizeof(STUDY_LEVEL) - 1))
        {
            printf ("*****************| Study Level Editing |*****************\n");
            printf ( "\n" );

            printf ( "[1] Study Date          = [%s]\n", A_data->study_level->study_date);
            printf ( "[2] Study Time          = [%s]\n", A_data->study_level->study_time);
            printf ( "[3] Accession Number    = [%s]\n", A_data->study_level->accession_num);
            printf ( "[4] Study ID            = [%s]\n", A_data->study_level->study_id);
            printf ( "[5] Study Instance UID  = [%s]\n", A_data->study_level->study_inst_uid);
            printf ( "[6] Patient ID          = [%s]\n", A_data->patient_level->patient_id);
            if (!strncmp(A_data->model, STUDY_MODEL, sizeof(STUDY_MODEL)))  
                printf ( "[7] Patient Name        = [%s]\n", A_data->patient_level->patient_name);
            choice = 3;
        }
        else if(!strncmp(A_level, FRAME_LEVEL, sizeof(FRAME_LEVEL) - 1))
        {
            printf ("*****************| Frame Level Editing |*****************\n");
            printf ( "\n" );

            printf ( "[1] Frame List         = [%s]\n", A_data->frame_level->frame_list);
            choice = 4;
        }

        printf( "[D] Done Editing\n" );
        printf( "[Q] Quit this Query\n" );

        printf ( "EDIT> " );
        fflush (stdout);
        fgets ( user_input, sizeof(user_input), fd_input==NULL ? stdin : fd_input );
        fflush (stdout);

        /*
         * Clear the newline characters from the end of the input data so
         * the checks below work properly.
         */
        for (i = (int)strlen(user_input)-1; i >= 0 && (user_input[i]==' '||user_input[i]=='\r'||user_input[i]=='\n'); i--)
            user_input[i] = '\0';

        switch(user_input[0])
        {
            case '1':
                switch (choice)
                {
                    case 0:
                        strcpy(A_data->patient_level->patient_id, &user_input[2]);
                    break;
                    case 1:
                        strcpy(A_data->series_level->modality, &user_input[2]);
                    break;
                    case 2:
                        strcpy(A_data->image_level->image_num, &user_input[2]);
                    break;
                    case 3:
                        strcpy(A_data->study_level->study_date, &user_input[2]);
                    break;
                    case 4:
                        strcpy(A_data->frame_level->frame_list, &user_input[2]);
                    break;
                    default:
                        printf("Invalid choice");
                        break;
                }
            break;

            case '2':
                switch (choice)
                {
                    case 0:
                        strcpy(A_data->patient_level->patient_name, &user_input[2]);
                    break;
                    case 1:
                        strcpy(A_data->series_level->series_num, &user_input[2]);
                    break;
                    case 2:
                        strcpy(A_data->image_level->sop_inst_uid, &user_input[2]);
                    break;
                    case 3:
                        strcpy(A_data->study_level->study_time, &user_input[2]);
                    break;
                    default:
                        printf("Invalid choice");
                        break;
                }
            break;

            case '3':
                switch (choice)
                {
                    case 1:
                        strcpy(A_data->series_level->series_inst_uid, &user_input[2]);
                    break;
                    case 2:
                        strcpy(A_data->study_level->study_inst_uid, &user_input[2]);
                    break;
                    case 3:
                        strcpy(A_data->study_level->accession_num, &user_input[2]);
                    break;
                    default:
                        printf("Invalid choice");
                        break;
                }
            break;

            case '4':
                switch (choice)
                {
                    case 1:
                        strcpy(A_data->study_level->study_inst_uid, &user_input[2]);
                    break;
                    case 2:
                        strcpy(A_data->series_level->series_inst_uid, &user_input[2]);
                    break;
                    case 3:
                        strcpy(A_data->study_level->study_id, &user_input[2]);
                    break;
                }
            break;

            case '5':
                switch (choice)
                {
                    case 1:
                        strcpy(A_data->patient_level->patient_id, &user_input[2]);
                    break;
                    case 2:
                        strcpy(A_data->patient_level->patient_id, &user_input[2]);
                    break;
                    case 3:
                        strcpy(A_data->study_level->study_inst_uid,
                            &user_input[2]);
                    break;
                }
            break;

            case '6':
                if(choice == 3)
                {
                    strcpy(A_data->patient_level->patient_id, &user_input[2]);
                }
            break;

            case '7':
                if(choice == 3)
                {
                    strcpy(A_data->patient_level->patient_name, &user_input[2]);
                }
            break;

            case 'Q':
            case 'q':
                return ( TRUE );

        }  /* end switch */
    } while ( user_input[0] != 'D' && user_input[0] != 'd' );

    return ( FALSE );
} /* GetLevelData() */

/*****************************************************************************
 *
 * NAME
 *    SelectRecord - Selects a record to query on
 *
 * ARGUMENTS
 *    A_data       RetData *    A pointer to data
 *    A_list       RetData *    A pointer to data returned from association
 *
 * DESCRIPTION
 *    Allows the selection of a record to continue to query on.  
 *  
 * RETURNS
 *    QR_SUCCESS
 *    QR_FAILURE
 *
 * SEE ALSO
 *
 ****************************************************************************/
static QR_STATUS SelectRecord ( RetData *A_data, RetData *A_list )
{
    char   user_input[USER_INPUT_LEN];
    int    i;
    PRPL   *prpl;
    PRSTL  *prstl;
    PRSL   *prsl;
    PRIL   *pril;

    printf("\nWhich one, there are %d.\n", A_list->numData);
    printf("==> ");
    fflush (stdout);
    fgets ( user_input, sizeof(user_input), fd_input==NULL ? stdin : fd_input );
    fflush (stdout);

    if (( atoi(user_input) > 0 ) && (atoi(user_input) <= A_list->numData ))
    {
        if ( !strncmp(A_data->level,PATIENT_LEVEL, sizeof(PATIENT_LEVEL)-1) )
        {
            prpl = A_list->patient_level;
            for ( i = 1; i < atoi(user_input); i++)
                prpl = prpl->next;

            memcpy ( (void*) A_data->patient_level, (void*) prpl, sizeof(PRPL) );
        }

        else if ( !strncmp(A_data->level, STUDY_LEVEL, sizeof(STUDY_LEVEL)-1))
        {
            prstl = A_list->study_level;
            for ( i = 1; i < atoi(user_input); i++)
                prstl = prstl->next;

            memcpy ( (void*) A_data->study_level, (void*) prstl, sizeof(PRSTL) );
        }

        else if ( !strncmp(A_data->level,SERIES_LEVEL,sizeof(SERIES_LEVEL)-1))
        {
            prsl = A_list->series_level;
            for ( i = 1; i < atoi(user_input); i++)
                prsl = prsl->next;

            memcpy ( (void*) A_data->series_level, (void*) prsl, sizeof(PRSL) ); 
        }

        else if ( !strncmp(A_data->level,IMAGE_LEVEL, sizeof(IMAGE_LEVEL)-1) )
        {
            pril = A_list->image_level;
            for ( i = 1; i < atoi(user_input); i++)
                pril = pril->next;

            memcpy ( (void*)A_data->image_level, (void*) pril, sizeof(PRIL) );
        }

        if (EmptyList ( A_list ) != QR_SUCCESS)
            printf("ERROR: freeing record list\n");
    }
    else
        return ( QR_FAILURE );

    return ( QR_SUCCESS );
} /* SelectRecord() */

/*****************************************************************************
 *
 * NAME
 *    AddToList - Add query records to list of query results
 *
 * ARGUMENTS
 *    A_level    char *       A pointer to the type of query 
 *    A_list     RetData *    A pointer to the list of data returned
 *    A_data     RetData *    A pointer to the new data to add to list
 *
 * DESCRIPTION
 *    Adds an element to the list of query results.
 *
 * RETURNS
 *    QR_SUCCESS if the routine finishes properly.
 *    QR_FAILURE if the routine detects an error.
 *
 * SEE ALSO
 *    PrintErrorMessage
 *
 ****************************************************************************/
static QR_STATUS AddToList ( char *A_level, RetData *A_list,  RetData *A_data )
{
    PRPL           *prpl;
    PRSTL          *prstl;
    PRSL           *prsl;
    PRIL           *pril;
    static char    S_prefix[] = "AddToList";

    strcpy ( A_list->level, A_level );
    strcpy ( A_list->model, A_data->model );
    if ( !strncmp ( A_level, PATIENT_LEVEL, sizeof( PATIENT_LEVEL ) - 1 ) )
    {
        prpl = (void*) malloc (sizeof(PRPL));
        if ( prpl == NULL )
        {
            PrintErrorMessage ( S_prefix, "malloc", -1, "Error allocating memory" );
            return ( QR_FAILURE );
        } 
        memcpy( (void*) prpl, (void*) A_data->patient_level, sizeof(PRPL) );
        prpl->next = A_list->patient_level;
        A_list->patient_level = prpl;
    }

    else if ( !strncmp ( A_level, STUDY_LEVEL, sizeof( STUDY_LEVEL ) - 1 ) )
    {
        prstl = (void*) malloc (sizeof(PRSTL));
        if ( prstl == NULL )
        {
            PrintErrorMessage ( S_prefix, "malloc", -1, "Error allocating memory" );
            return ( QR_FAILURE );
        }
        memcpy( (void*) prstl, (void*) A_data->study_level, sizeof(PRSTL) );
        prstl->next = A_list->study_level;
        A_list->study_level = prstl;
    }

    else if ( !strncmp ( A_level, SERIES_LEVEL, sizeof( SERIES_LEVEL ) - 1 ) )
    {
        prsl = (void*) malloc (sizeof(PRSL));
        if ( prsl == NULL )
        {
            PrintErrorMessage ( S_prefix, "malloc", -1, "Error allocating memory" );
            return ( QR_FAILURE );
        }
        memcpy( (void*) prsl, (void*) A_data->series_level, sizeof(PRSL) );
        prsl->next = A_list->series_level;
        A_list->series_level = prsl;
    }

    else if ( !strncmp ( A_level, IMAGE_LEVEL, sizeof( IMAGE_LEVEL ) -1 ) )
    {
        pril = (void*) malloc (sizeof(PRIL));
        if ( pril == NULL )
        {
            PrintErrorMessage ( S_prefix, "malloc", -1, "Error allocating memory" );
            return ( QR_FAILURE );
        }
        memcpy( (void*) pril, (void*) A_data->image_level, sizeof(PRIL) );
        pril->next = A_list->image_level;
        A_list->image_level = pril;
    }

    A_list->numData = A_list->numData + 1;

    return ( QR_SUCCESS );
} /* AddToList() */

/*****************************************************************************
 *
 * NAME
 *    EmptyList - empties the list of query results
 *
 * ARGUMENTS
 *    A_list     RetData *    A pointer to the list of data returned
 *
 * DESCRIPTION
 *    Frees the list of query results copied into these data structures
 *    from C-FIND-RSP messages.
 *
 * RETURNS
 *    QR_SUCCESS if the routine finishes properly.
 *    QR_FAILURE if the routine detects an error.
 *
 * SEE ALSO
 *    PrintErrorMessage
 *
 ****************************************************************************/
static QR_STATUS EmptyList ( RetData *A_list )
{
    int     i;
    char    *level;
    PRPL    *prpl;
    PRSTL   *prstl;
    PRSL    *prsl;
    PRIL    *pril;

    level = A_list->level;
    
    for (i=0; i<A_list->numData; i++)
    {
        if (!strncmp ( level, PATIENT_LEVEL, sizeof( PATIENT_LEVEL )-1 ) )
        {
            prpl = A_list->patient_level;
            if ( prpl != NULL )
            {
                A_list->patient_level = prpl->next;
                free ( prpl );
            }
        }
        else if (!strncmp ( level, STUDY_LEVEL, sizeof( STUDY_LEVEL )-1 ) )
        {
            prstl = A_list->study_level;
            if ( prstl != NULL )
            {
                A_list->study_level = prstl->next;
                free ( prstl );
            }
        }
        else if (!strncmp (level, SERIES_LEVEL, sizeof( SERIES_LEVEL )-1 ) )
        {
            prsl = A_list->series_level;
            if ( prsl != NULL )
            {
                A_list->series_level = prsl->next;
                free ( prsl );
            }
        }
        else if (!strncmp ( level, IMAGE_LEVEL, sizeof( IMAGE_LEVEL ) -1 ) )
        {
            pril = A_list->image_level;
            if ( pril != NULL )
            {
                A_list->image_level = pril->next;
                free ( pril );
            }
        }
    }
    A_list->numData = 0;
    A_list->patient_level = NULL;

    return ( QR_SUCCESS );
} /* EmptyList() */

/*****************************************************************************
 *
 * NAME
 *    OktoMove - Ask user if ok to move base on CFIND results
 *
 * ARGUEMENTS
 *    A_data    RetData *    Data to be moved, prompt user with it 
 *
 * DESCRIPTION
 *    This function asks user if ok to move SOP Instance based on CFIND.
 *    
 *
 * RETURNS
 *    1 for TRUE or 0 for FALSE
 *
 * SEE ALSO
 *    none.
 *
 ****************************************************************************/
static short OktoMove(RetData *A_data)
{
    char user_input[USER_INPUT_LEN];

    printf("\nOK to get ");
    if(!strncmp(A_data->level, IMAGE_LEVEL, sizeof(IMAGE_LEVEL) - 1) ||
        !strncmp(A_data->level, FRAME_LEVEL, sizeof(FRAME_LEVEL) - 1))
    {
        printf("Image Number = [%s]\t", A_data->image_level->image_num);
        if (!strncmp (A_data->model, STUDY_MODEL, sizeof(STUDY_MODEL) - 1))
            printf("Patinet ID = [%s]\n", A_data->study_level->patient_id);
        else
            printf("Patinet ID = [%s]\n", A_data->patient_level->patient_id);
    }
    else if(!strncmp(A_data->level, SERIES_LEVEL, sizeof(SERIES_LEVEL) - 1))
    {
        printf("Series Number = [%s]\n", A_data->series_level->series_num);
    }
    else if (!strncmp(A_data->level, PATIENT_LEVEL, sizeof(PATIENT_LEVEL) - 1))
    {
        printf("Patient ID = [%s]\n", A_data->patient_level->patient_id);
    }

    else /* study level */
    {
        printf("Study ID = [%s]\n", A_data->study_level->study_id);
    }

    printf ( "==> " );
    fflush (stdout);
    fgets ( user_input, sizeof(user_input), fd_input==NULL ? stdin : fd_input );
    fflush (stdout);

    if(user_input[0] == 'Y' || user_input[0] == 'y')
        return 1;
    else
        return 0;

} /* OktoMove() */

/*****************************************************************************
*
 * NAME
 *    CFINDOption - Starts the C-FIND Process
 *
 * ARGUMENTS
 *    A_myConfig           AppConfig *    Program Config values
 *    A_root_level_info    RetData *      Current Query information
 *    A_list               RetData *      Data returned from the Query  
 *
 * DESCRIPTION
 *    Option used for the C-FIND
 *
 * RETURNS
 *    QR_STATUS set according to the error
 *
 * SEE ALSO
 *    MC_Close_Association
 *    MC_Open_Association
 *    SendCFINDMessage    
 *
 ****************************************************************************/
static QR_STATUS CFINDOption ( AppConfig *A_myConfig, RetData *A_root_level_info, RetData *A_list )
{
    MC_STATUS      status;
    QR_STATUS      qrStatus;
    static char    S_prefix[] = "CFINDOption";

    status = MC_Open_Association(A_myConfig->applicationID, &(A_myConfig->associationID), A_myConfig->remoteApplicationTitle, NULL, NULL, NULL);
    if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "MC_Open_Association",
           status, NULL );
        return ( QR_FAILURE );
    }
 
    /* Make sure there is nothing left in the list before starting */
    if (EmptyList ( A_list ) != QR_SUCCESS)
        printf("ERROR: freeing found list\n");

    printf ( "%s: Sending the C-FIND request.\n", S_prefix );
    qrStatus = SendCFINDMessage ( A_root_level_info, A_myConfig, A_list );
    if (qrStatus != QR_SUCCESS)
    {
        PrintErrorMessage ( S_prefix, "SendCFINDMessage", -1, "Error returned, continueing." );
    }
    
    status = MC_Close_Association ( &(A_myConfig->associationID) );
    if (status != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage ( S_prefix, "MC_Close_Association", status, NULL );
        return ( QR_FAILURE );
    }    
    return ( qrStatus );
} /* CFINDOption() */

/*****************************************************************************
 *
 * NAME
 *    SendCFINDMessage - Send a C-FIND message to the remote application
 *
 * ARGUMENTS
 *    A_data            RetData *      A pointer to input data for the FIND
 *    A_myConfig        AppConfig *    A pointer to configuration data
 *    A_list            RetData *      A pointer to data returned from assoc
 *
 * DESCRIPTION
 *    SendCFINDMessage sends a C-FIND message to the remote application.
 *    After opening a new message and filling in all required fields,
 *    SendCFINDMessage sends the newly created and populated message by
 *    calling MC_Send_Request_Message.  The function then waits for 
 *    responses from the remote application.  When it gets the responses,
 *    the routine continues to put the Patient IDs in an array until a
 *    C_FIND_SUCCESS is received.
 *
 * RETURNS
 *    QR_SUCCESS if the routine finishes properly.
 *    QR_FAILURE if the routine detects an error.
 *
 * SEE ALSO
 *    PrintErrorMessage
 *    MC_Free_Message
 *    MC_Get_Value_To_UInt
 *    MC_Get_Value_To_String
 *    MC_Open_Message
 *    MC_Read_Message
 *    MC_Set_Value_From_String
 *    MC_Set_Value_To_NULL
 *    CancelCFINDRQ
 *
 ****************************************************************************/
static QR_STATUS SendCFINDMessage ( RetData*   A_data, AppConfig *A_myConfig, RetData *A_list )
{
    static char          S_prefix[] = "SendCFINDMessage";

    static int           S_once = FALSE;
    int                  done = FALSE;
    QR_STATUS            qrStatus;
    MC_COMMAND           command;
    MC_STATUS            status;
    int                  messageID, responseMessageID;
    char                 *serviceName;
    char                 model[SERVICENAME_LEN+1] = {0};
    unsigned int         response;
    RetData              data;
    PRPL                 patient_level;
    PRSTL                study_level;
    PRSL                 series_level;
    PRIL                 image_level;

    memcpy((void*)&data, (void*)A_data, sizeof(RetData));

    /*
     * Fill in some local data structures used to specify the C-FIND-RQ
     * messages. This is done so that the input data is not modified.
     */
    if (!strncmp ( A_data->level, PATIENT_LEVEL, sizeof( PATIENT_LEVEL )-1 ))
    {
        memcpy((void*)&patient_level, (void*)A_data->patient_level, sizeof(PRPL));
        data.patient_level = &patient_level;    
    }
    else if (!strncmp ( A_data->level, STUDY_LEVEL, sizeof( STUDY_LEVEL )-1 ))
    {
        memcpy((void*)&study_level, (void*)A_data->study_level, sizeof(PRSTL));
        data.study_level = &study_level;
    }
    else if (!strncmp ( A_data->level, SERIES_LEVEL, sizeof(SERIES_LEVEL)-1 ))
    {
        memcpy((void*)&series_level, (void*)(A_data->series_level), sizeof(PRSL));
        data.series_level = &series_level;
    }
    else if ( !strncmp ( A_data->level, IMAGE_LEVEL, sizeof( IMAGE_LEVEL ) -1 ))
    {
        memcpy((void*)&image_level, (void*)(A_data->image_level), sizeof(PRIL));
        data.image_level = &image_level;
    }

    /*
     * For the Composite Instance models use PATIENT_MODEL_QR_FIND query to find the required data to retrieve.
     */
    if(!strncmp ( data.model, COMPOSITE_MODEL, sizeof( COMPOSITE_MODEL ) -1 ) ||
       !strncmp ( data.model, COMPOSITE_NO_BULK_MODEL, sizeof( COMPOSITE_NO_BULK_MODEL ) -1 ))
        strcpy(model, PATIENT_MODEL);
    else
        strcpy(model, data.model);
    strcat(model, "_QR_FIND");

    /*
     * Open a new message 
     */
    status = MC_Open_Message ( &messageID, model, C_FIND_RQ );     
    if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "MC_Open_Message", status, NULL );
        return ( QR_FAILURE );
    }

    /*
     * Fill in the message with the required fields depending on the level the find is being sent at 
     */
    qrStatus = BuildCFINDMessage(&data, messageID);
    if ( qrStatus != QR_SUCCESS )
    {
        MC_Free_Message ( &responseMessageID );
        return ( qrStatus );
    }

    /*
     * Validate and list the message
     */
    ValMessage      (messageID, "C-FIND-RQ");
    WriteToListFile (messageID, "cfindrq.msg");

    /*
     * Send off the message 
     */
    status = MC_Send_Request_Message ( A_myConfig->associationID, messageID );
    if ( status != MC_NORMAL_COMPLETION )
    {
        MC_Free_Message ( &messageID );
        PrintErrorMessage ( S_prefix, "MC_Send_Request_Message", status, NULL );
        return ( QR_FAILURE );
    }

    status = MC_Free_Message ( &messageID );
    if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "MC_Free_Message", status, NULL );
        return ( QR_FAILURE );
    }

    /* 
     * A single response message is sent for each
     * match to the find request.  Wait for all of these
     * response messages here.  This loop is exited when
     * the status contained in a response message
     * is equal to a failure, or C_FIND_SUCCESS.
     */
    while (done != TRUE)
    {
        status = MC_Read_Message ( A_myConfig->associationID, A_myConfig->timeOut, &responseMessageID, &serviceName, &command );
        if ( status == MC_TIMEOUT )
        {
            printf("Timed out in MC_Read_Message.  Calling again.\n");
            continue;
        }
        else if ( status != MC_NORMAL_COMPLETION )
        {
            PrintErrorMessage ( S_prefix, "MC_Read_Message", status, NULL );
            return ( QR_FAILURE );
        }

        /* 
         * The status of the find response is contained in
         * the DICOM group 0 elements.  Retreive this status
         * and examine it here.
         */
        status = MC_Get_Value_To_UInt ( responseMessageID, MC_ATT_STATUS, &response );
        if ( status != MC_NORMAL_COMPLETION )
        {
            MC_Free_Message ( &responseMessageID );
            PrintErrorMessage ( S_prefix, "MC_Get_Value_To_UInt", status, NULL );
            return ( QR_FAILURE );
        }                                             

        /* 
         * If you are thinking that this error section could be better handled
         *  using a switch statement, you are right.  However under the OS9000
         *  compiler it did not work as a switch.  The solution was to write
         *  it as an if-else.
         */
        if ( response == C_FIND_SUCCESS )
        {
            /*
             * If we get a success, we are finished 
             */
            printf ( "%s: Response is C_FIND_SUCCESS\n", S_prefix );
            S_once = FALSE;
            done = TRUE;
        }
        else if ( response == C_FIND_CANCEL_REQUEST_RECEIVED ) 
        {
            /* 
             * If we get a cancel,  we are finished 
             */
            printf ("%s: Response C_FIND_CANCEL_REQUEST_RECEIVED\n", S_prefix );
            S_once = FALSE;
            done = TRUE;
        }
        else if ( response == C_FIND_PENDING_NO_OPTIONAL_KEY_SUPPORT || response == C_FIND_PENDING )
        {
            if ( response == C_FIND_PENDING_NO_OPTIONAL_KEY_SUPPORT )
            {
                printf ( "%s: C_FIND_PENDING_NO_OPTIONAL_KEY_SUPPORT\n", S_prefix );
                printf ( "\t\twas received...\n" );
            }
            /*
             * This means we got a real message with data 
             */
    
            /*
             * Hold off on Validation of CFIND until we know it is not  
             *   a C_FIND_SUCCESS since C_FIND_SUCCESS will not validate 
             *   because it is an empty message.                         
             */
            ValMessage      (responseMessageID, "C-FIND-RSP");
            WriteToListFile (responseMessageID, "cfindrsp.msg");

            qrStatus = ReadCFINDMessage(&data, A_data, responseMessageID, A_myConfig); 
            if ( qrStatus == QR_FAILURE )
            {
                MC_Free_Message(&responseMessageID);
                return ( QR_FAILURE );
            }

            if(A_list->numData < A_myConfig->maxQueryResponses )
            {
                /* 
                 * Add it to the list of responses to the query
                 */
                qrStatus = AddToList ( A_data->level, A_list, &data );
                if ( qrStatus == QR_FAILURE )
                {
                    MC_Free_Message(&responseMessageID);
                    return ( QR_FAILURE );
                }
            }
            else if ( S_once != TRUE ) 
            {  
                /* 
                 * We have filled up our buffer of C-FIND-RSP messages we
                 * can receive, we now send a cancel to the server to stop
                 * sending these response messages.  Note that because of
                 * a delay in when the SCP receives the C-CANCEL, several
                 * responses may continue to come in.
                 */
                if (CancelCFINDRQ(&A_myConfig->associationID, model) == QR_FAILURE)
                    printf("ERROR: sending C-FIND-RSP,  C-CANCEL\n");
                S_once = TRUE;
            }
        }
        else
        {
            /* 
             * Some other kind of error message 
             */
            printf("%s: Response is Unknown Error:  %X.\n", S_prefix, response);
            S_once = FALSE;
            done = TRUE;
        }

        /*
         * Free the valid response message and continue 
         * waiting for another response.
         */
        status = MC_Free_Message ( &responseMessageID );
        if ( status != MC_NORMAL_COMPLETION )
        {
            PrintErrorMessage ( S_prefix, "MC_Free_Message", status, NULL );
            return ( QR_FAILURE );
        }
    } /* while(done != TRUE) */

    printf ("Found %d matches.\n", A_list->numData );
    return ( QR_SUCCESS );
} /* SendCFINDMessage() */ 

/*****************************************************************************
 *
 * NAME
 *    CGETOption - Starts the C-GET Process
 *
 * ARGUMENTS
 *    A_myConfig           AppConfig *    Program Config values
 *    A_rootInfo           RetData *      Current Query information
 *
 * DESCRIPTION
 *    This funciton handles sending a C-GET-RQ message.  The association is
 *    opened and the C-GET-RQ message is sent based on user input
 *    and the data contained in the A_root_level_info structure.
 *
 * RETURNS
 *    QR_STATUS according to appropriate error conditions
 *
 * SEE ALSO
 *    MC_Open_Association
 *    SendCGETMessage
 *    MC_Abort_Association
 *    MC_Close_Association    
 *
 ****************************************************************************/
static QR_STATUS CGETOption ( AppConfig *A_myConfig,
                               RetData *A_rootInfo )
{
    MC_STATUS     status;
    QR_STATUS     qrStatus;
    static char   S_prefix[] = "CGETOption";
    char          *retrieveAE = "";


    if ( !strncmp(A_rootInfo->level,PATIENT_LEVEL, sizeof(PATIENT_LEVEL)-1) )
        retrieveAE = A_rootInfo->patient_level->retrieveAETitle;
    else if ( !strncmp(A_rootInfo->level, STUDY_LEVEL, sizeof(STUDY_LEVEL)-1))
        retrieveAE = A_rootInfo->study_level->retrieveAETitle;
    else if ( !strncmp(A_rootInfo->level,SERIES_LEVEL,sizeof(SERIES_LEVEL)-1))
        retrieveAE = A_rootInfo->series_level->retrieveAETitle;
    else if ( !strncmp(A_rootInfo->level,IMAGE_LEVEL, sizeof(IMAGE_LEVEL)-1) ||
              !strncmp(A_rootInfo->level,FRAME_LEVEL, sizeof(FRAME_LEVEL)-1))
        retrieveAE = A_rootInfo->image_level->retrieveAETitle;

    if (!strcmp(retrieveAE, ""))
    {
        printf("The location of the image was not given by the archive,\nso it is either on offline storage, or its location is not known.\n");
        return QR_OFFLINE;
    }

    /* 
     * Establish an association 
     */
    status = MC_Open_Association ( A_myConfig->applicationID, &(A_myConfig->associationID), retrieveAE, NULL, NULL, NULL );
    if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "MC_Open_Association", status, NULL );
        return ( QR_FAILURE );
    }

    /*
     * Send the C-GET Message 
     */
    printf ( "%s: Sending the C-GET request.\n", S_prefix );

    qrStatus = SendCGETMessage( A_rootInfo, A_myConfig );
    if ( qrStatus != QR_SUCCESS )
    {
        MC_Abort_Association ( &(A_myConfig->associationID) );
        PrintErrorMessage ( S_prefix, "SendCGETMessage", -1, "SendCGETMessage returned QR_FAILURE" );
        return ( qrStatus );
    }
    
    status = MC_Close_Association ( &(A_myConfig->associationID) ); 
    if (status != MC_NORMAL_COMPLETION)
    {
        PrintErrorMessage ( S_prefix, "MC_Close_Association", status, NULL );
    }

    return ( QR_SUCCESS );
} /* CGETOption() */

/*****************************************************************************
 *
 * NAME
 *    SendCGETMessage - Processes a C-GET message
 *
 * ARGUMENTS
 *    A_root_data       RetData *      A pointer to data structure with info.
 *    A_myConfig        AppConfig *    A pointer to configuration data.
 *
 * DESCRIPTION
 *    SendCGETMessage handles a C-GET message. It also handles the incoming 
 *    C-STORE requests from the SCP.
 *
 *    For every selected record in the A_root_data structure, a C-GET 
 *    request message is generated and sent to the remote application.  Once 
 *    this happens, three events can occur: 1) a message from the GET 
 *    association may arrive, 2) activity may occur on the same association 
 *    such as the C-STORE-RQ messages being received.  
 *    When a C-GET-RSP  message is received with a status
 *    signifying the get has completed or failed, the routine is exited.
 *    Note that the destination AE title used for the C-GET-RQ is the same as 
 *    this application.
 *
 * RETURNS
 *    QR_SUCCESS if the routine finishes properly.
 *    QR_FAILURE if the routine detects an error.
 *
 * SEE ALSO
 *    PrintErrorMessage
 *    ProcessCSTORERequest
 *    MC_Abort_Association
 *    MC_Accept_Association
 *    MC_Free_Message
 *    MC_Open_Message
 *    MC_Read_Message
 *    MC_Reject_Association
 *    MC_Send_Request_Message
 *    MC_Set_Value_From_String
 *    MC_Wait_For_Association
 *
 ****************************************************************************/
static QR_STATUS SendCGETMessage ( RetData *A_root_data, AppConfig *A_myConfig )
{
    static char           S_prefix[] = "SendCGEtMessage";

    QR_STATUS             qrStatus;
    MC_COMMAND            command;
    MC_STATUS             status;
    int                   messageID, receivedMessageID, associationID = A_myConfig->associationID, continueLoop = TRUE;
    char                 *serviceName;
    char                  model[SERVICENAME_LEN+1] = {0};
    unsigned int          response;
    void                 *stime = NULL;
    double                duration;
    RetData              *tmpData;
 
    /*
     * There is nothing left in the list so we are gonna take the 
     * one that was selected.  Its contents are in the A_root_data var
     */
    tmpData = A_root_data;
    
    if ( OktoMove( tmpData ) )
    {
        stime = GetIntervalStart();       /* lets see how long this takes */

        /*
         * Open a new message at the proper level, depending on where the get request was done.
         */
        if(!strncmp(A_root_data->model, COMPOSITE_MODEL, sizeof(COMPOSITE_MODEL) - 1))
        {
            strcpy(model, "COMPOSITE_INSTANCE_ROOT_RET"); 
            strcat(model, "_GET");
        }
        else if(!strncmp(A_root_data->model, COMPOSITE_NO_BULK_MODEL, sizeof(COMPOSITE_NO_BULK_MODEL) - 1))
        {
            strcpy(model, "COMPOSITE_INST_RET_NO_BULK"); 
            strcat(model, "_GET");
        }
        else
        {
            strcpy(model, A_root_data->model); 
            strcat(model, "_QR_GET");
        }
        status = MC_Open_Message( &messageID, model, C_GET_RQ );
        if ( status != MC_NORMAL_COMPLETION )
        {
            PrintErrorMessage ( S_prefix, "MC_Open_Message", status, NULL );
            return ( QR_FAILURE );
        }

        /*
         * Build the C-GET-RQ message with required fields based
         * on the level where the get is being requested.
         */
        qrStatus = BuildCGETMessage( tmpData, messageID, A_myConfig, A_root_data->level );
        if (qrStatus != QR_SUCCESS)
        {
            MC_Free_Message ( &messageID );
            PrintErrorMessage ( S_prefix, "BuildCGETMessage", -1, "Failure" );
            return ( qrStatus );
        }
        
        /*
         * Validate and list the message
         */
        ValMessage       (messageID, "C-GET-RQ");
        WriteToListFile (messageID, "cgetrq.msg");

        /*
         * Send off the message 
         */
        status = MC_Send_Request_Message ( associationID, messageID );
        if ( status != MC_NORMAL_COMPLETION )
        {
            MC_Free_Message ( &messageID );
            PrintErrorMessage ( S_prefix, "MC_Send_Request_Message", status, NULL );
            return ( QR_FAILURE );
        }

        status = MC_Free_Message ( &messageID );
        if (status != MC_NORMAL_COMPLETION )
        {
            PrintErrorMessage ( S_prefix, "MC_Free_Message", status, NULL );
        }

        /*
         * Wait for the C-GET-RSP messages and activity over the storage associatin such as messages received.
         */
        continueLoop = TRUE;
        while ( continueLoop == TRUE )
        {
            status = MC_Read_Message ( associationID, 0, &receivedMessageID, &serviceName, &command );

            switch ( status )
            {
                case MC_TIMEOUT:
                    /*
                     * Nothing received, now we should poll the store association
                     */
                    break;
                case MC_NORMAL_COMPLETION:

                    if(command == C_STORE_RQ)
                    {
                        qrStatus = ProcessCSTORERequest(A_root_data->level, A_myConfig, receivedMessageID, serviceName);
                        continueLoop = TRUE;
                        break;
                    }
                    else if(command == C_GET_RSP)
                    {
                        ValMessage      (receivedMessageID, "C-GET-RSP");
                        WriteToListFile (receivedMessageID, "cgetrsp.msg");

                        status = MC_Get_Value_To_UInt(receivedMessageID, MC_ATT_STATUS, &response);
                        if (status != MC_NORMAL_COMPLETION)
                            PrintErrorMessage(S_prefix, "MC_Get_Value_To_UInt", status, NULL );
        
                        status = MC_Free_Message ( &receivedMessageID );
                        if (status != MC_NORMAL_COMPLETION)
                            PrintErrorMessage(S_prefix, "MC_Free_Message", status, NULL);
                    
                        /*
                         * Check the status returned in the response message.
                        */
                        if ( response == C_GET_SUCCESS_NO_FAILURES_OR_WARNINGS )
                        {
                            /*
                             * The move has completed!
                             */
                            continueLoop = FALSE;
                        }
                        else if( response != C_GET_PENDING_MORE_SUB_OPERATIONS )
                        {
                            PrintErrorMessage(S_prefix, "Response for C_GET", -1, "Error in CGET operation");
                            MC_Free_Message ( &receivedMessageID );
                            return( QR_FAILURE );
                        } 
                    }
                    break;
                default:
                    MC_Free_Message ( &receivedMessageID );
                    PrintErrorMessage ( S_prefix, "MC_Read_Message for get response", status, NULL );
                    return ( QR_FAILURE );

            } /* switch status of get response read message */
        } /* continueLoop == TRUE */

        duration = GetIntervalElapsed(stime);
        if(fd_input==NULL)
            printf("\nElapsed time of Get Operation: %.3f seconds\n", duration);

        if (timing_report_file != NULL)
        {
            fprintf(timing_report_file, "%s\tC-GET\t%.3f\n", application_name, duration);
        }
    } /* if OktoMove  */

    return ( QR_SUCCESS );
} /* SendCGETMessage() */

/*****************************************************************************
 *
 * NAME
 *    ProcessCSTORERequest - Processes a C-Store Request on the C-GET's request
 *    association
 *
 * ARGUMENTS
 *    A_level           char *           String containing the level.
 *    A_myConfig        AppConfig *      A pointer to configuration data.
 *    A_storeMessageID  int              C-STORE message id
 *    A_serviceName     char*            The service name

 * DESCRIPTION
 *    ProcessCSTORERequest contains the code for a simple storage 
 *    service class SCP.  It is intended to handle the C-STORE operation
 *    conducted by the Q/R SCP after a C-GET-RQ message has been sent.
 *    This routine is not intended to be a "final" solution for a 
 *    Storage SCP when doing Q/R.  A typical application would have 
 *    another thread or process acting as the storage SCP when a move is 
 *    requested apart from the Q/R application.  
 *
 *    This routine will only allow a single association at a time.  
 *    It is meant to be polled repeatedly to handle any activity over this
 *    association.
 *
 * RETURNS
 *    QR_SUCCESS if the routine finishes properly.
 *    QR_FAILURE if the routine detects an error.
 *
 * SEE ALSO
 *    ValMessage
 *    WriteToListFile
 *    MC_Message_To_Stream
 *    CancelCGETRQ       
 *    MC_Open_Message
 *    MC_Send_Response_Message
 *    MC_Free_Message
 *    PrintErrorMessage
 *
 ****************************************************************************/

static QR_STATUS ProcessCSTORERequest( char *A_level, AppConfig *A_myConfig, int A_storeMessageID, char *A_serviceName )
{
    static int            S_numImages = -1;
    MC_STATUS             status;
    QR_STATUS             qrStatus;
    int                   responseMessageID;
    char                  fileName[256] = {0};
    char                  listFileName[256] = {0};
 
    static char           S_prefix[] = "ProcessCSTORERequest";

    /*
     * If we do not have an association open, return from this function,
     * or else process the C-STORE request we received for this association.
     */
    if (A_myConfig->associationID == -1)
        return ( QR_SUCCESS );

    /* We have successfully received a C-STORE message.  It will now be saved to disk. */
    S_numImages++;

    /* Make a file name to hold the image */
    sprintf ( fileName, "QR_%d", S_numImages );
    sprintf ( listFileName, "QR_%d", S_numImages );
    strcat ( fileName, ".img" );
    strcat ( listFileName, ".msg" );

    ValMessage      (A_storeMessageID, "C-STORE-RQ");
    WriteToListFile (A_storeMessageID, listFileName );

    /* Stream the message into a file */
    printf ( "%s: Writing message to file.\n", S_prefix );

    qrStatus = WriteToMedia(A_myConfig, fileName, &A_storeMessageID, A_serviceName);
    if(qrStatus != QR_SUCCESS)
    {
        PrintErrorMessage ( S_prefix, "WriteToMedia", qrStatus, NULL );
        return ( QR_FAILURE );
    }

    /* Send a successful response */
    status = MC_Open_Message ( &responseMessageID, A_serviceName, C_STORE_RSP );
    if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "MC_Open_Message", status, NULL );
        return ( QR_FAILURE );
    }

    status = MC_Send_Response_Message( A_myConfig->associationID, C_STORE_SUCCESS, responseMessageID );
    if ( status != MC_NORMAL_COMPLETION )
    {
        MC_Free_Message ( &responseMessageID );
        PrintErrorMessage ( S_prefix, "MC_Send_Response_Message",
            status, NULL );
        return ( QR_FAILURE );
    }

    status = MC_Free_Message ( &responseMessageID );
    if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "MC_Free_Message for C-STORE-RSP", status, NULL );
        return ( QR_FAILURE );
    }
    
    return ( QR_SUCCESS ); 
} /* ProcessCSTORERequest() */

/*****************************************************************************
 *
 * NAME
 *    CancelCGETRQ - Cancel a C-GET request.
 *
 * ARGUMENTS
 *    A_associationID    int *     Association ID of AE getting the CANCEL
 *    A_model            char *    Model name for which we are canceling
 *
 * DESCRIPTION
 *    Sends a C_CANCEL_GET_RQ message to a remote AE
 *
 * RETURNS
 *    QR_STATUS with appropriate error for current condition
 *
 * SEE ALSO
 *    MC_Open_Message
 *    MC_Send_Request_Message
 *    MC_Free_Message
 *
 ****************************************************************************/
static QR_STATUS CancelCGETRQ ( int *A_associationID, char *A_model )
{
    static char   S_prefix[]="CancelCGETRQ";
    int           status;
    int           messageID;

    status = MC_Open_Message ( &messageID, A_model, C_CANCEL_GET_RQ );
    if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "MC_Open_Message", status, NULL );
        return ( QR_FAILURE );
    }

    ValMessage      ( messageID, "C-CANCEL-GET-RQ" );        
    WriteToListFile( messageID, "ccancelq.msg" );

    status = MC_Send_Request_Message( *A_associationID, messageID );
    if ( status != MC_NORMAL_COMPLETION )
    {
        MC_Free_Message( &messageID );
        PrintErrorMessage( S_prefix, "MC_Send_Response_Message", status, NULL );
        return ( QR_FAILURE );
    }

    status = MC_Free_Message( &messageID );
    if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "MC_Free_Message", status, NULL );
        return ( QR_FAILURE );
    }

    return ( QR_SUCCESS );
} /* CancelCGETRQ() */

/*****************************************************************************
 *
 * NAME
 *    CancelCFINDRQ - Cancel a C-FIND request.
 *
 * ARGUMENTS
 *    A_associationID    int *     Association ID of AE getting the CANCEL
 *    A_model            char *    Model name for which we are canceling
 *
 * DESCRIPTION
 *    Sends a C_FIND_CANCEL_RQ message to a remote AE
 *
 * RETURNS
 *    QR_STATUS with appropriate error for current condition
 *
 * SEE ALSO
 *    MC_Open_Message
 *    MC_Send_Request_Message
 *    MC_Free_Message
 *
 ****************************************************************************/
static QR_STATUS CancelCFINDRQ ( int *A_associationID, char *A_model )
{
    int           status;
    int           messageID;
    static char   S_prefix[]="CancelCFINDRQ";

    status = MC_Open_Message ( &messageID, A_model, C_CANCEL_FIND_RQ );
    if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "MC_Open_Message", status, NULL );
        return ( QR_FAILURE );
    }

    ValMessage     ( messageID, "C-CANCEL-FIND-RQ" );        
    WriteToListFile( messageID, "ccancelq.msg" );

    status = MC_Send_Request_Message ( *A_associationID, messageID );
    if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(S_prefix, "MC_Send_Response_Message", status, NULL);
        return ( QR_FAILURE );
    }

    status = MC_Free_Message ( &messageID );
    if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "MC_Free_Message", status, NULL );
        return ( QR_FAILURE );
    }

    return ( QR_SUCCESS );
} /* CancelCFINDRQ() */

/*****************************************************************************
 *
 * NAME
 *    BuildCFINDMessage - Builds CFIND message  
 *
 * ARGUMENTS
 *    A_data         RetData *    Current Query information
 *    A_messageid    int          Id of message to build
 *
 * DESCRIPTION
 *    This function builds a CFIND message based on user input
 *
 * RETURN
 *    QR_SUCCESS or QR_FAILURE
 *
 * SEE ALSO
 *    none.
 *
 ****************************************************************************/
static QR_STATUS BuildCFINDMessage(RetData *A_data, int A_messageid)
{
    MC_STATUS status;
    static char S_prefix[] = "BuildCFINDMessage";

    status = MC_Set_Value_From_String(A_messageid, MC_ATT_QUERY_RETRIEVE_LEVEL, A_data->level );
    if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "QUERY_RETRIEVE_LEVEL, MC_Set_Value_From_String", status, NULL );
        return ( QR_FAILURE );
    }
    
    /*
     * Set values that you want returned from a query to NULL or they will
     *  not be sent back.  A wild card "*" will work for some values, but
     *  not all of them.
     */
    printf("We have a(n) %s Model, %s Level Query.\n", A_data->model, A_data->level);

    /* Fields needed for PATIENT_LEVEL (Patient Root, Patient/Study Root) */
    if (!strncmp(A_data->level, PATIENT_LEVEL, sizeof(PATIENT_LEVEL) - 1))
    {
        if ( SetValue ( A_messageid, MC_ATT_PATIENTS_NAME, A_data->patient_level->patient_name, NULL, FALSE) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( SetValue ( A_messageid, MC_ATT_PATIENT_ID, A_data->patient_level->patient_id, "*", FALSE) == QR_FAILURE )
            return ( QR_FAILURE );
    } /* end of PATIENT_LEVEL */

    /* Fields needed for STUDY_LEVEL (All Models) */
    else if (!strncmp(A_data->level, STUDY_LEVEL, sizeof(STUDY_LEVEL) - 1))
    {
        if ( SetValue ( A_messageid, MC_ATT_STUDY_DATE, A_data->study_level->study_date, NULL, FALSE) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( SetValue ( A_messageid, MC_ATT_STUDY_TIME,
            A_data->study_level->study_time, NULL, FALSE) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( SetValue ( A_messageid, MC_ATT_ACCESSION_NUMBER,
            A_data->study_level->accession_num, NULL, FALSE) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( SetValue ( A_messageid, MC_ATT_STUDY_ID,
            A_data->study_level->study_id, NULL, FALSE) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( SetValue ( A_messageid, MC_ATT_STUDY_INSTANCE_UID,
            A_data->study_level->study_inst_uid, NULL, FALSE) == QR_FAILURE )
            return ( QR_FAILURE );

        /* 
         * Fields needed by Study Root Model, and other Models   
         */
        if(!strncmp(A_data->model, STUDY_MODEL, sizeof(STUDY_MODEL) - 1))
        {
            if ( SetValue ( A_messageid, MC_ATT_PATIENTS_NAME, A_data->patient_level->patient_name, NULL,FALSE) == QR_FAILURE )
                return ( QR_FAILURE );

            if ( SetValue ( A_messageid, MC_ATT_PATIENT_ID, A_data->patient_level->patient_id, "*", FALSE) == QR_FAILURE )
                return ( QR_FAILURE );
        } 
        else /* PATIENT MODEL and PATIENT/STUDY ONLY MODEL do this */
        {
            if ( SetValue ( A_messageid, MC_ATT_PATIENT_ID, A_data->patient_level->patient_id, "*", FALSE) == QR_FAILURE )
                return ( QR_FAILURE );
        }
    } /* end of STUDY_LEVEL */

    /* Fields needed for SERIES_LEVEL (Patient Root, Study Root) */
    else if(!strncmp(A_data->level, SERIES_LEVEL, sizeof(SERIES_LEVEL) - 1))
    {
        if ( SetValue ( A_messageid, MC_ATT_MODALITY, A_data->series_level->modality, NULL, FALSE) == QR_FAILURE )
            return ( QR_FAILURE );
 
        if ( SetValue ( A_messageid, MC_ATT_SERIES_NUMBER, A_data->series_level->series_num, NULL, FALSE) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( SetValue ( A_messageid, MC_ATT_SERIES_INSTANCE_UID, A_data->series_level->series_inst_uid, NULL, FALSE) == QR_FAILURE )
            return ( QR_FAILURE );

        /* Set the Fields of the other levels (Patient, Study) */
        if (!strncmp(A_data->model, STUDY_MODEL, sizeof ( STUDY_MODEL ) -1 ))
        {
            if ( SetValue ( A_messageid, MC_ATT_PATIENTS_NAME, "", NULL, FALSE) == QR_FAILURE )
                return ( QR_FAILURE );
        }

        if ( SetValue ( A_messageid, MC_ATT_PATIENT_ID, A_data->patient_level->patient_id, NULL, FALSE) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( SetValue ( A_messageid, MC_ATT_STUDY_INSTANCE_UID, A_data->study_level->study_inst_uid, NULL, TRUE) == QR_FAILURE )
            return ( QR_FAILURE );

    } /* End of SERIES_LEVEL */

    /* 
     * Fields needed for IMAGE_LEVEL (Patient Root, Study Root Models ) 
     */
    else if(!strncmp(A_data->level, IMAGE_LEVEL, sizeof(IMAGE_LEVEL) - 1))
    {
        if ( SetValue ( A_messageid, MC_ATT_SOP_INSTANCE_UID, A_data->image_level->sop_inst_uid, NULL, FALSE) == QR_FAILURE )
            return ( QR_FAILURE );

        /* Set the Fields of the other levels (Patient, Study, Series) */
        if (!strncmp(A_data->model, STUDY_MODEL, sizeof ( STUDY_MODEL ) -1 ))
        {
            if ( SetValue ( A_messageid, MC_ATT_PATIENTS_NAME, "", NULL, FALSE) == QR_FAILURE )
                return ( QR_FAILURE );
        }

        if ( SetValue ( A_messageid, MC_ATT_PATIENT_ID, A_data->patient_level->patient_id, NULL, FALSE) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( SetValue ( A_messageid, MC_ATT_STUDY_INSTANCE_UID, A_data->study_level->study_inst_uid, NULL, FALSE) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( SetValue ( A_messageid, MC_ATT_SERIES_INSTANCE_UID, A_data->series_level->series_inst_uid, NULL, FALSE) == QR_FAILURE )
            return ( QR_FAILURE );

    } /* End of IMAGE_LEVEL */

    return(QR_SUCCESS);
} /* BuildCFINDMessage() */


/*****************************************************************************
 *
 * NAME
 *    SetValue - Sets values for a message
 *
 * ARGUMENTS
 *    A_messageid    int              Id of message the value is being set in
 *    A_tag          unsigned long    Tag of message that is to be set
 *    A_value        char *           Value of tag that is to be set
 *    A_default      char *           Default value of tag, if A_value is NULL 
 *    A_required     int              Flag telling if the tag is required 
 *
 * DESCRIPTION
 *    This function sets the values for a tag in a message. If the value  
 *    given is NULL and the tag is not required, the tag will be set to NULL 
 *    using MC_Set_Value_To_NULL().  If the tag value is not required, and the 
 *    value given is NULL you can specify a default value. The default value
 *    will then be used and set using MC_Set_Value_From_String(). 
 *
 * RETURNS
 *    QR_SUCCESS or QR_FAILURE
 *
 * SEE ALSO
 *    PrintErrorMessage()
 *    MC_Set_Value_From_String()
 *    MC_Set_Value_To_NULL() 
 *
 ****************************************************************************/
static QR_STATUS SetValue ( int A_messageid, unsigned long A_tag, char *A_value, char *A_default, int A_required )
{
    MC_STATUS      status;
    static char    S_prefix[] = "SetValue";

    if ( strlen(A_value) <= (size_t)0 )
    {
        /* The tag we were gonna set, was not given a value */
        if ( A_required == FALSE )
        {
            /* It's not a required tag, so we can set it to NULL */
            status = MC_Set_Value_To_NULL ( A_messageid, A_tag );
            if ( status != MC_NORMAL_COMPLETION )
            {
                PrintErrorMessage(S_prefix,"MC_Set_Value_To_NULL",status, NULL);
                printf("***          Tag: %lX\n", A_tag);
                return ( QR_FAILURE );
            }
            return ( QR_SUCCESS );
        }
        else if ( A_required == TRUE )
        {
            /* The tag is required so we must check to see if there is a default since we were not given a value for it. */
            if ( A_default )
            {
                status = MC_Set_Value_From_String ( A_messageid, A_tag, A_default );
                if ( status != MC_NORMAL_COMPLETION )
                {
                    PrintErrorMessage (S_prefix,"MC_Set_Value_From_String, default", status, NULL);
                    printf("***          Tag: %lX\n", A_tag);
                    return ( QR_FAILURE );
                }
                return ( QR_SUCCESS );
            } 
            else
            {
                /*
                 * This is a required tag and no value was given for it. There
                 * is no default value, so we cannot set it. Its an error.
                 */
                printf("%s:%lX, Required Parameter not set.\n", S_prefix,A_tag);
                return ( QR_FAILURE );
            }
        }
    }

    /*
     * This is just a usual tag that is being set, since we have a value for it
     */
    status = MC_Set_Value_From_String ( A_messageid, A_tag, A_value ); 
    if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage( S_prefix, "MC_Set_Value_From_String", status, NULL );
        printf("***          Tag: %lX\n", A_tag);
        return ( QR_FAILURE );
    }
    return ( QR_SUCCESS );

} /* SetValue() */

/*****************************************************************************
 *
 * NAME
 *    SetNextValue - Sets next values for a message
 *
 * ARGUMENTS
 *    A_messageid    int              Id of message the value is being set in
 *    A_tag          unsigned long    Tag of message that is to be set
 *    A_value        char *           Value of tag that is to be set
 *
 * DESCRIPTION
 *    This function sets the next values for a tag in a message. 
 *
 * RETURNS
 *    QR_SUCCESS or QR_FAILURE
 *
 * SEE ALSO
 *    PrintErrorMessage()
 *    MC_Set_Value_From_String()
 *
 ****************************************************************************/
static QR_STATUS SetNextValue ( int A_messageid, unsigned long A_tag,
                            char *A_value)
{
    MC_STATUS      status;
    static char    S_prefix[] = "SetNextValue";

    /*
     * This is just a usual tag that is being set, since we have a value for it
     */
    status = MC_Set_Next_Value_From_String ( A_messageid, A_tag, A_value ); 
    if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage( S_prefix, "MC_Set_Value_From_String", status, NULL );
        printf("***          Tag: %lX\n", A_tag);
        return ( QR_FAILURE );
    }
    return ( QR_SUCCESS );

} /* SetNextValue() */


/*****************************************************************************
 *
 * NAME
 *    BuildCGETMessage - Builds CGET message  
 *
 * ARGUMENTS
 *    A_data         RetData *      Information needed for the message
 *    A_messageID    int            Id of message being built 
 *    A_myConfig     AppConfig *    Program defaults structure
 *    A_moveLevel    char *         Name of level being moved
 *
 * DESCRIPTION
 *    This function builds a CGET message based on user input that has
 *    been filled into the A_data structure.
 *    Note: 
 *        For a C-GET request the Query SCP will send the requested 
 *        image back to the AE that originated the C-GET request.
 *
 * RETURNS
 *    QR_SUCCESS or QR_FAILURE
 *
 * SEE ALSO
 *    MC_Set_Value_From_String
 *    PrintErrorMessage
 *    SetVal
 *
 ****************************************************************************/
static QR_STATUS BuildCGETMessage(RetData* A_data, int A_messageID, AppConfig* A_myConfig, char* A_moveLevel ) 
{
    MC_STATUS status;
    static char S_prefix[] = "BuildCGETMessage";

    /*
     * Set the Query/Retrieve Level
     */
    status = MC_Set_Value_From_String (A_messageID, MC_ATT_QUERY_RETRIEVE_LEVEL, A_data->level );
    if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(S_prefix,"Query_Retrieve_level, SVFS", status, NULL );
        return ( QR_FAILURE );
    }

    if(!strncmp(A_data->level, IMAGE_LEVEL, sizeof(IMAGE_LEVEL) - 1))
    {
        /* check and set required attributes */
        if ( SetValue ( A_messageID, MC_ATT_SOP_INSTANCE_UID, A_data->image_level->sop_inst_uid, NULL, TRUE ) == QR_FAILURE )
            return ( QR_FAILURE );

        /*
         * If this is a COMPOSITE_ROOT Model, then we don't set the series UID and study UID 
         */
        if (strncmp(A_data->model, COMPOSITE_MODEL, sizeof(STUDY_MODEL) - 1 ) ||
            strncmp(A_data->model, COMPOSITE_NO_BULK_MODEL, sizeof(STUDY_MODEL) - 1 ))
        {
            if ( SetValue ( A_messageID, MC_ATT_SERIES_INSTANCE_UID, A_data->series_level->series_inst_uid, NULL, TRUE ) == QR_FAILURE )
                return ( QR_FAILURE );

            if ( SetValue ( A_messageID, MC_ATT_STUDY_INSTANCE_UID, A_data->study_level->study_inst_uid, NULL, TRUE ) == QR_FAILURE )
                return ( QR_FAILURE );
        }
        /*
         * If this is a STUDY_ROOT Model, then we don't set the patient id
         */
        if (strncmp(A_data->model, STUDY_MODEL, sizeof(STUDY_MODEL) - 1 ) &&
            strncmp(A_data->model, COMPOSITE_MODEL, sizeof(COMPOSITE_MODEL) - 1 ) &&
            strncmp(A_data->model, COMPOSITE_NO_BULK_MODEL, sizeof(COMPOSITE_NO_BULK_MODEL) - 1 ))
        {
            if ( SetValue ( A_messageID, MC_ATT_PATIENT_ID, A_data->patient_level->patient_id, NULL, TRUE ) == QR_FAILURE )
                return ( QR_FAILURE );
        }
    }
    else if (!strncmp(A_data->level, FRAME_LEVEL, sizeof(FRAME_LEVEL) - 1))
    {
        char *pch;
        int first = 1;

        /* only COMPOSITE model should come here. check and set required attributes */
        if ( SetValue ( A_messageID, MC_ATT_SOP_INSTANCE_UID, A_data->image_level->sop_inst_uid, NULL, TRUE ) == QR_FAILURE )
            return ( QR_FAILURE );

        /* parse frame_level->frame_list and set frame list to CGet request */
        /* this example only uses Simple Frame List */
        pch = strtok(A_data->frame_level->frame_list, " ,.");
        while (pch != NULL)
        {
            if (first)
            {
                if ( SetValue ( A_messageID, MC_ATT_SIMPLE_FRAME_LIST, pch, NULL, TRUE ) == QR_FAILURE )
                    return ( QR_FAILURE );
                first = 0;
            }
            else
            {
                if ( SetNextValue ( A_messageID, MC_ATT_SIMPLE_FRAME_LIST, pch) == QR_FAILURE )
                    return ( QR_FAILURE );
            }
            pch = strtok(NULL, " ,.");
        }
    }
    else if (!strncmp(A_data->level, PATIENT_LEVEL, sizeof(PATIENT_LEVEL) - 1))
    {
        if ( SetValue ( A_messageID, MC_ATT_PATIENT_ID, A_data->patient_level->patient_id, NULL, TRUE ) == QR_FAILURE )
            return ( QR_FAILURE );
    }
    else if(!strncmp(A_data->level, SERIES_LEVEL, sizeof(SERIES_LEVEL) - 1))
    {
        if ( SetValue ( A_messageID, MC_ATT_SERIES_INSTANCE_UID, A_data->series_level->series_inst_uid, NULL, TRUE ) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( SetValue ( A_messageID, MC_ATT_STUDY_INSTANCE_UID, A_data->study_level->study_inst_uid, NULL, TRUE ) == QR_FAILURE )
            return ( QR_FAILURE );

        /*
         * If this is a STUDY_ROOT Model, then we don't set the patient id
         */
        if ( strncmp (A_data->model, STUDY_MODEL, sizeof(STUDY_MODEL) ) )
        {
            if ( SetValue ( A_messageID, MC_ATT_PATIENT_ID, A_data->patient_level->patient_id, NULL, TRUE ) == QR_FAILURE )
                return ( QR_FAILURE );
        }
    }
    else /* study level */
    {
        if ( SetValue ( A_messageID, MC_ATT_STUDY_INSTANCE_UID, A_data->study_level->study_inst_uid, NULL, TRUE ) == QR_FAILURE )
            return ( QR_FAILURE );

        /*
         * If this is a STUDY_ROOT Model, then we don't set the patient id
         */
        if ( strncmp (A_data->model, STUDY_MODEL, sizeof(STUDY_MODEL) ) )
        { 
            if ( SetValue ( A_messageID, MC_ATT_PATIENT_ID, A_data->patient_level->patient_id, NULL, TRUE ) == QR_FAILURE )
                return ( QR_FAILURE );
        }
    }

    return(QR_SUCCESS);
} /* BuildCGETMessage() */

/*****************************************************************************
 *
 * NAME
 *    ReadCFINDMessage - Read a CFIND message  
 *
 * ARGUMENTS
 *    A_data               RetData *      Message found to be added to a list
 *    A_root_level_info    RetData *      Current query information
 *    A_messageid          int            Id of message that is being read
 *    A_myConfig           AppConfig *    Application configuration information
 *
 * DESCRIPTION
 *    This function reads a CFIND message and copies the appropriate 
 *    information into the A_data structure.
 *
 * RETURNS
 *    QR_SUCCESS or QR_FAILURE
 *
 * SEE ALSO
 *    GetValue 
 *
 ****************************************************************************/
static QR_STATUS ReadCFINDMessage( RetData *A_data, RetData *A_root_level_info, int A_messageid, AppConfig *A_myConfig )
{
    /* 
     * required fields for IMAGE_LEVEL
     */
    if(!strncmp(A_data->level, IMAGE_LEVEL, sizeof(IMAGE_LEVEL) - 1))
    {
        if ( GetValue ( A_messageid, MC_ATT_IMAGE_NUMBER,
            A_data->image_level->image_num,
            sizeof ( A_data->image_level->image_num ), 
            A_root_level_info->image_level->image_num ) == QR_FAILURE )
            return ( QR_FAILURE ); 

        if ( GetValue ( A_messageid, MC_ATT_SOP_INSTANCE_UID,
            A_data->image_level->sop_inst_uid,
            sizeof ( A_data->image_level->sop_inst_uid ),
            A_root_level_info->image_level->sop_inst_uid ) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( GetValue ( A_messageid, MC_ATT_RETRIEVE_AE_TITLE, 
            A_data->image_level->retrieveAETitle, 
            sizeof (A_data->image_level->retrieveAETitle), NULL) == QR_NOTAG )
        {
            if (GetValue(A_messageid, MC_ATT_STORAGE_MEDIA_FILE_SET_ID,
                A_data->image_level->med_file_id,
                sizeof(A_data->image_level->med_file_id), NULL) != QR_SUCCESS)
                return QR_FAILURE;
            if (GetValue(A_messageid, MC_ATT_STORAGE_MEDIA_FILE_SET_UID,
                A_data->image_level->med_file_uid,
                sizeof(A_data->image_level->med_file_uid), NULL) != QR_SUCCESS)
                return QR_FAILURE;
        }
    }

    /* 
     * required fields for SERIES_LEVEL
     */
    else if(!strncmp(A_data->level, SERIES_LEVEL, sizeof(SERIES_LEVEL) - 1))
    {
        if ( GetValue ( A_messageid, MC_ATT_MODALITY,
            A_data->series_level->modality,
            sizeof ( A_data->series_level->modality ),
            A_root_level_info->series_level->modality ) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( GetValue ( A_messageid, MC_ATT_SERIES_INSTANCE_UID,
            A_data->series_level->series_inst_uid,
            sizeof ( A_data->series_level->series_inst_uid ),
            A_root_level_info->series_level->series_inst_uid ) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( GetValue ( A_messageid, MC_ATT_SERIES_NUMBER,
            A_data->series_level->series_num,
            sizeof ( A_data->series_level->series_num ),
            A_root_level_info->series_level->series_num ) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( GetValue ( A_messageid, MC_ATT_RETRIEVE_AE_TITLE, 
            A_data->series_level->retrieveAETitle, 
            sizeof(A_data->series_level->retrieveAETitle), NULL) == QR_NOTAG)
        {
            GetValue(A_messageid, MC_ATT_STORAGE_MEDIA_FILE_SET_ID,
                     A_data->series_level->med_file_id,
                     sizeof(A_data->series_level->med_file_id), NULL);
            GetValue(A_messageid, MC_ATT_STORAGE_MEDIA_FILE_SET_UID,
                     A_data->series_level->med_file_uid,
                     sizeof(A_data->series_level->med_file_uid), NULL);
        }
    }

    /*
     * required fields for PATIENT_LEVEL
     */
    else if (!strncmp(A_data->level, PATIENT_LEVEL, sizeof(PATIENT_LEVEL) - 1))
    {
        if ( GetValue ( A_messageid, MC_ATT_PATIENTS_NAME,
            A_data->patient_level->patient_name,
            sizeof ( A_data->patient_level->patient_name),
            A_root_level_info->patient_level->patient_name ) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( GetValue ( A_messageid, MC_ATT_PATIENT_ID, 
            A_data->patient_level->patient_id,
            sizeof ( A_data->patient_level->patient_id ),
            A_root_level_info->patient_level->patient_id ) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( GetValue ( A_messageid, MC_ATT_RETRIEVE_AE_TITLE, 
            A_data->patient_level->retrieveAETitle, 
            sizeof(A_data->patient_level->retrieveAETitle), NULL) == QR_NOTAG)
        {
            GetValue(A_messageid, MC_ATT_STORAGE_MEDIA_FILE_SET_ID,
                     A_data->patient_level->med_file_id,
                     sizeof(A_data->patient_level->med_file_id), NULL);
            GetValue(A_messageid, MC_ATT_STORAGE_MEDIA_FILE_SET_UID,
                     A_data->patient_level->med_file_uid,
                     sizeof(A_data->patient_level->med_file_uid),NULL);
        }
    }

    /*
     * required fields for STUDY_LEVEL 
     */
    else /* study level */
    {
        if ( GetValue ( A_messageid, MC_ATT_STUDY_DATE, 
            A_data->study_level->study_date,
            sizeof ( A_data->study_level->study_date ),
            A_root_level_info->study_level->study_date ) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( GetValue ( A_messageid, MC_ATT_STUDY_TIME, 
            A_data->study_level->study_time,
            sizeof ( A_data->study_level->study_time ),
            A_root_level_info->study_level->study_time ) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( GetValue ( A_messageid, MC_ATT_ACCESSION_NUMBER, 
            A_data->study_level->accession_num,
            sizeof ( A_data->study_level->accession_num ),
            A_root_level_info->study_level->accession_num ) == QR_FAILURE )
            return ( QR_FAILURE );

        if (strncmp(A_data->model, STUDY_MODEL, sizeof(STUDY_MODEL) - 1))
        {
            /* 
             * If it is not a STUDY_MODEL query, then the patient's name
             *  goes with the patient level structure
             */
            if ( GetValue ( A_messageid, MC_ATT_PATIENTS_NAME, 
                A_data->patient_level->patient_name,
                sizeof ( A_data->patient_level->patient_name ),
                A_root_level_info->patient_level->patient_name ) == QR_FAILURE )
                return ( QR_FAILURE );

            if ( GetValue ( A_messageid, MC_ATT_PATIENT_ID,
                A_data->patient_level->patient_id,
                sizeof ( A_data->patient_level->patient_id ),
                A_root_level_info->patient_level->patient_id ) == QR_FAILURE )
                return ( QR_FAILURE );
        }

        /*
         * The study model requires that the study_level has the patient name and patient id
         */
        else if (!strncmp(A_data->model, STUDY_MODEL, sizeof(STUDY_MODEL) - 1))
        {
            if ( GetValue ( A_messageid, MC_ATT_PATIENTS_NAME,
                A_data->study_level->patient_name,
                sizeof ( A_data->study_level->patient_name ),
                A_root_level_info->study_level->patient_name ) == QR_FAILURE )
                return ( QR_FAILURE );

            if ( GetValue ( A_messageid, MC_ATT_PATIENT_ID,
                A_data->study_level->patient_id,
                sizeof ( A_data->study_level->patient_id ),
                A_root_level_info->study_level->patient_id ) == QR_FAILURE )
                return ( QR_FAILURE ); 
        }

        if ( GetValue ( A_messageid, MC_ATT_STUDY_ID,
            A_data->study_level->study_id,
            sizeof ( A_data->study_level->study_id ),
            A_root_level_info->study_level->study_id ) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( GetValue ( A_messageid, MC_ATT_STUDY_INSTANCE_UID,
            A_data->study_level->study_inst_uid,
            sizeof ( A_data->study_level->study_inst_uid ),
            A_root_level_info->study_level->study_inst_uid ) == QR_FAILURE )
            return ( QR_FAILURE );

        if ( GetValue ( A_messageid, MC_ATT_RETRIEVE_AE_TITLE, 
            A_data->study_level->retrieveAETitle, 
            sizeof(A_data->study_level->retrieveAETitle), NULL) == QR_NOTAG )
        {
            GetValue(A_messageid, MC_ATT_STORAGE_MEDIA_FILE_SET_ID,
                     A_data->study_level->med_file_id,
                     sizeof(A_data->study_level->med_file_id), NULL);
            GetValue(A_messageid, MC_ATT_STORAGE_MEDIA_FILE_SET_UID,
                     A_data->study_level->med_file_uid,
                     sizeof(A_data->study_level->med_file_uid), NULL);
        }
    } /* End of STUDY_LEVEL */

    return ( QR_SUCCESS );
} /* ReadCFINDMessage() */


/*****************************************************************************
 *
 * NAME
 *    GetValue - Gets the value from a message for specific tags 
 *
 * ARGUMENTS
 *    A_messageid    int              Id of message the value is being set in
 *    A_tag          unsigned long    Tag of message that is to be set
 *    A_value        char *           Value of tag that is to be set
 *    A_size         int              Size of the buffer to hold the tag value
 *    A_default      char *           Default value of tag, if A_value is NULL
 *
 * DESCRIPTION
 *    Gets the value of a tag from a given message id.
 *
 * RETURNS
 *    QR_SUCCESS or QR_FAILURE
 *
 * SEE ALSO
 *
 ****************************************************************************/
static QR_STATUS GetValue ( int A_messageid, unsigned long A_tag, char *A_value, int A_size, char *A_default )
{
    MC_STATUS      status;
    static char    S_prefix[] = "GetValue";

    status = MC_Get_Value_To_String ( A_messageid, A_tag, A_size,
                                      A_value );
    if ( status == MC_NULL_VALUE || status == MC_EMPTY_VALUE  || status == MC_INVALID_TAG )
    {
        if (!A_default)
        {
            A_value[0] = '\0';
            return ( QR_NOTAG );
        }
        strcpy ( A_value, A_default );
    }
    else if ( status != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage ( S_prefix, "MC_Get_Value_To_String", status, NULL );
        printf("***          Tag:  %lX\n", A_tag);
        return ( QR_FAILURE );
    }
    return ( QR_SUCCESS );
} /* GetValue() */

/*****************************************************************************
 *
 * NAME
 *    PrintCFINDResults - Print contents of a CFIND Message  
 *
 * ARGUEMENTS
 *    A_list    RetData *    List of find results to be displayed
 *   
 * DESCRIPTION
 *    This function prints the contents of a data structure with info
 *    from a CFIND Message.  This function is used to display the query
 *    results from a given level when selecting a record.
 *
 * RETURNS
 *    none
 *
 * SEE ALSO
 *    none
 *
 ****************************************************************************/
static void PrintCFINDResults( RetData *A_list )
{
    int    i;
    PRPL   *prpl;
    PRSTL  *prstl;
    PRSL   *prsl;
    PRIL   *pril;

    if (!strncmp(A_list->model, STUDY_MODEL, sizeof(STUDY_MODEL) - 1))
    {
        if (!strncmp(A_list->level, STUDY_LEVEL, sizeof(STUDY_LEVEL) - 1))
        {
            printf("Patient's Name      = [%s]\n", A_list->study_level->patient_name);
            printf("Patient ID          = [%s]\n", A_list->study_level->patient_id);
        }
    }
    else if(!strncmp(A_list->level, PATIENT_LEVEL, sizeof(PATIENT_LEVEL) - 1))
    {
        printf("Patient's Name      = [%s]\n", A_list->patient_level->patient_name);
        printf("Patient ID          = [%s]\n", A_list->patient_level->patient_id);
    }

    if(!strncmp(A_list->level, IMAGE_LEVEL, sizeof(IMAGE_LEVEL) - 1))
    {
        pril = A_list->image_level;
        printf("      %-33.33s%-20.20s%s\n", "Image Number", "SOP Instance UID", "Image Status");
        printf("------------------------------------------------------------------------\n");
        for (i=0; i<A_list->numData; i++)
        {
            printf("%5d: %-32.32s %-20.20s %s\n", i+1, pril->image_num, pril->sop_inst_uid, (pril->retrieveAETitle[0] != '\0' ? "ONLINE":"OFFLINE") ); 
            pril = pril->next;
        }
    }
    else if(!strncmp(A_list->level, SERIES_LEVEL, sizeof(SERIES_LEVEL) - 1))
    {
        prsl = A_list->series_level;
        printf("      %-33.33s%-20.20s%s\n", "Modality", "Series Number", "Image Status");
        printf("------------------------------------------------------------------------\n");
        for (i=0; i<A_list->numData; i++)
        {
            printf("%5d: %-32.32s %-20.20s %s\n", i+1, prsl->modality, prsl->series_num, (prsl->retrieveAETitle[0] != '\0' ? "ONLINE":"OFFLINE") ); 
            prsl = prsl->next;
        }
    }
    else if (!strncmp(A_list->level, STUDY_LEVEL, sizeof(STUDY_LEVEL)- 1))
    {
        prstl = A_list->study_level;
        printf("      %-33.33s%-20.20s%s\n", "Study Date", "Study ID", "Image Status");
        printf("------------------------------------------------------------------------\n");
        for (i=0; i<A_list->numData; i++)
        {
            printf("%5d: %-32.32s %-20.20s %s\n", i+1, prstl->study_date, prstl->study_id, (prstl->retrieveAETitle[0] != '\0' ? "ONLINE":"OFFLINE") ); 
            prstl = prstl->next;
        }
    }
    else if (!strncmp(A_list->level, PATIENT_LEVEL, sizeof(PATIENT_LEVEL) - 1))
    {
        prpl = A_list->patient_level;
        printf("\n");
        printf("      %-33.33s%-20.20s%s\n", "Patient Name", "Patient ID", "Image Status");
        printf("------------------------------------------------------------------------\n");
        for (i=0; i<A_list->numData; i++)
        {
            printf("%5d: %-32.32s %-20.20s %s\n", i+1, prpl->patient_name, prpl->patient_id, (prpl->retrieveAETitle[0] != '\0' ? "ONLINE":"OFFLINE") ); 
            prpl = prpl->next;
        }
    }
    else 
        printf("The specified level is not supported, so the data was not shown.\n");

} /* PrintCFINDResults() */

/*****************************************************************************
 *
 * NAME
 *    MessageToFile - The callback routine for MC_Stream_To_Message
 *
 * ARGUMENTS
 *    A_msgID             int     The message ID
 *    A_CBinformation     void *  The data passed to this function
 *    A_dataSize          int     The data size of the stream data
 *    A_dataBuffer        void *  The data buffer containing the stream data
 *    A_isFirst           int     TRUE when MC3 is providing first data
 *    A_isLast            int     TRUE when MC3 is providing last data
 *
 * DESCRIPTION
 *    MessageToFile is the function which will be called repeatedly to
 *    provide blocks of streamed DICOM message data.  It is the callback
 *    function called by MC_Message_To_Stream.
 *
 * RETURNS
 *    MC_CANNOT_COMPLY
 *    MC_NORMAL_COMPLETION
 *
 * SEE ALSO
 *    none.
 *
 ****************************************************************************/
static MC_STATUS NOEXP_FUNC MessageToFile ( int A_msgID, 
                                            void *A_CBinformation,
                                            int A_dataSize, 
                                            void *A_dataBuffer,
                                            int A_isFirst, 
                                            int A_isLast )
{
    CBinfo*      callbackInfo = (CBinfo*)A_CBinformation;
    size_t       count;
    int          returnVal;

    if ( A_isFirst && A_msgID != callbackInfo->messageID )
    {
        printf ( "%s:  Wrong message ID!\n", callbackInfo->prefix );
        return ( MC_CANNOT_COMPLY );
    }

    count = fwrite ( A_dataBuffer, 1, A_dataSize, callbackInfo->stream );

    if ( count != (size_t)A_dataSize )
    {
        printf ( "%s:  fwrite error\n", callbackInfo->prefix );
        return ( MC_CANNOT_COMPLY );
    }

    /*1-2WAPH*/
    returnVal = fflush(callbackInfo->stream);
    if ( returnVal != 0 )
    {
        printf("\tfflush error\n");
        fclose(callbackInfo->stream);
        callbackInfo->stream= NULL;
        return MC_CANNOT_COMPLY;
    }

    return ( MC_NORMAL_COMPLETION );
} /* MessageToFile() */

/********************************************************************
**
** NAME
**    WriteToMedia
**
** ARGUMENTS
**    Aoptions   - Structure that holds configuration
**                 parameters
**    A_filename - Filename to write to
**    A_msgID    - ID of message received to write
**    A_msgType  - Character string describing the
**                 message type
**
** RETURNS
**    QR_SUCCESS or QR_FAILURE
**
** DESCRIPTION
**    Converts a message received over the network
**    into a DICOM-3 formatted file.
**
*********************************************************************/
static QR_STATUS WriteToMedia( AppConfig* A_myConfig, char* A_filename, int* A_msgID, char* A_messageType )
{
    MC_STATUS        mcStatus;
    QR_STATUS        qrStatus;
    CBinfo           callbackInfo;
    TRANSFER_SYNTAX  messageSyntax;
    TRANSFER_SYNTAX  resultSyntax;

    /*
     * Get the transfer syntax that the message was transferred over
     * the network as.  This is to determine if it is JPEG encoded.
     */
    mcStatus = MC_Get_Message_Transfer_Syntax( *A_msgID, &messageSyntax );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->applicationTitle, "MC_Get_Message_Transfer_Syntax", mcStatus, NULL);
        MC_Free_Message(A_msgID);
        return QR_FAILURE;
    }
    else
    {
        /*
         * For the standard syntaxes, save in the configured syntax.
         * For all the encapsualted/compressed syntaxes, save in the
         * syntax received.
         */
        switch ( messageSyntax )
        {
            case IMPLICIT_LITTLE_ENDIAN:
            case EXPLICIT_LITTLE_ENDIAN:
            case EXPLICIT_BIG_ENDIAN:
            case IMPLICIT_BIG_ENDIAN:
                resultSyntax = EXPLICIT_LITTLE_ENDIAN;
                break;

            default:
                resultSyntax = messageSyntax;
                break;
        }
    }

    /*
     * Now convert message object to a file object.  This changes the
     * toolkit's internal representation of the file from a message to a
     * file object.  It also allows the group 0x0002 elements to be used
     * in the object.  Any other attributes within the message can still
     * be dealt with when it is classified as a file.
     */
    mcStatus = MC_Message_To_File( *A_msgID, A_filename );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->applicationTitle, "MC_Message_To_File", mcStatus, NULL);
        MC_Free_File(A_msgID);
        return QR_FAILURE;
    }

    /*
     * Add the group 2 elements to the object.
     */
    qrStatus = AddGroup2Elements( A_myConfig, resultSyntax, *A_msgID );
    if ( qrStatus == QR_FAILURE )
    {
        PrintErrorMessage(A_myConfig->applicationTitle, "AddGroup2Elements", mcStatus, NULL);
        MC_Free_File(A_msgID);
        return QR_FAILURE;
    }

    printf("Writing %s image in DICOM Part 10 format:  %s\n", A_messageType, A_filename);

    /*
     * Write out the new file.
     */
    mcStatus = MC_Write_File( *A_msgID, 0, &callbackInfo, FileObjToMedia );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        if ( callbackInfo.stream )
            fclose(callbackInfo.stream);

        PrintErrorMessage(A_myConfig->applicationTitle, "MC_Write_File", mcStatus, NULL);
        MC_Free_File(A_msgID);
        return QR_FAILURE;
    }

    if ( callbackInfo.stream )
        fclose(callbackInfo.stream);

    mcStatus = MC_Free_File(A_msgID);
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->applicationTitle, "MC_Free_File", mcStatus, NULL);
        return QR_FAILURE;
    }

    return QR_SUCCESS;
} /* WriteToMedia() */

/****************************************************************************
**
** NAME
**    FileObjToMedia
**
** ARGUMENTS
**    A_filename   - Filename to write to
**    A_userInfo   - Information to store between calls to this
**                   function
**    A_dataSize   - Size of A_dataBuffer
**    A_dataBuffer - Buffer containing data to write
**    A_isFirst    - set to true on first call
**    A_isLast     - Is set to true on the final call
**
** RETURNS
**    MC_NORMAL_COMPLETION on success, any other MC_STATUS
**    value on failure.
**
** DESCRIPTION
**    Callback function used to write DICOM file object to
**    media.  A pointer to this function is passed to
**    MC_Write_File
**
*****************************************************************************/
static MC_STATUS NOEXP_FUNC FileObjToMedia( char*    A_filename,
                                            void*    A_userInfo,
                                            int      A_dataSize,
                                            void*    A_dataBuffer,
                                            int      A_isFirst,
                                            int      A_isLast)
{
    size_t     count = 0;
    CBinfo*    cbInfo = (CBinfo*)A_userInfo;
    int        retStatus;

    if ( A_isFirst )
    {
        cbInfo->stream = fopen(A_filename, BINARY_WRITE);
        if(cbInfo->stream==NULL)
        {
            printf("\nERROR: Can not open %s file. (errno=%d) \n",A_filename,errno);
            return MC_CANNOT_COMPLY;
        }

        retStatus = setvbuf(cbInfo->stream, (char *)NULL, _IOFBF, 32768);
        if ( retStatus != 0 )
        {
            printf("WARNING:  Unable to set IO buffering on input file.\n");
        }
    }

    if ( !cbInfo->stream )
        return MC_CANNOT_COMPLY;

    count = fwrite(A_dataBuffer, 1, A_dataSize, cbInfo->stream);
    if ( count != (size_t)A_dataSize )
    {
        printf("fwrite error");
        return MC_CANNOT_COMPLY;
    }

    retStatus = fflush(cbInfo->stream);
    if ( retStatus != 0 )
    {
        printf("\tfflush error\n");
        fclose(cbInfo->stream);
        cbInfo->stream = NULL;
        return MC_CANNOT_COMPLY;
    }

    if ( A_isLast )
    {
        /*
         * NULL ->fp so that the routine calling MC_Write file knows not to close the stream.
         */
        retStatus = fclose(cbInfo->stream);
        if ( retStatus != 0 )
        {
            printf("\tfclose error\n");
            cbInfo->stream = NULL;
            return MC_CANNOT_COMPLY;
        }
        cbInfo->stream = NULL;
    }

    return MC_NORMAL_COMPLETION;

} /* FileObjToMedia() */


/****************************************************************************
**
**  Function    :   AddGroup2Elements
**
**  Parameters  :   A_options    - Input parameters
**                  AtransSyntax - structure for config options
**                  AfileID      - File to add meta information to
**
**  Returns     :   QR_STATUS
**
**  Description :   Sets group two information in a media file
**
*****************************************************************************/
static QR_STATUS AddGroup2Elements( AppConfig* A_myConfig, TRANSFER_SYNTAX A_transSyntax, int A_fileID )
{
    MC_STATUS mcStatus;
    char      uidBuffer[UI_LEN+2] = {0};
    char      syntaxUID[UI_LEN+2] = {0};

    /*
     * Get the correct UID for the new transfer syntax
     */
    mcStatus = MC_Get_Transfer_Syntax_From_Enum(A_transSyntax, syntaxUID, sizeof(syntaxUID));
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->applicationTitle, "MC_Get_Transfer_Syntax_From_Enum", mcStatus, NULL);
        return QR_FAILURE;
    }

    /*
     * Set the new transfer syntax for this message
     */
    mcStatus = MC_Set_Value_From_String(A_fileID, MC_ATT_TRANSFER_SYNTAX_UID, syntaxUID);
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->applicationTitle, "MC_Set_Value_From_String", mcStatus, NULL);
        return QR_FAILURE;
    }

    /*
     * Set other media group 2 elements
     */
    mcStatus = MC_Set_Value_From_Function( A_fileID, MC_ATT_FILE_META_INFORMATION_VERSION, NULL, FileMetaInfoVersion );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->applicationTitle, "MC_Set_Value_From_Function", mcStatus, NULL);
        return QR_FAILURE;
    }


    mcStatus = MC_Get_Value_To_String( A_fileID, MC_ATT_SOP_CLASS_UID, sizeof(uidBuffer), uidBuffer );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->applicationTitle, "MC_Get_Value_To_String", mcStatus, "Unable to get SOP Class UID from image file");
        return QR_FAILURE;
    }

    mcStatus = MC_Set_Value_From_String( A_fileID, MC_ATT_MEDIA_STORAGE_SOP_CLASS_UID, uidBuffer);
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->applicationTitle, "MC_Set_Value_From_String", mcStatus, "Unable to add media storage SOP Class UID");
        return QR_FAILURE;
    }

    mcStatus = MC_Get_Value_To_String(A_fileID, MC_ATT_SOP_INSTANCE_UID, sizeof(uidBuffer), uidBuffer);
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->applicationTitle, "MC_Get_Value_To_String", mcStatus, "Unable to get SOP Instance UID from image file");
        return QR_FAILURE;
    }

    mcStatus = MC_Set_Value_From_String( A_fileID, MC_ATT_MEDIA_STORAGE_SOP_INSTANCE_UID, uidBuffer);
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->applicationTitle, "MC_Set_Value_From_String", mcStatus, "Unable to add media storage SOP instance UID");
        return QR_FAILURE;
    }

    mcStatus = MC_Set_Value_From_String( A_fileID, MC_ATT_SOURCE_APPLICATION_ENTITY_TITLE, A_myConfig->applicationTitle);
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        PrintErrorMessage(A_myConfig->applicationTitle, "MC_Set_Value_From_String", mcStatus, "Unable to add source application entity title");
        return QR_FAILURE;
    }
    return QR_SUCCESS;

} /* AddGroup2Elements() */

/********************************************************************
**
**  Function    :   FileMetaInfoVersion
**
**  Parameters  :
**
**  Returns     :   MC_NORMAL_COMPLETION
**
**  Description :   Adds group 2 element for File Meta Information Version
**                  to the preamble of the DICOM file object
**
*********************************************************************/
static MC_STATUS NOEXP_FUNC FileMetaInfoVersion( int           A_msgID,
                                                 unsigned long A_tag,
                                                 int           A_isFirst,
                                                 void*         A_info,
                                                 int*          A_dataSize,
                                                 void**        A_dataBufferPtr,
                                                 int*          A_isLastPtr)
{
    static char version[] = {0x00,0x01};

    *A_dataSize = 2;
    *A_dataBufferPtr = version;
    *A_isLastPtr = 1;

    return MC_NORMAL_COMPLETION;

} /* FileMetaInfoVersion() */

