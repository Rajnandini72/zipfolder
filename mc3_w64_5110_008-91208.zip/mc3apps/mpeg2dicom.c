/*************************************************************************
 *
 *        System: MergeCOM-3 Mpeg-2 Stream to Dicom Sample Program
 *
 *
 *   Description:
 *
 *  =============================  History  =============================
 *
 *************************************************************************
 *
 *                      COPYRIGHT (C) 2012
 *                  Merge Technologies Incorporated
 *            900 Walnut Ridge Drive, Hartland, WI 53029
 *
 *                      -- ALL RIGHTS RESERVED --
 *
 *  This software is furnished under license and may be used and copied
 *  only in accordance with the terms of such license and with the
 *  inclusion of the above copyright notice.  This software or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and ownership of the software is hereby
 *  transferred.
 *
 ************************************************************************/

#include <time.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <ctype.h>
#include <math.h>


#include "mergecom.h"
#include "mcstatus.h"
#include "mc3msg.h"
#include "diction.h"
#include "mc3services.h"

#include "mc3media.h"


#define FILE_NAME_LEN   100


/*
 * Structure passed to pixel callback function for streaming pixel data
 * into a message
 */
typedef struct PIXELCALLBACK
{
    int Axsize;
    int Aysize;
    int messageID;
} PixelCallBack;

typedef struct CALLBACKINFO
{
    FILE*         fp;
    /*
     * Note!   The size of this buffer impacts toolkit performance.  Higher
     * values in general should result in increased performance of reading
     * files
     */
    char          buffer[64*1024];
    size_t        bytesRead;
} CBinfo;

typedef struct MCFileCbkStruct
{
    const char* fileName;

    int         bufferSize;
    void*       buffer;

    FILE*       file;
} FileCbkInfo;

static const char Sheader_str1[] = "Mpeg2Dicom: Dicom MPEG-2 Video Utility";
static const char Sheader_str2[] = "(c) 2020 Merge Healthcare.  All rights reserved.";


static char* S_InputFile;
static char* S_OutputFile;
static char  S_Operation;

#define FALSE 0
#define TRUE 1

/* functions definition */
static void print_cmdline(void);
static int read_cmd_line( int Aargc, char *Aargv[]);
static MC_STATUS WrapToDcm(int applicationID, const char* mpgFileName, const char* dcmFileName);
static MC_STATUS UnpackMpeg(int applicationID, const char* dcmFileName, const char* mpgFileName);
MC_STATUS NOEXP_FUNC FileWriteCbk(char* A_filename, void* userInfo, int dataSize,
                                  void* dataBuffer, int isFirst, int isLast);
MC_STATUS NOEXP_FUNC MsgToStream(int AmsgID, void* AuserInfo, int AdataSize,
                                 void* AdataBuffer, int AisFirst, int AisLast);
MC_STATUS NOEXP_FUNC ValueToFile(int AmsgID, unsigned long ATag, void* AuserInfo,
                                 int AdataSize, void* AdataBuffer,
                                 int AisFirst, int AisLast);
MC_STATUS NOEXP_FUNC SetPixelFunction(int AmsgID, unsigned long ATag, int AfirstCall,
                                      void* AuserInfo, int* AdataLen, void** Abuffer,
                                      int* AisLast);

/********************************************************************
 *
 *  Function    :   main
 *
 *  Returns     :   0 if OK
 *                  1 if error occurred
 * example parameters:		-p ..\1\sample_mpeg2.mpg Dicom_Mpeg2.dcm
 *				
 *
 ********************************************************************/
int main( int argc, char *argv[])
{
    int                 applicationID;  /* ID for application & toolkit */
    MC_STATUS           mcStatus;        /* return value from toolkit calls */
	char versionString[256];


	mcStatus = MC_Get_Version_String(sizeof(versionString), versionString);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        printf("Error from MC_Get_Version_String()\n");
        exit(EXIT_FAILURE);
    }

    printf("%s, Version %s\n", Sheader_str1, versionString );
    printf("%s\n\n", Sheader_str2);

    if (!read_cmd_line(argc, argv))
    {
        printf("\n"); /* force extra character, mainly for UNIX */
        exit(EXIT_FAILURE);   /* Invalid command line, exit now */
    }

    /*
     * This call MUST be the first call made to the library!!!
     */
    mcStatus = MC_Library_Initialization ( NULL, NULL, NULL );
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        printf("Unable to initialize library: %s\n", MC_Error_Message(mcStatus));
        exit(EXIT_FAILURE);
    }

    /*
     *  Register this DICOM application
     */
    mcStatus = MC_Register_Application(&applicationID, "mpeg2dicom");
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        printf("\tUnable to register \"mpeg2dicom\"\n");
        printf("\t%s\n", MC_Error_Message(mcStatus));
        exit(EXIT_FAILURE);
    }

    if(S_Operation == 'p')
    {
        mcStatus = WrapToDcm(applicationID, S_InputFile, S_OutputFile);
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            printf("\tUnable to create DICOM file:\n");
            printf("\t%s\n", MC_Error_Message(mcStatus));
            exit(EXIT_FAILURE);
        }
    }
    else if(S_Operation == 'u')
    {
		mcStatus = UnpackMpeg(applicationID, S_InputFile, S_OutputFile);
        if (mcStatus != MC_NORMAL_COMPLETION)
        {
            printf("\tUnable to unpack MPEG file:\n");
            printf("\t%s\n", MC_Error_Message(mcStatus));
            exit(EXIT_FAILURE);
        }

    }

    MC_Release_Application(&applicationID);
    return EXIT_SUCCESS;
}

/*
 * CBinfo is used to callback functions when reading in stream objects
 * and Part 10 format objects.
 */
/****************************************************************************
 *
 *  Function    :   MediaToFileObj
 *
 *  Parameters  :   A_fileName   - Filename to open for reading
 *                  A_userInfo   - Pointer to an object used to preserve
 *                                 data between calls to this function.
 *                  A_dataSize   - Number of bytes read
 *                  A_dataBuffer - Pointer to buffer of data read
 *                  A_isFirst    - Set to non-zero value on first call
 *                  A_isLast     - Set to 1 when file has been completely
 *                                 read
 *
 *  Returns     :   MC_NORMAL_COMPLETION on success
 *                  any other MC_STATUS value on failure.
 *
 *  Description :   Callback function used by MC_Open_File to read a file
 *                  in the DICOM Part 10 (media) format.
 *
 ****************************************************************************/
static MC_STATUS NOEXP_FUNC MediaToFileObj( char*     A_filename,
                                 void*     A_userInfo,
                                 int*      A_dataSize,
                                 void**    A_dataBuffer,
                                 int       A_isFirst,
                                 int*      A_isLast)
{

    CBinfo*         callbackInfo = (CBinfo*)A_userInfo;
    size_t          bytes_read;

    if (!A_userInfo)
        return MC_CANNOT_COMPLY;

    if (A_isFirst)
    {
        callbackInfo->bytesRead = 0;
        callbackInfo->fp = fopen(A_filename, "rb");
    }

    if (!callbackInfo->fp)
       return MC_CANNOT_COMPLY;

    bytes_read = fread(callbackInfo->buffer, 1, sizeof(callbackInfo->buffer),
                       callbackInfo->fp);
    if (ferror(callbackInfo->fp))
        return MC_CANNOT_COMPLY;

    if (feof(callbackInfo->fp))
    {
        *A_isLast = 1;
        fclose(callbackInfo->fp);
        callbackInfo->fp = NULL;
    }
    else
        *A_isLast = 0;

    *A_dataBuffer = callbackInfo->buffer;
    *A_dataSize = (int)bytes_read;
    callbackInfo->bytesRead += (int)bytes_read;
    return MC_NORMAL_COMPLETION;

} /* MediaToFileObj() */


MC_STATUS NOEXP_FUNC FileWriteCbk(char* A_filename, void* userInfo, int dataSize,
                                  void* dataBuffer, int isFirst, int isLast)
{
    size_t count;
    FileCbkInfo* cbInfo = (FileCbkInfo*) userInfo;

    if( !userInfo ) return MC_CANNOT_COMPLY;

    if( isFirst ) cbInfo->file = fopen( cbInfo->fileName, "wb" );

    if( !cbInfo->file )
    {
        printf("Failed to open file to write %s, error: %s\n", cbInfo->fileName, strerror(errno) );
        return MC_CANNOT_COMPLY;
    }

    count = fwrite( dataBuffer, 1, dataSize, cbInfo->file );
    if( count != (size_t) dataSize )
    {
        printf("Failed to write to %s, error: %s\n", cbInfo->fileName, strerror(errno) );
        return MC_CANNOT_COMPLY;
    }

    return MC_NORMAL_COMPLETION;
}



/****************************************************************************
 *
 *  Function    :   MsgToStream
 *
 *  Parameters  :   AmsgID      - Message ID
 *                  AdimseInfo  - Information to use for SendPDVs
 *                  AdataSize   - Bytes of data in Adata
 *                  Adata       - Buffer containing streamed data
 *                  AisFirst    - This is first call to this function
 *                                for this stream
 *                  AisLast     - This is last call to this function
 *                                for this stream
 *
 *  Returns     :   MC_NORMAL_COMPLETION
 *                  MC_CANNOT_COMPLY
 *
 *  Description :   This is the callback function used to write messages to file
 *
 ****************************************************************************/

MC_STATUS NOEXP_FUNC MsgToStream(int AmsgID, void* AuserInfo, int AdataSize,
                                 void* AdataBuffer, int AisFirst, int AisLast)
{
    size_t  bytes;
    char* filename = (char*) AuserInfo;
    static FILE* fp;

    if (AisFirst)
    {
        fp = fopen(filename, "wb");
        if (!fp)
        {
            printf("\n can't open file: %s ", strerror(errno));
            return MC_CANNOT_COMPLY;
        }
    }


    if (AdataSize)
    {
        bytes = fwrite(AdataBuffer, 1, (size_t)AdataSize, fp);
        if (bytes != (size_t)AdataSize)
        {
            fclose(fp);
            printf("\n can't write file");
            return MC_CANNOT_COMPLY;
        }
    }

    if (AisLast)
        fclose(fp);

    return MC_NORMAL_COMPLETION;
}

/****************************************************************************
 *
 *  Function    :   MsgToStream
 *
 *  Parameters  :   AmsgID      - Message ID
 *                  ATag		- Tag for the value
 *                  AdimseInfo  - Information to use for SendPDVs
 *                  AdataSize   - Bytes of data in Adata
 *                  Adata       - Buffer containing streamed data
 *                  AisFirst    - This is first call to this function
 *                                for this stream
 *                  AisLast     - This is last call to this function
 *                                for this stream
 *
 *  Returns     :   MC_NORMAL_COMPLETION
 *                  MC_CANNOT_COMPLY
 *
 *  Description :   This is the callback function used to write messages to file
 *
 ****************************************************************************/

MC_STATUS NOEXP_FUNC ValueToFile(int AmsgID, unsigned long ATag, void* AuserInfo,
                                 int AdataSize, void* AdataBuffer,
                                 int AisFirst, int AisLast)
{
    size_t  bytes;
    char* filename = (char*) AuserInfo;
    static FILE* fp;

    if (AisFirst)
    {
        fp = fopen(filename, "wb");
        if (!fp)
        {
            printf("\n can't open file: %s ", strerror(errno));
            return MC_CANNOT_COMPLY;
        }
    }


    if (AdataSize)
    {
        bytes = fwrite(AdataBuffer, 1, (size_t)AdataSize, fp);
        if (bytes != (size_t)AdataSize)
        {
            fclose(fp);
            printf("\n can't write file");
            return MC_CANNOT_COMPLY;
        }
    }

    if (AisLast)
        fclose(fp);

    return MC_NORMAL_COMPLETION;
}


/********************************************************************
 *
 *  Function    :   read_cmd_line
 *
 *  Parameters  :   Aargc   - Number of command line arguments
 *                  Aargv   - Array of pointers to arguments
 *
 *  Returns     :   TRUE     - All went well
 *                  FALSE    - Error on command line
 *
 *  Description :   Command line parser
 *
 *  Usage: Mpeg2Dicom -pu <inputFile> <outputFile> 
 *     or  Mpeg2Dicom -h   (for help)
 *     or  Mpeg2Dicom -?   (for help)
 *     or  Mpeg2Dicom      (for help)
 *
 *        Command:
 *          -p            = pack MPEG-2 stream into DICOM file
 *          -u            = unpack MPEG-2 stream from DICOM file
 *        Parameters:
 *          <inputFile>   = MANDATORY: existing file name for input
 *          <outputFile>  = MANDATORY: new file name for output
 *
 ********************************************************************/
static int read_cmd_line( int Aargc, char *Aargv[])
{

    /* Missing arguments */
    if (Aargc < 3)
    {
        print_cmdline();
        return FALSE;
    }

    /* Invalid commands */
    if(strcmp(Aargv[1], "-p") && strcmp(Aargv[1], "-P") && strcmp(Aargv[1], "-u") && strcmp(Aargv[1], "-U"))
    {
        print_cmdline();
        return FALSE;
    }

    S_Operation = Aargv[1][1]; /* just the command character */
    S_InputFile = Aargv[2];
    S_OutputFile = Aargv[3];

    return TRUE;
}

/********************************************************************
 *
 *  Function    :   print_cmdline
 *
 *  Parameters  :   none
 *
 *  Returns     :   nothing
 *
 *  Description :   Prints program usage
 *
 ********************************************************************/
static void print_cmdline(void)
{
    printf("Usage: mpeg2Dicom -pu <inputFile> <outputFile>\n");
    printf("   or  mpeg2Dicom -h   (for help)\n");
    printf("\n");
    printf("      Command:\n");
    printf("        -p            = pack MPEG-2 stream into DICOM file\n");
	printf("                      Note: The MPEG image size is hardcoded to 512x512@30fps\n");
    printf("        -u            = unpack MPEG-2 stream from DICOM file\n");
    printf("      Parameters:\n");
    printf("        <inputFile>   = existing file name for input\n");
    printf("        <outputFile>  = new file name for output\n");
    printf("\n");
    printf("Example: mpeg2Dicom -p input.mpg output.dcm\n\n");
}

MC_STATUS NOEXP_FUNC SetPixelFunction(int AmsgID, unsigned long ATag, int AfirstCall,
                                      void* AuserInfo, int* AdataLen, void** Abuffer,
                                      int* AisLast)
{
    FileCbkInfo* cbInfo = (FileCbkInfo*) AuserInfo;
    size_t count;

    if(ATag != MC_ATT_PIXEL_DATA ) 
        return MC_CANNOT_COMPLY;

    if( !AuserInfo ) 
        return MC_CANNOT_COMPLY;

    if( AfirstCall ) 
    {
        cbInfo->file = fopen( cbInfo->fileName, "rb" );
        if( !cbInfo->file )
        {
            printf("Failed to open file for reading %s, error: %s\n", cbInfo->fileName, strerror(errno) );
            return MC_CANNOT_COMPLY;
        }
    }

    *Abuffer = cbInfo->buffer;

    count = fread( cbInfo->buffer, 1, cbInfo->bufferSize, cbInfo->file );

    if( count != (size_t) cbInfo->bufferSize )
    {
        if (!feof(cbInfo->file))
        {
            printf("Failed to read from %s, error: %s\n", cbInfo->fileName, strerror(errno) );
            fclose(cbInfo->file);
            return MC_CANNOT_COMPLY;
        }
        fclose(cbInfo->file);
        *AisLast = 1;
    }
    *AdataLen = (int) count;

    return MC_NORMAL_COMPLETION;
}



static MC_STATUS WrapToDcm(int applicationID, const char* mpgFileName, const char* dcmFileName)
{
    MC_STATUS   mcStatus;
    int         messageID;
    FileCbkInfo fwInfo;
    FileCbkInfo frInfo;
    const size_t buffer_size = 1024*1024*20; /* 20 meg*/
	/*unsigned short miVer = 0x0100;*/
    /* MPEG2 Main Profile @ Main Level (SDTV)*/
    /* use 1.2.840.10008.1.2.4.101 for MPEG2 Main Profile @ High Level (HDTV) */
    const char* MPEG_TRANSFER_SYNTAX_UID = "1.2.840.10008.1.2.4.100";
	
    /*
    ** create an empty message
    */
	mcStatus = MC_Open_Empty_Message(&messageID);
	if(mcStatus != MC_NORMAL_COMPLETION)
		return mcStatus;

	/* Set service separatelly to improve the performance */
	mcStatus = MC_Set_Service_Command(messageID, Services.STANDARD_SEC_CAPTURE, C_STORE_RQ);
	if(mcStatus != MC_NORMAL_COMPLETION)
		return mcStatus;
    
    mcStatus = MC_Set_Message_Transfer_Syntax(messageID, MPEG2_MPML);
	if(mcStatus != MC_NORMAL_COMPLETION)
		return mcStatus;

    /* Set pixel data related attributes 
    * The value of Planar Configuration (0028,0006) is irrelevant since the manner of encoding components is
    * specified in the MPEG2 MP@ML standard, hence it shall be set to 0.
    *   In summary:
    *    - Samples per Pixel (0028,0002) shall be 3
    *    - Photometric Interpretation (0028,0004) shall be YBR_PARTIAL_420
    *    - Bits Allocated (0028,0100) shall be 8
    *    - Bits Stored (0028,0101) shall be 8
    *    - High Bit (0028,0102) shall be 7
    *    - Pixel Representation (0028,0103) shall be 0
    *    - Planar Configuration (0028,0006) shall be 0
    *    - Rows (0028,0010), Columns (0028,0011), Cine Rate (0018,0040) and Frame Time (0018,1063)
    *    or Frame Time Vector (0018,1065) shall be consistent with the limitations of MP@ML
    **********************************************************************************************/

    mcStatus = MC_Set_Value_From_Int(messageID, MC_ATT_SAMPLES_PER_PIXEL, 3);
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_PHOTOMETRIC_INTERPRETATION, "YBR_PARTIAL_420");
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 

    mcStatus = MC_Set_Value_From_Int(messageID, MC_ATT_BITS_ALLOCATED, 8);
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 

    mcStatus = MC_Set_Value_From_Int(messageID, MC_ATT_BITS_STORED, 8);
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 

    mcStatus = MC_Set_Value_From_Int(messageID, MC_ATT_HIGH_BIT, 7);
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 

    mcStatus = MC_Set_Value_From_Int(messageID, MC_ATT_PIXEL_REPRESENTATION, 0);
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 

    mcStatus = MC_Set_Value_From_Int(messageID, MC_ATT_PLANAR_CONFIGURATION, 0);
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 

	/*** Image Size shall to match the MPEG file *******/
    mcStatus = MC_Set_Value_From_Int(messageID, MC_ATT_ROWS, 512);
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 

    mcStatus = MC_Set_Value_From_Int(messageID, MC_ATT_COLUMNS, 512);
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 

	/**************************/

    mcStatus = MC_Set_Value_From_Int(messageID, MC_ATT_CINE_RATE, 30);
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 

    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_FRAME_TIME, "33.3");
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 

    /*Multi-frame True Color Secondary Capture Image Storage*/
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_SOP_CLASS_UID, "1.2.840.10008.5.1.4.1.1.7.4" );
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_SOP_INSTANCE_UID, "1.2.3.4.5.6.7.300");
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_STUDY_DATE, "19991029");
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_CONTENT_DATE, "19991029");
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_STUDY_TIME, "154500");
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_CONTENT_TIME,  "154510");
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_ACCESSION_NUMBER,  "123456");
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    /* Video Microscopic Image - modality = GM */
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_MODALITY,  "GM"); 
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_MANUFACTURER,  "MERGE" );
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_REFERRING_PHYSICIANS_NAME,  "Luke^Will^^Dr.^M.D." );
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
	mcStatus = MC_Set_Value_To_NULL(messageID, MC_ATT_REFERENCED_PERFORMED_PROCEDURE_STEP_SEQUENCE);
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_PATIENTS_NAME,  "Jane^Doo" );
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_PATIENT_ID,  "234567" );
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_PATIENTS_BIRTH_DATE,  "19991109" );
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_PATIENTS_SEX,  "F");
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_STUDY_INSTANCE_UID,  "1.2.3.4.5.6.7.100");
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_SERIES_INSTANCE_UID,  "1.2.3.4.5.6.7.200");
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_STUDY_ID,  "345678");
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_SERIES_NUMBER,  "1");
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MC_ATT_INSTANCE_NUMBER,  "1");
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_To_NULL(messageID, MC_ATT_PERFORMED_PROCEDURE_CODE_SEQUENCE);
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 

    /* Allocate callback data */
    frInfo.file = NULL;
    frInfo.fileName = mpgFileName;
    frInfo.buffer = malloc(buffer_size);
    if( !frInfo.buffer )
    {
        printf("Failed to allocate memory, error: %s\n", strerror(errno) );
        return MC_SYSTEM_ERROR;
    }
    frInfo.bufferSize = (int) buffer_size;

    mcStatus = MC_Set_Encapsulated_Value_From_Function(messageID, MC_ATT_PIXEL_DATA, &frInfo, SetPixelFunction);
    free(frInfo.buffer);

    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 

    mcStatus = MC_Close_Encapsulated_Value(messageID, MC_ATT_PIXEL_DATA);
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 

    mcStatus = MC_Message_To_File(messageID, dcmFileName);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        printf("Error from MC_Message_To_File");
        printf("\t%s\n", MC_Error_Message(mcStatus));
        return mcStatus;
    }

    /** Set file meta information **/
#ifdef NOTDEF
	mcStatus = MC_Set_Value_From_Buffer(messageID, MEDIA_FILE_META_INFO_VER, &miVer, sizeof(miVer) );
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
#endif
    mcStatus = MC_Set_Value_From_String(messageID, MEDIA_TRANSFER_SYNTAX_UID, MPEG_TRANSFER_SYNTAX_UID); 
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MEDIA_IMPLEMENTATION_CLASS_UID, "2.16.840.1.113669.2.931128" );
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MEDIA_IMPLEMENTATION_VER_NAME, "MergeCOM3_2.4");
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    /*Multi-frame True Color Secondary Capture Image Storage*/
    mcStatus = MC_Set_Value_From_String(messageID, MEDIA_STORAGE_SOP_CLASS_UID, "1.2.840.10008.5.1.4.1.1.7.4" );
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 
    mcStatus = MC_Set_Value_From_String(messageID, MEDIA_STORAGE_SOP_INSTANCE_UID, "1.2.3.4.5.6.7.300" );
    if(mcStatus != MC_NORMAL_COMPLETION) 
        return mcStatus; 


    fwInfo.file = NULL;
    fwInfo.fileName = dcmFileName;

    mcStatus = MC_Write_File( messageID, 0, &fwInfo, FileWriteCbk );
    if ( mcStatus != MC_NORMAL_COMPLETION )
    {
        printf("Error from MC_Write_File");
        printf("\t%s\n", MC_Error_Message(mcStatus));
        return mcStatus;
    }

    return MC_NORMAL_COMPLETION;
}


static MC_STATUS UnpackMpeg(int applicationID, const char* dcmFileName, const char* mpgFileName)
{
    MC_STATUS   mcStatus;
    CBinfo      callbackInfo;
	int			fileID;
    TRANSFER_SYNTAX ts;

	/*
     * Read the file off of disk
     */
	mcStatus = MC_Create_Empty_File( &fileID, dcmFileName );
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        printf("Error from MC_Empty_File");
        printf("\t%s\n", MC_Error_Message(mcStatus));
        return mcStatus;
    }

    mcStatus = MC_Open_File(applicationID,
                            fileID,
                            &callbackInfo,
                            MediaToFileObj);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        printf("Unable to open file object");
        printf("\t%s\n", MC_Error_Message(mcStatus));
        return mcStatus;
    }

    mcStatus = MC_Get_Message_Transfer_Syntax(fileID, &ts);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        printf("Error from MC_Get_Message_Transfer_Syntax");
        printf("\t%s\n", MC_Error_Message(mcStatus));
        return mcStatus;
    }

	if(ts != MPEG2_MPML && ts != MPEG2_MPHL)
	{
        printf("Invalid input file. Expecting DICOM MPEG video");
        return MC_INVALID_FILE;
	}

    mcStatus = MC_Get_Encapsulated_Value_To_Function( fileID, MC_ATT_PIXEL_DATA, (char *)mpgFileName, ValueToFile);
    if (mcStatus != MC_NORMAL_COMPLETION)
    {
        printf("Error from MC_Get_Encapsulated_Value_To_Function");
        printf("\t%s\n", MC_Error_Message(mcStatus));
        return mcStatus;
    }
    
    MC_Free_Message(&fileID);

    return MC_NORMAL_COMPLETION;
}
