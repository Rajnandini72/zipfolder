
/*******************************************************************************
 *                                                                             *
 *       System: Merge DICOM Tool Kit Sample Applications                      *
 *                                                                             *
 *       Author: Merge Healthcare                                              *
 *                                                                             *
 *  Description: Compression Sample Application.                               *
 *                                                                             *
 *******************************************************************************
 *                                                                             *
 *   Copyright (C) IBM Corporation 2016, 2020.                                 *
 *   Copyright (C) Merge Healthcare 2005, 2016.                                *
 *                                                                             *
 *   All rights reserved.                                                      *
 *                                                                             *
 *  This software is furnished under license and may be used and copied only   *
 *  in accordance with the terms of such license and with the inclusion of the *
 *  above copyright notice.                                                    *
 *                                                                             *
 *  This software or any other copies thereof may not be provided or otherwise *
 *  made available to any other person. No title to and ownership of the       *
 *  software is hereby transferred.                                            *
 *                                                                             *
 *******************************************************************************/

#include "mc3media.h"
#include "mc3msg.h"
#include "mcstatus.h"
#include "mergecom.h"
#include "diction.h"
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <memory.h>

#ifdef _WIN32
    #pragma warning(disable : 4996)
#endif

#include <fcntl.h>

/* Mark unreferenced variables/functions with UNUSED to avoid compiler warnings. */
#ifdef __GNUC__
#define UNUSED __attribute__((__unused__))
#else
#define UNUSED /* empty */
#endif

#ifdef BIG_END
#define LONG_FROM_LITTLE_ENDIAN(SOURCE, DEST) \
    { \
      ((unsigned char*)(DEST))[0] = ((unsigned char*)(SOURCE))[3]; \
      ((unsigned char*)(DEST))[1] = ((unsigned char*)(SOURCE))[2]; \
      ((unsigned char*)(DEST))[2] = ((unsigned char*)(SOURCE))[1]; \
      ((unsigned char*)(DEST))[3] = ((unsigned char*)(SOURCE))[0]; \
    }
#else
#define LONG_FROM_LITTLE_ENDIAN(SOURCE, DEST) \
    { \
      ((unsigned char*)(DEST))[0] = ((unsigned char*)(SOURCE))[0]; \
      ((unsigned char*)(DEST))[1] = ((unsigned char*)(SOURCE))[1]; \
      ((unsigned char*)(DEST))[2] = ((unsigned char*)(SOURCE))[2]; \
      ((unsigned char*)(DEST))[3] = ((unsigned char*)(SOURCE))[3]; \
    }
#endif

#define EXIT_SUCCESS      0
#define EXIT_FAILURE      1
#define FILENAME_LEN      512
#define MC_FAILED(STATUS) STATUS != MC_NORMAL_COMPLETION
#define WORK_BUFFER_SIZE  28*1024

typedef struct MC3_FILE_OBJECT 
{
#ifdef UNIX_FILEIO
    int             fd;
    MTI_BOOLEAN     eof;
#else
    FILE*           fp;
#endif
} MC3FILE;

/*
 *  Internal MC Toolkit structure, SHOULD NOT be changed
 */
typedef struct FileOpInfo_struct
{
    char*       FileName;

    int         BufferSize;
    void*       Buffer;

    MTI_BOOLEAN Readonly;
    MTI_BOOLEAN Truncate;

    MTI_BOOLEAN FileOpen;
    MC3FILE     FileHandle;

    int         LastOp;
    long        Offset;
    long        Size;
} FileOpInfo;

typedef struct app_config
{
    int     applicationID;
    char    inputFile[FILENAME_LEN];
    char    storageFolder[FILENAME_LEN];
} AppConfig;

typedef struct OffsetTableInfo_struct
{
    int number_of_offsets;
    unsigned long *offsets;
} OffsetTableInfo;

#if !defined(ANDROID) && !defined(IOS) && !defined(LINUX_ARM)
#define NUM_OF_ENCAPSULATED_SYNTAXES 8
static TRANSFER_SYNTAX encapsulatedTransferSyntax[] = {
    JPEG_BASELINE, 
    JPEG_EXTENDED_2_4,
    JPEG_LOSSLESS_HIER_14,
    JPEG_2000,
    JPEG_2000_LOSSLESS_ONLY,
    JPEG_LS_LOSSLESS,
    JPEG_LS_LOSSY,
    RLE
};

#define NUM_OF_SYNTAXES 2
static char* transferSyntaxName[] = { "JPEG_2000", "RLE" };
static TRANSFER_SYNTAX transferSyntax[] = { JPEG_2000, RLE };
#else
#if defined(PEGASUS)
#define NUM_OF_ENCAPSULATED_SYNTAXES 3
static  TRANSFER_SYNTAX encapsulatedTransferSyntax[] = {
    JPEG_BASELINE, 
    JPEG_EXTENDED_2_4,
    RLE
};
#else
#define NUM_OF_ENCAPSULATED_SYNTAXES 1
static  TRANSFER_SYNTAX encapsulatedTransferSyntax[] = { RLE };

#endif /* PEGASUS */
#define NUM_OF_SYNTAXES 1
static char* transferSyntaxName[] = { "RLE" };
static TRANSFER_SYNTAX transferSyntax[] = { RLE };
#endif /* !ANDROID && !IOS && !LINUX_ARM */

static void ShowUsage(void);
static int isEncapsulated(TRANSFER_SYNTAX ts);
static void CleanUp(AppConfig *appConfig);
static int GetOptions(int A_argc, char **A_argv, AppConfig *appConfig);
static int Compress(AppConfig *appConfig);
static int Read(AppConfig *appConfig);
static void Replace(char *string, char oldCh, char newCh);
static int LastIndexOf(char *string, char ch);

MC_STATUS FileWriteCallbackFunction(char* A_filename, void* userInfo, int dataSize, void* dataBuffer, int isFirst, int isLast);
MC_STATUS DataCallbackFunction(int AmsgID, unsigned long ATag, void* AuserInfo, CALLBACK_TYPE Atype, unsigned long* AdataLen, void** AdataValue, int AisFirst, int* AisLast);
MC_STATUS FileCallbackFunction(char* filename, void* userInfo, int* dataSizePtr, void** dataBufferPtr, int isFirst, int* isLastPtr);
MC_STATUS OffsetTableCallbackFunction(int CBmsgID, unsigned long ATag, void* CBuserInfo, int CBdataLen, void* CBdataBuffer, int CBfirstCall, int CBisLast);
MC_STATUS FrameCallbackFunction(int CBmsgID, unsigned long  ATag, void* CBuserInfo, int CBdataLen, void* CBdataBuffer, int CBfirstCall, int CBisLast);

/*****************************************************************************
**
** NAME
**    main - Compression sample main program
**
** SYNOPSIS
**    comp
**
** DESCRIPTION
**  Compression sample is used to demonstrate a compression/decompression and reading encapsulated data.
**  Non-encapsulated multi-frame DICOM file is used as an input to create a compressed multi-frame output DICOM files.
**
*****************************************************************************/
int main(int argc, char** argv);
int main(int argc, char** argv)
{
    MC_STATUS   mcStatus;
    AppConfig   appConfig;

    /*
     * Set up the default variables and get the command line options
     */
    if(GetOptions(argc, argv, &appConfig))
    {
        /*
         *  Compression sample read the input multi-frame file from data storage, 
         *  creates compressed output files and reads a pixel frames from them.
         *
         *  Example: "1.3.6.1.4.1.5962.1.1.5001.1.1.1118413147.3424.dcm"
         *
         *  ./testimages/1.3.6.1.4.1.5962.1.1.5001.1.1.1118413147.3424.dcm - DICOM sample, Explicit Little Endian, 22 frames
         */
        ShowUsage();
        return EXIT_FAILURE;
    }

    /* ------------------------------------------------------- */
    /* This call MUST be the first call made to the library!!! */
    /* ------------------------------------------------------- */
    mcStatus = MC_Library_Initialization(NULL, NULL, NULL);
    if(mcStatus != MC_NORMAL_COMPLETION)
    {
        printf("Unable to initialize MC library\n");
        return(EXIT_FAILURE);
    }

    /*
     * Register local application title
     */
    mcStatus = MC_Register_Application(&appConfig.applicationID, "COMP_SAMPLE");
    if(mcStatus != MC_NORMAL_COMPLETION)
    {
        printf("Failed to register MCapplication\n");
        return(EXIT_FAILURE);
    }

    /*
     *  Compress() creates a file copies with compressed encapsulated data in StorageFolder
     */
    if(Compress(&appConfig))
    {
        printf("Compress failed\n");
        CleanUp(&appConfig);

        return(EXIT_FAILURE);
    }

    /*
     *  Read() reads a file copies with compressed encapsulated data from DATA_FOLDER
     */
    if(Read(&appConfig))
    {
        printf("Read failed\n");
        CleanUp(&appConfig);

        return(EXIT_FAILURE);
    }

    return(EXIT_SUCCESS);

} /* main */

static void ShowUsage()
{
    printf("\n");
    printf("Compression sample.\n");
    printf("(c) 2020 Merge Healthcare\n");
    printf("All rights reserved.\n\n");
    printf("Usage:\n");
    printf("    comp|compd|comps file_path [-s store_dir] \n");
    printf("Options:\n");
    printf("    file_path       (mandatory) Input DICOM file\n");
    printf("    -s store_dir    (optional)  Directory for the output files (it must pre-exist).\n");
    printf("                                Default: current directory.\n");
    printf("\n");
}

static void CleanUp(AppConfig* appConfig)
{
    MC_STATUS status;

    status = MC_Release_Application(&appConfig->applicationID);
    if(status != MC_NORMAL_COMPLETION)
    {
        printf("Failed to release MCapplication\n");
        return;
    }

    status = MC_Library_Release();
    if(status != MC_NORMAL_COMPLETION)
    {
        printf("Failed to release the library\n");
        return;
    }
}

static int GetOptions(int A_argc, char **A_argv, AppConfig* appConfig)
{
    int len;

    if(A_argc != 2 && A_argc != 4)
        return 1;

    strcpy(appConfig->inputFile, A_argv[1]);
    /* Normalize path separator to '/' */
    Replace(appConfig->inputFile, '\\', '/');
    if(A_argc == 2)
    {
        /* Default storage folder to current */
        strcpy(appConfig->storageFolder, "./");
        return 0;
    }

    if(strcmp(A_argv[2], "-s"))
        return 1;

    strcpy(appConfig->storageFolder, A_argv[3]);
    /* Normalize path separator to '/' */
    Replace(appConfig->storageFolder, '\\', '/');

    /* Append '/' as last character */
    len = (int)strlen(appConfig->storageFolder);
    if(appConfig->storageFolder[len - 1] != '/')
    {
        appConfig->storageFolder[len] = '/';
        appConfig->storageFolder[len + 1] = 0;
    }
    return 0;
}

/* 
 * Do compression using memory mechanism 
 */
static int Compress(AppConfig *appConfig)
{
    MC_STATUS   status;
    TRANSFER_SYNTAX t_syntax;

    int fileID = -1, dupID = -1;
    int i = 0;

    char outfile[FILENAME_LEN] = {0};

    FileOpInfo fileOpInfo = {0};

    for(i = 0; i < NUM_OF_SYNTAXES; i++)
    {
        /* Output file: storage folder + TS name + input file name without directory path */
        sprintf(outfile, "%s%s.%s", appConfig->storageFolder, transferSyntaxName[i],
                appConfig->inputFile + LastIndexOf(appConfig->inputFile, '/') + 1);

        dupID = -1;
        fileOpInfo.FileName = outfile;

        status = MC_Create_Empty_File(&fileID, appConfig->inputFile);
        if(MC_FAILED(status))
        {
            printf("MC_Create_Empty_File failed for %s\n", appConfig->inputFile);
            return(EXIT_FAILURE);
        }

        /*
         *  Read all DICOM data from input file into memory including pixel data
         */
        status = MC_Open_File(appConfig->applicationID, fileID, appConfig->inputFile, FileCallbackFunction);
        if(MC_FAILED(status))
        {
            printf("MC_Open_File failed for %s\n", appConfig->inputFile);
            return(EXIT_FAILURE);
        }

        /*
         *  Check if input file is already encapsulated 
         */
        status = MC_Get_Message_Transfer_Syntax(fileID, &t_syntax);
        if(status != MC_NORMAL_COMPLETION)
        {
            printf("MC_Get_Message_Transfer_Syntax failed\n");
            return(EXIT_FAILURE);
        }

        if(isEncapsulated(t_syntax))
        {
            printf("File %s is already encapsulated\n", appConfig->inputFile);
            return(EXIT_FAILURE);
        }

        /*
         *  Duplicate all DICOM data into new transfer syntax, compress pixel data if required
         */
        status = (!strcmp(transferSyntaxName[i], "RLE")) ?
            MC_Duplicate_Message(fileID, &dupID, transferSyntax[i], MC_RLE_Compressor, MC_RLE_Decompressor) :
            MC_Duplicate_Message(fileID, &dupID, transferSyntax[i], MC_Standard_Compressor, MC_Standard_Decompressor);

        if(MC_FAILED(status))
        {
            printf("MC_Duplicate_Message failed\n");
            return(EXIT_FAILURE);
        }

        /*
         *  Write compressed multi-frame DICOM data into output file
         */
        status = MC_Set_Message_Transfer_Syntax(dupID, transferSyntax[i]);
        if(MC_FAILED(status))
        {
            printf("MC_Set_Message_Transfer_Syntax failed\n");
            return(EXIT_FAILURE);
        }

        status = MC_Write_File(dupID, 0, &fileOpInfo, FileWriteCallbackFunction);
        if(MC_FAILED(status))
        {
            printf("MC_Write_File failed for %s\n", fileOpInfo.FileName);
            return(EXIT_FAILURE);
        }

        /* Clean up*/
        MC_Free_Message(&fileID);
        MC_Free_File(&dupID);
    }
    return EXIT_SUCCESS;
}

/* 
 * Read compressed files using callback mechanism 
 */
static int Read(AppConfig *appConfig)
{
    MC_STATUS   status;
    FileOpInfo  fileOpInfo = {0};
    OffsetTableInfo offsetTableInfo = {0};

    int fileID = -1;
    int numberOfFrames = 0, i = 0, off = 0, nframe = 0;
    
    char filename[FILENAME_LEN] = {0}, outfile[FILENAME_LEN] = {0};
    long streamOffset = 0;

    status = MC_Register_Callback_Function(appConfig->applicationID, MC_ATT_PIXEL_DATA, &fileOpInfo, DataCallbackFunction);
    if(MC_FAILED(status))
    {
        printf("MC_Register_Callback_Function failed\n");
        return(EXIT_FAILURE);
    }

    for(i = 0; i < NUM_OF_SYNTAXES; i++)
    {
        /* Input multi-frame file with compressed encapsulated pixel data */
        sprintf(filename, "%s%s.%s", appConfig->storageFolder, transferSyntaxName[i],
                appConfig->inputFile + LastIndexOf(appConfig->inputFile, '/') + 1);
        fileOpInfo.FileName = filename;

        /* 
         * Create an empty DICOM file
         */
        status = MC_Create_Empty_File(&fileID, filename);
        if(MC_FAILED(status))
        {
            printf("MC_Create_Empty_File failed for %s\n", filename);
            return(EXIT_FAILURE);
        }

        /* 
         * Explicitly set Transfer Syntax 
         */
        status = MC_Set_Message_Transfer_Syntax(fileID, transferSyntax[i]);
        if(MC_FAILED(status))
        {
            printf("MC_Set_Message_Transfer_Syntax failed\n");
            return(EXIT_FAILURE);
        }

        /*
         *  Associate this file with application instance.
         *  The associated application will supply attribute value storage
         *  for this file through the registered callback.
         */
        status = MC_Set_Message_Callbacks(appConfig->applicationID, fileID);
        if(MC_FAILED(status))
        {
            printf("MC_Set_Message_Callbacks failed\n");
            return(EXIT_FAILURE);
        }

        /*
         *  Register default compressor/decompressor used on pixel frame reading
         */
        status = (!strcmp(transferSyntaxName[i], "RLE")) ?
            MC_Register_Compression_Callbacks(fileID, MC_RLE_Compressor, MC_RLE_Decompressor) :
            MC_Register_Compression_Callbacks(fileID, MC_Standard_Compressor, MC_Standard_Decompressor);

        if(MC_FAILED(status))
        {
            printf("MC_Register_Compression_Callbacks failed\n");
            return(EXIT_FAILURE);
        }

        /*
         * Open file and read DICOM attributes using FileCallbackFunction, but bypass pixel data. 
         * Pixel data will be accessed upon request using callback mechanism through DataCallbackFunction registered in application instance.
         * This mechanism allows to decrease the memory footprint on reading large pixel data.
         */
        status = MC_Open_File_Upto_Tag_Bypass_Value(appConfig->applicationID, fileID, filename, MC_ATT_PIXEL_DATA, MTI_TRUE, &streamOffset, FileCallbackFunction);
        if(MC_FAILED(status))
        {
            printf("MC_Open_File_Upto_Tag_Bypass_Value failed for %s\n", filename);
            return(EXIT_FAILURE);
        }

        /*
         *  Get number of frames
         */
        status = MC_Get_Value_To_Int(fileID, MC_ATT_NUMBER_OF_FRAMES, &numberOfFrames);
        if(status == MC_INVALID_TAG)
            numberOfFrames = 1;
        else if(MC_FAILED(status))
        {
            printf("MC_Get_Offset_Table_To_Function failed\n");
            return(EXIT_FAILURE);
        }
        if(numberOfFrames == 0)
            numberOfFrames = 1;

        /*
         *  Retrieve the offset table of pixel data
         */
        status = MC_Get_Offset_Table_To_Function(fileID, &offsetTableInfo, OffsetTableCallbackFunction);
        if(MC_FAILED(status))
        {
            printf("MC_Get_Offset_Table_To_Function failed\n");
            return(EXIT_FAILURE);
        }

        printf("Number of frames(0028,0008) [%d], number of offsets [%d]\n", numberOfFrames, offsetTableInfo.number_of_offsets);

        if(offsetTableInfo.offsets)
        {
            for(off = 0; off<offsetTableInfo.number_of_offsets; off++)
            {
                printf("Offset[%d] = %ld\n", off, offsetTableInfo.offsets[off]);
            }

            free(offsetTableInfo.offsets);

            offsetTableInfo.number_of_offsets = 0;
            offsetTableInfo.offsets = NULL;
        }

        /*
         *  Retrieve uncompressed encapsulated frames using MC_Get_Encapsulated_Value_To_Function / MC_Get_Next_Encapsulated_Value_To_Function 
         *  and write the results into output files with FrameCallbackFunction.
         */
        nframe = 0;

        sprintf(outfile,"%s.encapsulated.%d", filename, nframe + 1);
        status = MC_Get_Encapsulated_Value_To_Function(fileID, MC_ATT_PIXEL_DATA, outfile, FrameCallbackFunction);
        if(status != MC_END_OF_FRAME && status != MC_NORMAL_COMPLETION)
        {
            printf("MC_Get_Encapsulated_Value_To_Function failed\n");
            return(EXIT_FAILURE);
        }

        /*
         *  Continue with MC_Get_Next_Encapsulated_Value_To_Function 
         */
        while(status == MC_END_OF_FRAME || status == MC_NORMAL_COMPLETION)
        {
            nframe++;

            sprintf(outfile,"%s.encapsulated.%d", filename, nframe + 1);
            status = MC_Get_Next_Encapsulated_Value_To_Function(fileID, MC_ATT_PIXEL_DATA, outfile, FrameCallbackFunction);
        }
        if(MC_FAILED(status) && status != MC_NO_MORE_VALUES)
        {
            printf("MC_Get_Next_Encapsulated_Value_To_Function failed\n");
            return(EXIT_FAILURE);
        }

        /*
         *  Check the number of received pixel data frames
         */
        if(nframe != numberOfFrames)
        {
            printf("Invalid number of frames\n");
            return(EXIT_FAILURE);
        }

        /*
         *  Retrieve uncompressed encapsulated frames using MC_Get_Frame_To_Function 
         *  and write the results into output files with FrameCallbackFunction.
         */
        for(nframe = 0; nframe < numberOfFrames; nframe++)
        {
            sprintf(outfile,"%s.frame.%d", filename, nframe + 1);
            status = MC_Get_Frame_To_Function(fileID, nframe, outfile, FrameCallbackFunction);
            if(MC_FAILED(status))
            {
                printf("MC_Get_Frame_To_Function failed\n");
                return(EXIT_FAILURE);
            }
        }

        /*
         * Try to get non-existing frame of pixel data
         */
        nframe = 123;
        status = MC_Get_Frame_To_Function(fileID, nframe, outfile, FrameCallbackFunction);
        if(status != MC_NO_MORE_VALUES)
        {
                printf("MC_Get_Frame_To_Function failed\n");
                return(EXIT_FAILURE);
        }

        /* Clean up */
        MC_Free_File(&fileID);
    }

    status = MC_Release_Callback_Function(appConfig->applicationID, MC_ATT_PIXEL_DATA);
    if(MC_FAILED(status))
    {
        printf("MC_Release_Callback_Function failed\n");
        return(EXIT_FAILURE);
    }

    return EXIT_SUCCESS;
}

/*
 *  Callback function associated with MC_ATT_PIXEL_DATA and registered in application to read PIXEL data from a seekable stream
 *  This function should handle different CALLBACK_TYPE requests, such as:
 *    
 *  REQUEST_FOR_DATA,
 *  REQUEST_FOR_DATA_LENGTH,
 *  PROVIDING_DATA,
 *  PROVIDING_DATA_LENGTH,
 *  PROVIDING_MEDIA_DATA_LENGTH,
 *  PROVIDING_OFFSET_TABLE,
 *  FREE_DATA,
 *  REQUEST_FOR_DATA_WITH_OFFSET
 *
 */
MC_STATUS DataCallbackFunction(int AmsgID, unsigned long ATag, void* AuserInfo, CALLBACK_TYPE Atype, unsigned long* AdataLen, void** AdataValue, int AisFirst, int* AisLast)
{
    static char buffer[WORK_BUFFER_SIZE];

    FileOpInfo* fileOpInfo = (FileOpInfo*)NULL;
    long offset = -1;

    fileOpInfo = (FileOpInfo*)AuserInfo;
    if(fileOpInfo == NULL || fileOpInfo->FileName == NULL)
    {
        printf("Invalid user data\n"); 
        return MC_CANNOT_COMPLY; 
    }

    if(ATag != MC_ATT_PIXEL_DATA)
    { 
        printf("Invalid Tag\n");
        return MC_CANNOT_COMPLY; 
    }

    if(Atype == PROVIDING_MEDIA_DATA_LENGTH || Atype == PROVIDING_DATA_LENGTH)
    {
        fileOpInfo->Size = (long)*AdataLen;
    }
    else if(Atype == REQUEST_FOR_DATA_LENGTH)
    {
        *AdataLen = fileOpInfo->Size;
    }
    else if(Atype == REQUEST_FOR_DATA)
    {        
        if(AisFirst)
        {
            fileOpInfo->FileHandle.fp = fopen(fileOpInfo->FileName, "rb");
            if(!fileOpInfo->FileHandle.fp)
            {
                return MC_CALLBACK_CANNOT_COMPLY;
            }
        }

        *AdataLen = (unsigned long)fread(buffer, 1, sizeof(buffer), fileOpInfo->FileHandle.fp);
        *((char**)AdataValue) = buffer;

        if(feof(fileOpInfo->FileHandle.fp))
        {
            *AisLast = 1;
        }
    }
    else if(Atype == REQUEST_FOR_DATA_WITH_OFFSET)
    {
        if(AisFirst)
        {
            fileOpInfo->FileHandle.fp = fopen(fileOpInfo->FileName, "rb");
            if(!fileOpInfo->FileHandle.fp)
            {
                return MC_CALLBACK_CANNOT_COMPLY;
            }

            /* Retrieve data offset to start to read */
            offset = (long)*AdataLen;
            fseek(fileOpInfo->FileHandle.fp, offset, SEEK_SET);
        }

        *AdataLen = (unsigned long)fread(buffer, 1, sizeof(buffer), fileOpInfo->FileHandle.fp);
        *((char**)AdataValue) = buffer;

        if(feof(fileOpInfo->FileHandle.fp))
        {
            *AisLast = 1;
        }
    }
    else
    {
        return MC_CANNOT_COMPLY;
    }

    return MC_NORMAL_COMPLETION;
}

/*
 *  Callback function to read DICOM data in Open_File_Upon_Tag
 */
MC_STATUS FileCallbackFunction(char* filename, void* userInfo, int* dataSizePtr, void** dataBufferPtr, int isFirst, int* isLastPtr)
{
    static char buffer[WORK_BUFFER_SIZE];
    static FILE *fp;
    size_t dataread;

    if(isFirst)
    {
        fp = fopen(filename, "rb");
        if(!fp)
            return MC_CALLBACK_CANNOT_COMPLY;
    }

    dataread = fread(buffer, 1, sizeof(buffer), fp);

    if(feof(fp))
        *isLastPtr = 1;

    if(dataread >0)
        *dataSizePtr = (int)dataread;

    *dataBufferPtr = buffer;

    return MC_NORMAL_COMPLETION;
}

/*
 *  Callback function to handle frame data in Get_Encapsulated_Value_To_Function & Get_Frame_To_Function
 */
MC_STATUS FrameCallbackFunction(int CBmsgID, unsigned long  ATag, void* CBuserInfo, int CBdataLen, void* CBdataBuffer, int CBfirstCall, int CBisLast)
{
    static FILE *fp;

    /* Don't want it to do any file stuff if we didn't give it a filename */
    if(CBuserInfo == NULL)
        return MC_NORMAL_COMPLETION;

    if(CBfirstCall)
    {
        fp = fopen(CBuserInfo, "wb");
        if(fp == NULL)
            return MC_CALLBACK_CANNOT_COMPLY;
    }

    if(!fp)
        return MC_CANNOT_COMPLY;

    fwrite(CBdataBuffer, 1, CBdataLen, fp);

    if(CBisLast)
    {
        fclose(fp);
        fp = NULL;
    }

    return MC_NORMAL_COMPLETION;
}

/*
 *  Callback function to handle offset table data in Get_Offset_Table_To_Function
 */
MC_STATUS OffsetTableCallbackFunction(int CBmsgID, unsigned long ATag, void* CBuserInfo, int CBdataLen, void* CBdataBuffer, int CBfirstCall, int CBisLast)
{
    int offsets = -1, i = -1;
    unsigned long ul = 0; 
    char *buf = NULL;
    OffsetTableInfo *offsetTableInfo = NULL;

    if(CBmsgID <= 0)
        return MC_CALLBACK_CANNOT_COMPLY;

    if(ATag != MC_ATT_PIXEL_DATA)
        return MC_CALLBACK_CANNOT_COMPLY;

    if(CBfirstCall)
    {
        buf = (char *)CBdataBuffer;

        if(buf == NULL)
            return MC_CALLBACK_CANNOT_COMPLY;

        offsetTableInfo = (OffsetTableInfo *)CBuserInfo;
        if(offsetTableInfo == NULL)
        {
            return MC_CALLBACK_CANNOT_COMPLY;
        }

        offsetTableInfo->number_of_offsets = 0;
        if(offsetTableInfo->offsets)
        {
            free(offsetTableInfo->offsets);
        }

        LONG_FROM_LITTLE_ENDIAN(buf, &ul);

        buf += 4;
        offsets = ul / 4;

        offsetTableInfo->number_of_offsets = offsets;
        offsetTableInfo->offsets = (unsigned long *)malloc(offsets * sizeof(unsigned long));

        for(i = 0; i<offsets; i++)
        {
            LONG_FROM_LITTLE_ENDIAN(buf, &ul);
            offsetTableInfo->offsets[i] = ul;

            buf += 4;
        }
    }
    return MC_NORMAL_COMPLETION;
}

/*
 *  Callback function to write the content of DICOM file in MC_Write_File
 */
MC_STATUS FileWriteCallbackFunction(char* A_filename, void* userInfo, int dataSize, void* dataBuffer, int isFirst, int isLast)
{
    size_t count = 0;
    FileOpInfo* cbInfo = (FileOpInfo*)userInfo;

    if(!userInfo)
        return MC_CANNOT_COMPLY;

    if(isFirst)
        cbInfo->FileHandle.fp = fopen(cbInfo->FileName, "wb"); 

    if(!cbInfo->FileHandle.fp)
    {
        printf("Failed to open file to write %s\n", cbInfo->FileName);
        return MC_CANNOT_COMPLY;
    }

    count = fwrite(dataBuffer, 1, dataSize, cbInfo->FileHandle.fp);
    if(count != (size_t)dataSize)
    {
        printf("fwrite error\n");
        return MC_CANNOT_COMPLY;
    }

    if(isLast)
        fclose(cbInfo->FileHandle.fp);

    return MC_NORMAL_COMPLETION;
}

static int isEncapsulated(TRANSFER_SYNTAX ts)
{
    int i = 0;
    for(i = 0; i < NUM_OF_ENCAPSULATED_SYNTAXES; i++)
    {
        if(ts == encapsulatedTransferSyntax[i])
            return 1;
    }
    return 0;
}

static int LastIndexOf(char *string, char ch)
{
    int i;
    int lastIndex = -1;
    int len;

    len = (int)strlen(string);
    for(i = 0; i < len; ++i)
        if(string[i] == ch)
            lastIndex = i;

    return lastIndex;
}

static void Replace(char *string, char oldCh, char newCh)
{
    int i;
    int len;

    len = (int)strlen(string);
    for(i = 0; i < len; ++i)
        if(string[i] == oldCh)
            string[i] = newCh;
}
